import {defineCliConfig} from 'sanity/cli'

export default defineCliConfig({
  api: {
    projectId: 'h35hsaal',
    dataset: 'development'
  }
})
