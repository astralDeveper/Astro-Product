const configurations = {
  site: {
    name: "",
    title: "Kamer Lark",
    description: "",
    url: "",
  },
};

export default configurations