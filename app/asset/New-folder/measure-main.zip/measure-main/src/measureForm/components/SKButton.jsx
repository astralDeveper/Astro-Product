import React from "react";

export default function SKButton() {
  return <button>Next</button>;
}
