import "./App.css";
import RouterComponent from "./Router";

function App() {


  return (
    <div>
        <RouterComponent />
    </div>
  );
}

export default App;
