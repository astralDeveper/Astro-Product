import AwardsSliderSection from "../AwardsSliderSection";

export default function Section7() {
  return (
    <AwardsSliderSection />
  )
}