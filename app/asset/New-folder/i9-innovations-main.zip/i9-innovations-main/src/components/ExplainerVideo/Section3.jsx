import AwardsSliderSection from "../AwardsSliderSection";

export default function Section3() {
  return (
    <AwardsSliderSection />
  )
}