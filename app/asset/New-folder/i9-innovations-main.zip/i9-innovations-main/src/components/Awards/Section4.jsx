import AwardsSliderSection from "../AwardsSliderSection";

export default function Section4() {
  return (
    <AwardsSliderSection />
  )
}