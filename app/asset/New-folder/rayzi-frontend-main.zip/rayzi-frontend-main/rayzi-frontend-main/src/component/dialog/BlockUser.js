import React, { useEffect, useState } from "react";

//redux
import { connect, useDispatch, useSelector } from "react-redux";

//MUI
import {
  Dialog,
  DialogContent,
  DialogTitle,
  IconButton,
  Tooltip,
} from "@material-ui/core";
import { Cancel } from "@material-ui/icons";

//types
import { CLOSE_BLOCK_USER_DIALOG } from "../../store/user/types";

//action
import { handleBlockUnblockSwitch } from "../../store/user/action";

const BlockUserDialog = (props) => {
  const dispatch = useDispatch();

  const { dialog: open, dialogData } = useSelector((state) => state.user);

  const [blockHours, setBlockHours] = useState("");

  const [errors, setError] = useState({
    blockHours: "",
  });

  useEffect(
    () => () => {
      setError({
        blockHours: "",
      });
      setBlockHours("");
    },
    [open]
  );

  const closePopup = () => {
    dispatch({ type: CLOSE_BLOCK_USER_DIALOG });
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    if (!blockHours) {
      const error = {};

      if (!blockHours) error.diamonds = "Block hours is required!";
      return setError({ ...error });
    }
    dispatch(handleBlockUnblockSwitch(dialogData, blockHours));
    closePopup()
  };

  return (
    <>
      <Dialog
        open={open}
        aria-labelledby="responsive-dialog-title"
        onClose={closePopup}
        // disableBackdropClick
        disableEscapeKeyDown
        fullWidth
        maxWidth="sm"
      >
        <DialogTitle id="responsive-dialog-title">
          <span className="text-danger font-weight-bold h4"> Block user </span>
        </DialogTitle>

        <IconButton
          style={{
            position: "absolute",
            right: 0,
          }}
        >
          <Tooltip title="Close">
            <Cancel className="text-danger" onClick={closePopup} />
          </Tooltip>
        </IconButton>
        <DialogContent>
          <div className="modal-body pt-1 px-1 pb-3">
            <div className="d-flex flex-column">
              <form>
                <div className="form-group">
                  <label className="mb-2 text-gray">Block hours</label>
                  <input
                    type="number"
                    className="form-control"
                    required=""
                    value={blockHours}
                    placeholder="10"
                    onChange={(e) => {
                      setBlockHours(
                        (e.target.value = Math.max(
                          0,
                          parseInt(e.target.value)
                        ).toString())
                      );
                      if (!e.target.value) {
                        return setError({
                          ...errors,
                          diamonds: "Diamonds is Required !",
                        });
                      } else {
                        return setError({
                          ...errors,
                          diamonds: "",
                        });
                      }
                    }}
                  />
                  {errors.diamonds && (
                    <div className="ml-2 mt-1">
                      {errors.diamonds && (
                        <div className="pl-1 text__left">
                          <span className="text-red">{errors.diamonds}</span>
                        </div>
                      )}
                    </div>
                  )}
                </div>
                <div className="mt-5">
                  <button
                    type="button"
                    className="btn btn-outline-info ml-2 btn-round float__right icon_margin"
                    onClick={closePopup}
                  >
                    Close
                  </button>
                  <button
                    type="button"
                    className="btn btn-round float__right btn-danger"
                    onClick={handleSubmit}
                  >
                    Submit
                  </button>
                </div>
              </form>
            </div>
          </div>
        </DialogContent>
      </Dialog>
    </>
  );
};

export default connect(null, {  })(BlockUserDialog);
