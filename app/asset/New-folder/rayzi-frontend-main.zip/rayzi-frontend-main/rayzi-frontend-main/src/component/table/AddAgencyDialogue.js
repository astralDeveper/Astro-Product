import {
  Dialog,
  DialogContent,
  DialogTitle,
  IconButton,
  Tooltip,
} from "@material-ui/core";
import $ from "jquery";

import React, { Fragment, useEffect, useRef, useState } from "react";
import { connect, useDispatch, useSelector } from "react-redux";
import { createNewAgency, editAgency } from "../../store/agency/action";
import SVGA from "svgaplayerweb";

import { baseURL } from "../../util/Config";
import { Cancel } from "@material-ui/icons";
import { getCategory } from "../../store/giftCategory/action";
// import { Cropper } from "react-advanced-cropper";
import html2canvas from "html2canvas";
import { CLOSE_AGENCY_DIALOG } from "../../store/agency/types";
import { getUser } from "../../store/user/action";

const AddAgencyDialogue = (props) => {
  const dispatch = useDispatch();
  const { dialog: open, dialogData: dialogData } = useSelector(
    (state) => state.agency
  );

  // const categories = useSelector((state) => state.giftCategory.giftCategory);
  const [images, setImages] = useState([]);
  const [imagePath, setImagePath] = useState(null);

  const [agencyName, setAgencyName] = useState("");
  const [agencyTagLine, setAgencyTagLine] = useState("");
  const [imageData, setImageData] = useState(null);
  const [agencyOwner, setAgencyOwner] = useState("");
  const [mongoId, setMongoId] = useState("");

  const [data, setData] = useState([]);
  const [activePage, setActivePage] = useState(1);
  const [rowsPerPage, setRowsPerPage] = useState(10);
  const [search, setSearch] = useState("ALL");
  const [date, setDate] = useState([]);
  const [sDate, setsDate] = useState("ALL");
  const [eDate, seteDate] = useState("ALL");

  const [category, setCategory] = useState("");
  const [image, setImage] = useState();
  const [cropper, setCropper] = useState(null);
  const [isSubmit, setIsSubmit] = useState(false);
  const imageRef = useRef(null);

  useEffect(() => {
    dispatch(getUser(activePage, rowsPerPage, search, sDate, eDate));
  }, [activePage, rowsPerPage, search, sDate, eDate]);

  const { user, activeUser, male, female, totalUser } = useSelector(
    (state) => state.user
  );

  useEffect(() => {
    setData(user);
  }, [user]);

  const [errors, setError] = useState({
    agencyName: "",
    agencyOwner: "",
    image: "",
    agencyTagLine: "",
  });

  // useEffect(() => {
  //   dispatch(getCategory());
  // }, [dispatch]);

  // useEffect(() => {
  //   setIsSubmit(true);
  // }, [open]);

  useEffect(() => {
    if (dialogData) {
      setMongoId(dialogData._id);
      setAgencyName(dialogData.agencyName);
      setAgencyTagLine(dialogData.agencyTagLine);
      setAgencyOwner(dialogData.agencyOwner);
      setImagePath(baseURL + dialogData.image);
    }
  }, [dialogData]);

  // const removeImage = () => {
  //   setImage("");
  //   setImageData(null);
  //   setImagePath(null);
  // };

  useEffect(
    () => () => {
      setError({
        agencyName: "",
        agencyTagLine: "",
        agencyOwner: "",
        image: "",
      });
      setMongoId("");
      setAgencyName("");
      setAgencyTagLine("");
      setAgencyOwner("");
      setImageData(null);
      setImagePath(null);
    },
    [open]
  );

  const handleInputImage = (e) => {
    if (e.target.files[0]) {
      setImageData(e.target.files[0]);
      const reader = new FileReader();
      reader.addEventListener("load", () => {
        setImagePath(reader.result);
      });
      reader.readAsDataURL(e.target.files[0]);
    }
  };
  console.log(errors);
  // const imageSvg = useRef();
  const handleSubmit = async (e) => {
    e.preventDefault();

    // if (images.length === 0) {
    //   return setError({ ...errors, image: "Please select an Image!" });
    // }

    const error = {}
    if (!mongoId && (!agencyName || !agencyOwner || !agencyTagLine || !imagePath)) {
      if (!agencyName) error.agencyName = "Agency name is Required!";
      if (!agencyOwner) error.agencyOwner = "Agency owner is Required!";
      if (!agencyTagLine) error.agencyTagLine = "Agency tagline is Required!";
      if (!imageData || !imagePath) error.image = "Image is Required!";

      return setError({ ...error });
    }
    if (mongoId && (!agencyName || !agencyOwner || !agencyTagLine || !imagePath)) {
      if (!agencyName) error.agencyName = "Agency name is Required!";
      if (!agencyOwner) error.agencyOwner = "Agency owner is Required!";
      if (!agencyTagLine) error.agencyTagLine = "Agency tagline is Required!";
      if (!imageData || !imagePath) error.image = "Image is Required!";

      return setError({ ...error });
    }

    const formData = new FormData();
    formData.append("agencyName", agencyName);
    formData.append("agencyOwner", agencyOwner);
    formData.append("agencyTagLine", agencyTagLine);
    formData.append("image", imageData);

    if (mongoId) {
      props.editAgency(mongoId, formData);
    } else {
      props.createNewAgency(formData);
    }
  };

  const closePopup = () => {
    dispatch({ type: CLOSE_AGENCY_DIALOG });
  };

  return (
    <>
      <Dialog
        open={open}
        aria-labelledby="responsive-dialog-title"
        onClose={closePopup}
        // disableBackdropClick
        disableEscapeKeyDown
        fullWidth
        maxWidth="xs"
      >
        <DialogTitle id="responsive-dialog-title">
          <span className="text-danger font-weight-bold h4">Agency</span>
        </DialogTitle>

        <IconButton
          style={{
            position: "absolute",
            right: 0,
          }}
        >
          <Tooltip title="Close">
            <Cancel className="text-danger" onClick={closePopup} />
          </Tooltip>
        </IconButton>
        <DialogContent>
          <div class="modal-body pt-1 px-1 pb-3">
            <div class="d-flex flex-column">
              <div
                style={{ position: "absolute", opacity: "0", zIndex: "-111" }}
              >
                {/* <Cropper
                  defaultCoordinates={{
                    height: 221,
                    left: 77,
                    top: 128,
                    width: 192,
                  }}
                  src={image}
                  onChange={onChange}
                  className={"cropper"}
                /> */}
                {/* <img
                  ref={imageRef}
                  src={image}
                  alt="Original"
                  style={{ display: "none" }}
                /> */}
              </div>
              <form>
                <div class="form-group">
                  <label className="mb-2 text-gray">Name</label>
                  <input
                    type="text"
                    class="form-control"
                    placeholder="john doe"
                    required
                    value={agencyName}
                    onChange={(e) => {
                      setAgencyName(e.target.value);

                      if (!e.target.value) {
                        return setError({
                          ...errors,
                          agencyName: "Agency name can't be a blank!",
                        });
                      } else {
                        return setError({
                          ...errors,
                          agencyName: "",
                        });
                      }
                    }}
                  />
                   {errors.agencyName && (
                    <div className="ml-2 mt-1">
                      {errors.agencyName && (
                        <div className="pl-1 text__left">
                          <span className="text-red">{errors.agencyName}</span>
                        </div>
                      )}
                    </div>
                  )}
                </div>

                <div class="form-group mt-2">
                  <label className="mb-2 text-gray">Tag Line</label>
                  <input
                    type="text"
                    class="form-control"
                    placeholder="john doe"
                    required
                    value={agencyTagLine}
                    onChange={(e) => {
                      setAgencyTagLine(e.target.value);

                      if (!e.target.value) {
                        return setError({
                          ...errors,
                          agencyTagLine: "coin can't be a blank!",
                        });
                      } else {
                        return setError({
                          ...errors,
                          agencyTagLine: "",
                        });
                      }
                    }}
                  />
                   {errors.agencyTagLine && (
                    <div className="ml-2 mt-1">
                      {errors.agencyTagLine && (
                        <div className="pl-1 text__left">
                          <span className="text-red">{errors.agencyTagLine}</span>
                        </div>
                      )}
                    </div>
                  )}
                </div>

                <div class="form-group mt-2">
                  <label className="mb-2 mt-2 text-gray">Agency Owner</label>
                  <select
                    className="form-control"
                    value={agencyOwner}
                    onChange={(e) => {
                      setAgencyOwner(e.target.value);
                    }}
                  >
                    <option selected={true}>----</option>
                    {data.map((item) => (
                      <option key={item._id} value={item._id}>
                        {item.username} ({item.level.name})
                      </option>
                    ))}
                  </select>
                  {errors.agencyOwner && (
                    <div className="ml-2 mt-1">
                      {errors.agencyOwner && (
                        <div className="pl-1 text__left">
                          <span className="text-red">{errors.agencyOwner}</span>
                        </div>
                      )}
                    </div>
                  )}
                </div>

                <div class="form-group">
                  <label className="mb-2 mt-2 text-gray">Image</label>
                  <>
                    <input
                      class="form-control"
                      type="file"
                      required=""
                      accept="image/*"
                      onChange={handleInputImage}
                    />
                    {errors.image && (
                      <div className="ml-2 mt-1">
                        {errors.image && (
                          <div className="pl-1 text__left">
                            <span className="text-red">{errors.image}</span>
                          </div>
                        )}
                      </div>
                    )}
                    {imagePath && (
                      <img
                        src={imagePath}
                        class="mt-3 rounded float-left mb-2"
                        height="100px"
                        width="100px"
                      />
                    )}
                  </>
                </div>

                <div className="mt-5">
                  <button
                    type="button"
                    className="btn btn-outline-info ml-2 btn-round float__right icon_margin"
                    onClick={closePopup}
                  >
                    Close
                  </button>
                  <button
                    type="button"
                    disabled={isSubmit}
                    className="btn btn-round float__right btn-danger"
                    onClick={handleSubmit}
                  >
                    Submit
                  </button>
                </div>
              </form>
            </div>
          </div>
        </DialogContent>
      </Dialog>
    </>
  );
};

export default connect(null, { createNewAgency, editAgency })(
  AddAgencyDialogue
);
