import React, { useEffect, useState } from "react";

//redux
import { connect, useDispatch, useSelector } from "react-redux";

//action
// import { getAgency } from "../../store/agency/action";

//config
import { baseURL } from "../../util/Config";
//routing
import { Link, useHistory } from "react-router-dom";
// type
import {
  OPEN_AGENCY_DIALOG,
  CLOSE_AGENCY_DIALOG,
} from "../../store/agency/types";
// dialog
import GiftDialog from "../dialog/Gift/Edit";
//sweet alert
import { warning } from "../../util/Alert";

//all gift
import AllGift from "../../pages/AllGift";

//image
import noImage from "../../assets/images/noImage.png";

import SVGA from "svgaplayerweb";
import AddSvgaDialogue from "./AddSvgaDialogue";
import AddAgencyDialogue from "./AddAgencyDialogue";
import { getAgency, deleteAgency } from "../../store/agency/action";
import { Avatar, Tooltip } from "@material-ui/core";

const Agency = (props) => {
  const history = useHistory();
  const dispatch = useDispatch();
  const [data, setData] = useState([]);

  const category = JSON.parse(localStorage.getItem("Category"));

  const GiftClick = localStorage.getItem("GiftClick");

  useEffect(() => {
    dispatch(getAgency());
  }, [dispatch]);

  const [page, setPage] = useState(0);
  const [rowsPerPage, setRowsPerPage] = useState(10);

  const agency = useSelector((state) => state.agency.agency);

  useEffect(() => {
    setData(agency);
  }, [agency, data]);

  // // for .svga file
  // useEffect(() => {
  //   if (data.length > 0 &&
  //    data.map((gift, index) => {
  //       if (gift.icon.split(".").pop() === "svga") {
  //         var player = new SVGA.Player(`div[attr="${index}"]`);
  //         var parser = new SVGA.Parser(`div[attr="${index}"]`);
  //         parser.load(baseURL + "/" + gift.icon, function (videoItem) {
  //           player.setVideoItem(videoItem);
  //           player.startAnimation();
  //         });
  //       }
  //     });
  //   }
  // }, [data, rowsPerPage]);
  // useEffect(() => {
  //   data.map((gift, index) => {
  //     if (gift.image.split(".").pop() === "svga") {
  //       const player = new SVGA.Player(`div[attr="${index}"]`);
  //       const parser = new SVGA.Parser();

  //       parser.load(baseURL + "/" + gift.icon, (videoItem) => {
  //         player.setVideoItem(videoItem);
  //         player.startAnimation();
  //       });
  //     }
  //   });
  // }, [data]);

  const handleSearch = (e) => {
    const value = e.target.value.toUpperCase()
      ? e.target.value.trim().toUpperCase()
      : e.target.value.trim();
    if (value) {
      const data = agency.filter((data) => {
        return (
          data?.coin?.toString()?.indexOf(value) > -1 ||
          data?.category?.name?.toUpperCase()?.indexOf(value) > -1
        );
      });
      setData(data);
    } else {
      return setData(agency);
    }
  };

  const handleDelete = (agencyId) => {
    const data = warning();
    data
      .then((isDeleted) => {
        console.log(isDeleted);
        if (isDeleted) {
          props.deleteAgency(agencyId);
          // alert("Deleted!", `Agency has been deleted!`, "success");
        }
      })
      .catch((err) => console.log(err));
  };

  const handleEdit = (data) => {
    dispatch({ type: OPEN_AGENCY_DIALOG, payload: data });
  };

  const handleOpen = () => {
    dispatch({ type: OPEN_AGENCY_DIALOG });
  };

  return (
    <>
      <div className="page-title">
        <div className="row">
          <div className="col-12 col-md-6 order-md-1 order-last">
            <h3 className="mb-3 text-white">Agency</h3>
          </div>
          <div className="col-12 col-md-6 order-md-2 order-first">
            <nav
              aria-label="breadcrumb"
              className="breadcrumb-header float-start float-lg-end"
            >
              <ol className="breadcrumb">
                <li className="breadcrumb-item">
                  <Link to="/admin/dashboard" className="text-danger">
                    Dashboard
                  </Link>
                </li>
                <li className="breadcrumb-item active" aria-current="page">
                  Agency
                </li>
              </ol>
            </nav>
          </div>
        </div>
      </div>
      <div class="row">
        <div class="col">
          <div class="card">
            <div className="card-header pb-0">
              <div className="row my-3">
                <div className="col-xs-12 col-sm-12 col-md-6 col-lg-8 float-left">
                  <button
                    type="button"
                    className="btn waves-effect waves-light btn-danger btn-sm float-left"
                    onClick={handleOpen}
                    id="bannerDialog"
                  >
                    <i className="fa fa-plus"></i>
                    <span className="icon_margin">New</span>
                  </button>
                </div>
                <div className="col-xs-12 col-sm-12 col-md-6 col-lg-4 float-right mt-3 mt-lg-0 mt-xl-0">
                  <form action="">
                    <div className="input-group mb-3 border rounded-pill">
                      <div className="input-group-prepend border-0">
                        <div id="button-addon4" className="btn text-danger">
                          <i className="fas fa-search mt-2"></i>
                        </div>
                      </div>
                      <input
                        type="search"
                        placeholder="What're you searching for?"
                        aria-describedby="button-addon4"
                        className="form-control bg-none border-0 rounded-pill searchBar"
                        onChange={handleSearch}
                      />
                    </div>
                  </form>
                </div>
              </div>
            </div>
            <div class="card-body card-overflow">
              <div class="d-sm-flex align-items-center justify-content-between mb-4"></div>

              <table class="table table-striped">
                <thead className="text-center">
                  <tr>
                    <th>No.</th>
                    <th>Image</th>
                    <th>Name</th>
                    <th>Tag</th>
                    <th>Owner</th>
                    <th>Edit</th>
                    <th>Delete</th>
                  </tr>
                </thead>
                <tbody className="text-center">
                  {data?.length > 0 ? (
                    (rowsPerPage > 0
                      ? data.slice(
                          page * rowsPerPage,
                          page * rowsPerPage + rowsPerPage
                        )
                      : data
                    ).map((data, index) => {
                      return (
                        <tr key={index}>
                          <td>{index + 1}</td>
                          <td>
                            <img
                              src={`https://livebroadcastingapp-2f9c47b9791e.herokuapp.com/${data.image}`}
                              height="50px"
                              width="50px"
                            />
                          </td>
                          <td>{data.agencyName}</td>

                          <td>{data.agencyTagLine}</td>
                          <td>{data.agencyOwner}</td>
                          {/* <td>
                            <label className="switch">
                              <input
                                type="checkbox"
                                checked={data.isTop}
                                onChange={() => handleIsTop(data._id)}
                              />
                              <span className="slider">
                                <p
                                  style={{
                                    fontSize: 12,
                                    marginLeft: `${
                                      data.isTop ? "-24px" : "35px"
                                    }`,
                                    color: "#000",
                                    marginTop: "6px",
                                  }}
                                >
                                  {data.isTop ? "Yes" : "No"}
                                </p>
                              </span>
                            </label>
                          </td> */}
                          <td>
                            <Tooltip title="Edit">
                              <button
                                type="button"
                                className="btn btn-sm btn-info"
                                onClick={() => handleEdit(data)}
                              >
                                <i className="fa fa-edit fa-lg"></i>
                              </button>
                            </Tooltip>
                          </td>
                          <td>
                            <Tooltip title="Delete">
                              <button
                                type="button"
                                className="btn btn-danger btn-sm"
                                onClick={() => handleDelete(data._id)}
                              >
                                <i className="fas fa-trash-alt fa-lg"></i>
                              </button>
                            </Tooltip>
                          </td>
                        </tr>
                      );
                    })
                  ) : (
                    <tr>
                      <td colSpan="8" align="center">
                        Nothing to show!!
                      </td>
                    </tr>
                  )}
                </tbody>
              </table>
              {/* <TablePagination
                id="pagination"
                component="div"
                rowsPerPageOptions={[
                  5,
                  10,
                  25,
                  100,
                  { label: "All", value: -1 },
                ]}
                count={data.length}
                rowsPerPage={rowsPerPage}
                page={page}
                SelectProps={{
                  inputProps: { "aria-label": "rows per page" },
                  native: true,
                }}
                onChangePage={handleChangePage}
                onChangeRowsPerPage={handleChangeRowsPerPage}
                ActionsComponent={TablePaginationActions}
              /> */}
            </div>
          </div>
        </div>
      </div>
      <AddAgencyDialogue />
    </>
  );
};

export default connect(null, { getAgency, deleteAgency })(Agency);
