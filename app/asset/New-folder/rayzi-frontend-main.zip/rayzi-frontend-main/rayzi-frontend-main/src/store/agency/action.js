import axios from "axios";
import { Toast } from "../../util/Toast";
import {
  CLOSE_AGENCY_DIALOG,
  OPEN_AGENCY_DIALOG,
  CREATE_NEW_AGENCY,
  GET_AGENCY,
  DELETE_AGENCY,
  EDIT_AGENCY,
} from "./types";
import { apiInstanceFetch } from "../../util/api";

// const GiftClick = localStorage.getItem("GiftClick");

export const getAgency = () => (dispatch) => {
  apiInstanceFetch
    .get("agency/all")
    .then((res) => {
      if (res.status) {
        dispatch({ type: GET_AGENCY, payload: res?.agency });
      } else {
        // Toast("error", res.data.message);
      }
    })
    .catch((error) => Toast("error", error.message));
};

export const createNewAgency = (data) => (dispatch) => {
  axios
    .post("/agency", data)
    .then((res) => {
      if (res.data.status) {
        Toast("success", "Agency created successfully!");
        dispatch({ type: CLOSE_AGENCY_DIALOG });
        dispatch({ type: CREATE_NEW_AGENCY, payload: res.data.agency });
      } else {
        Toast("error", res.data.message);
      }
    })
    .catch((error) => {
      console.error("Error creating agency:", error);
      // Toast("error", error.response ? error.response.data.error : "Server Error");
    });
};
// export const createNewGiftSvga = (data, categoryID) => (dispatch) => {
//   axios
//     .post(`gift/svgaAdd`, data)
//     .then((res) => {
//       if (res.data.status) {
//         Toast("success", "Svga created successfully!");
//         dispatch({ type: CLOSE_SVGA_DIALOG });
//         dispatch({
//           type: CREATE_NEW_SVGA,
//           payload: {
//             categoryID: categoryID,
//             giftData: res.data.data,
//           },
//         });
//       } else {
//         Toast("error", res.data.message);
//       }
//     })
//     .catch((error) => Toast("error", error.message));
// };

// export const editGift = (data, giftId) => (dispatch) => {
//   axios
//     .patch(`gift/${giftId}`, data)
//     .then((res) => {
//       if (res.data.status) {
//         Toast("success", "Gift updated successfully!");
//         dispatch({ type: CLOSE_GIFT_DIALOG });
//         dispatch({
//           type: EDIT_GIFT,
//           payload: { data: res.data.gift, id: giftId },
//         });
//       } else {
//         Toast("error", res.data.message);
//       }
//     })
//     .catch((error) => Toast("error", error.message));
// };

// Delete
export const deleteAgency = (agencyId) => (dispatch) => {
  axios
    .delete(`agency/${agencyId}`)
    .then((res) => {
      if (res.data.status) {
        dispatch({ type: DELETE_AGENCY, payload: agencyId });
      } else {
        Toast("error", res.data.message);
      }
    })
    .catch((error) => console.log(error));
};

// Edit Agency
export const editAgency = (agencyId, data) => (dispatch) => {
  axios
    .patch(`/agency/${agencyId}`, data)
    .then((res) => {
      if (res.data.status) {
        Toast("success", "Agency updated successfully!");
        dispatch({ type: CLOSE_AGENCY_DIALOG });

        dispatch({
          type: EDIT_AGENCY,
          payload: { data: res.data.agency, id: agencyId },
        });
      } else {
        Toast("error", res.data.message);
      }
    })
    .catch((error) => Toast("error", error.message));
};
