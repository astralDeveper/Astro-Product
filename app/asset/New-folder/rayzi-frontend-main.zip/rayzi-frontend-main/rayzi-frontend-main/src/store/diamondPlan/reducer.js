import {
  GET_Diamond_PLAN,
  CREATE_NEW_Diamond_PLAN,
  EDIT_Diamond_PLAN,
  DELETE_Diamond_PLAN,
  OPEN_Diamond_PLAN_DIALOG,
  CLOSE_Diamond_PLAN_DIALOG,
  GET_Diamond_PLAN_HISTORY,
  ISTOP_SWITCH_TOGGLE,
} from "./type";

const initialState = {
  diamondPlan: [],
  dialog: false,
  dialogData: null,
  history: [],
  totalPlan: 0,
};

const diamondPlanReducer = (state = initialState, action) => {
  switch (action.type) {
    case GET_Diamond_PLAN:
      return {
        ...state,
        diamondPlan: action?.payload,
      };
    case CREATE_NEW_Diamond_PLAN:
      const data = [...state.diamondPlan];
      data.unshift(action.payload);
      return {
        ...state,
        diamondPlan: data,
      };
    case EDIT_Diamond_PLAN:
      return {
        ...state,
        diamondPlan: state.diamondPlan.map((diamondPlan) => {
          if (diamondPlan._id === action.payload.id) return action.payload.data;
          else return diamondPlan;
        }),
      };
    case DELETE_Diamond_PLAN:
      return {
        ...state,
        diamondPlan: state.diamondPlan.filter(
          (diamondPlan) => diamondPlan._id !== action.payload
        ),
      };
    case OPEN_Diamond_PLAN_DIALOG:
      return {
        ...state,
        dialog: true,
        dialogData: action.payload || null,
      };
    case CLOSE_Diamond_PLAN_DIALOG:
      return {
        ...state,
        dialog: false,
        dialogData: null,
      };

    case GET_Diamond_PLAN_HISTORY:
      return {
        ...state,
        history: action.payload.history,
        totalPlan: action.payload.total,
      };

    case ISTOP_SWITCH_TOGGLE:
      debugger;
      return {
        ...state,
        diamondPlan: state.diamondPlan.map((diamondPlan) => {
          if (diamondPlan._id === action.payload._id)
            return {
              ...diamondPlan,
              isTop: action.payload.isTop,
            };
          else return diamondPlan;
        }),
      };

    default:
      return state;
  }
};

export default diamondPlanReducer;
