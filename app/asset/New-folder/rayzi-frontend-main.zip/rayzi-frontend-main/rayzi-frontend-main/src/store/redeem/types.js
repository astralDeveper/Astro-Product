export const GET_REDEEM = "GET_REDEEM";

export const ACCEPT_REDEEM = "ACCEPT_REDEEM";
