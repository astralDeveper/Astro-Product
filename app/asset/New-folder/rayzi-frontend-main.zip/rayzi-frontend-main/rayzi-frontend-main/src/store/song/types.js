export const GET_SONG = "GET_SONG";
export const CREATE_NEW_SONG = "CREATE_NEW_SONG";
export const EDIT_SONG = "EDIT_SONG";
export const DELETE_SONG = "DELETE_SONG";
