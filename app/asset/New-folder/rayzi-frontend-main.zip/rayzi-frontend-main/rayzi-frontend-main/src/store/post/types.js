export const GET_POST = "GET_POST";
export const GET_COMMENT = "GET_COMMENT";
export const GET_LIKE = "GET_LIKE";
export const DELETE_POST = "DELETE_POST";
export const DELETE_COMMENT = "DELETE_COMMENT";
export const INSERT_POST = "INSERT_POST";
export const GET_FAKE_POST = "GET_FAKE_POST"
export const EDIT_FAKE_POST = "EDIT_FAKE_POST"