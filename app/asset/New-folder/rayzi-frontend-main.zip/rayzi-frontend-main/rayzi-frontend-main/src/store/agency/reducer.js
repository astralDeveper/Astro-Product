import {
  OPEN_AGENCY_DIALOG,
  CLOSE_AGENCY_DIALOG,
  CREATE_NEW_AGENCY,
  GET_AGENCY,
  DELETE_AGENCY,
  EDIT_AGENCY,
} from "./types";

const initialState = {
  dialog: false,
  dialogData: null,
  dialog1: false,
  dialogData1: null,
};

const agencyReducer = (state = initialState, action) => {
  switch (action.type) {
    case GET_AGENCY:
      return {
        ...state,
        agency: action.payload,
      };

    case CREATE_NEW_AGENCY:
      const data = [...state.agency];
      data.unshift(action.payload);
      return {
        ...state,
        agency: data,
      };
    case DELETE_AGENCY:
      // return {
      //   ...state,
      //   agency: state.agency.map((agency) => {
      //     return {
      //       ...agency,
      //       agency: agency.agency.filter(
      //         (agency) => agency._id !== action.payload
      //       ),
      //     };
      //   }),
      // };

      return {
        ...state,
        agency: state.agency.filter((agency) => agency._id !== action.payload),
      };

    case EDIT_AGENCY:
      return {
        ...state,
        agency: state.agency.map((agency) => {
          if (agency._id === action.payload.id) return action.payload.data;
          else return agency;
        }),
      };
    case OPEN_AGENCY_DIALOG:
      return {
        ...state,
        dialog: true,
        dialogData: action.payload || null,
      };
    case CLOSE_AGENCY_DIALOG:
      return {
        ...state,
        dialog: false,
        dialogData: null,
      };

    default:
      return state;
  }
};

export default agencyReducer;
