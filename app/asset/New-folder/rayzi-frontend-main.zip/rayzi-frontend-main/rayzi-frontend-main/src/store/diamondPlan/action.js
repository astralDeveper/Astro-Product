import axios from "axios";
import { Toast } from "../../util/Toast";
import {
    GET_Diamond_PLAN,
    CREATE_NEW_Diamond_PLAN,
    EDIT_Diamond_PLAN,
    DELETE_Diamond_PLAN,
    // OPEN_Diamond_PLAN_DIALOG,
    CLOSE_Diamond_PLAN_DIALOG,
    GET_Diamond_PLAN_HISTORY,
    ISTOP_SWITCH_TOGGLE
} from "./type"

import { apiInstanceFetch } from "../../util/api";

export const getDiamondPlan = () => (dispatch) => {
  apiInstanceFetch
    .get(`diamondPlan`)
    .then((res) => {
      if (res?.status) {
        dispatch({ type: GET_Diamond_PLAN, payload: res?.diamondPlan });
      }
    })
    .catch((error) => Toast("error", error.message));
};

export const createNewDiamondPlan = (data) => (dispatch) => {
  axios
    .post(`diamondPlan`, data)
    .then((res) => {
      if (res.data.status) {
        Toast("success", "Plan created successfully!");
        dispatch({ type: CLOSE_Diamond_PLAN_DIALOG });
        dispatch({ type: CREATE_NEW_Diamond_PLAN, payload: res.data.diamondPlan });
      } else {
        Toast("error", res.data.message);
      }
    })
    .catch((error) => Toast("error", error.message));
};
export const editDiamondPlan = (diamondPlanId, data) => (dispatch) => {
  axios
    .patch(`diamondPlan/${diamondPlanId}`, data)
    .then((res) => {
      if (res.data.status) {
        Toast("success", "Plan updated successfully!");
        dispatch({ type: CLOSE_Diamond_PLAN_DIALOG });
        dispatch({
          type: EDIT_Diamond_PLAN,
          payload: { data: res.data.diamondPlan, id: diamondPlanId },
        });
      } else {
        Toast("error", res.data.message);
      }
    })
    .catch((error) => Toast("error", error.message));
};
export const deleteDiamondPlan = (diamondPlanId) => (dispatch) => {
  axios
    .delete(`diamondPlan/${diamondPlanId}`)
    .then((res) => {
      if (res.data.status) {
        dispatch({ type: DELETE_Diamond_PLAN, payload: diamondPlanId });
      } else {
        Toast("error", res.data.message);
      }
    })
    .catch((error) => console.log(error));
};

export const DiamondPlanHistory =
  (id, start, limit, sDate, eDate) => (dispatch) => {
    const url =
      id !== null
        ? `diamondPlan/history?userId=${id}&start=${start}&limit=${limit}&startDate=${sDate}&endDate=${eDate}`
        : `diamondPlan/history?start=${start}&limit=${limit}&startDate=${sDate}&endDate=${eDate}`;
    apiInstanceFetch
      .get(url)
      .then((res) => {
        if (res.status) {
          dispatch({
            type: GET_Diamond_PLAN_HISTORY,
            payload: { history: res.data.history, total: res.total },
          });
        }
      })
      .catch((error) => console.log(error));
  };

export const isTop = (id) => (dispatch) => {
  apiInstanceFetch.get(`diamondPlan/isTopToggle?planId=${id}`).then((res) => {
    if (res.status) {
      debugger;
      dispatch({ type: ISTOP_SWITCH_TOGGLE, payload: res?.data });
      {
        res.data.isTop === true
          ? Toast("success", "Plan now top successfully!")
          : Toast("success", "Plan top Off successfully!");
      }
    } else {
      Toast("error", res.message);
    }
  });
};
