export const GET_Diamond_PLAN = "GET_Diamond_PLAN";
export const CREATE_NEW_Diamond_PLAN = "CREATE_NEW_Diamond_PLAN";
export const EDIT_Diamond_PLAN = "EDIT_Diamond_PLAN";
export const DELETE_Diamond_PLAN = "DELETE_Diamond_PLAN";

export const OPEN_Diamond_PLAN_DIALOG = "OPEN_Diamond_PLAN_DIALOG";
export const CLOSE_Diamond_PLAN_DIALOG = "CLOSE_Diamond_PLAN_DIALOG";

export const GET_Diamond_PLAN_HISTORY = "GET_Diamond_PLAN_HISTORY";

export const ISTOP_SWITCH_TOGGLE = "ISTOP_SWITCH_TOGGLE";
