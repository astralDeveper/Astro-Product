// import publics from "../../assets/images/male.png"

// export const Users = [
//   {
//     image : publics, 
//     username : 'haris ahmed' ,
//     gender : 'male' ,
//     rCoin : 12,
//     country : 'pakistan',
//     followers : 10 ,     
//     following : 6,
//     level : {name :30 }
// },  {
//   image :publics, 
//   username : 'aisha' ,
//   gender : 'female' ,
//   rCoin : 10,
//   country : 'saudia',
//   followers : 20,     
//   following : 17,
//   level : {name :30 }
// },
//   ]