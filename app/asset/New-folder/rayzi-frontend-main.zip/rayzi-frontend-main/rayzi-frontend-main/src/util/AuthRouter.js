import React from "react";
import { Redirect, Route } from "react-router-dom";

import { connect } from "react-redux";

const AuthRouter = ({ component: Component, isAuth, admin, ...rest }) => (
  <Route
    {...rest}
    render={(props) =>
      isAuth === true ? (admin.type === 'agency' ? <Redirect to="/agency/dashboard" /> : <Redirect to="/admin/dashboard" />) : <Component {...props} />
      
    }
  />  
);

const mapStateToProps = (state) => ({
  isAuth: state.admin.isAuth,
  admin: state.admin.admin
});

export default connect(mapStateToProps)(AuthRouter);
