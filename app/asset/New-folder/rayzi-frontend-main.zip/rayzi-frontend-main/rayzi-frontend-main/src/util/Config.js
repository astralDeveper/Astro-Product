// exports.baseURL = "http://localhost:5000/";
exports.baseURL = "https://livebroadcastingapp-2f9c47b9791e.herokuapp.com/";
exports.key = "SECRET_KEY";
