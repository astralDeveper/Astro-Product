import React, { useEffect, useState } from "react";
import { Link } from "react-router-dom";

import { Chart as ChartJS } from "chart.js/auto";
import { Line, Doughnut, Chart } from "react-chartjs-2";

//dayjs
import dayjs from "dayjs";

//datepicker
import DateRangePicker from "react-bootstrap-daterangepicker";
import "bootstrap-daterangepicker/daterangepicker.css";

// action
import { getAgencyDashboard, getAnalytic } from "../store/dashboard/action";
import { getSetting } from "../store/setting/action";
import { connect, useDispatch, useSelector } from "react-redux";

const AgencyDashboard = () => {
  let label = [];
  let data = [];
  let data1 = [];
  const [type, setType] = useState("USER");
  const dispatch = useDispatch();

  const dashboard = useSelector((state) => state.dashboard.dashboard);
  const agencyId = useSelector((state) => state.admin.admin.agencyId);
  
  var date = new Date();
  const [sDate, setSDate] = useState("ALL");
  const [eDate, setEDate] = useState("ALL");

  useEffect(() => {
    dispatch(getAgencyDashboard(agencyId));
  }, [dispatch]);


  const labelFormate = label?.map((item) => dayjs(item).format("DD-MM-YYYY"));
  
  const chartData = {
    labels: labelFormate,
    datasets: [
      {
        label: type?.toUpperCase(),
        data: data,
        fill: true,
        backgroundColor: "rgba(255, 99, 132, 0.1)",
        borderColor: "rgb(255, 99, 132)",
        lineTension: 0.5,
      },
    ],
  };
  const multiLineChartData = {
    labels: labelFormate,
    datasets: [
      {
        label: "Coin Revenue",
        data: data,
        fill: true,
        backgroundColor: "rgba(255, 99, 132, 0.1)",
        borderColor: "rgb(255, 99, 132)",
        lineTension: 0.5,
      },
      {
        label: "VIP Revenue",
        data: data1,
        fill: true,
        backgroundColor: "rgb(205,235,255,0.1)",
        borderColor: "#68B9F0",
        lineTension: 0.5,
      },
    ],
  };

  const optionsLine = {
    responsive: true,
    scales: {
      // x: {
      //   type: 'time',
      //   time: {
      //       parser: 'dd-mm-yyyy',
      //     tooltipFormat: 'dd-mm-yyyy',
      //     unit: 'day',
      //   },
      //   title: {
      //     display: true,
      //     text: 'Date',
      //   },
      // },
      y: {
        // Other Y-axis configuration options go here
      },
    },
  };
  // chartData.labels = chartData.labels.map((date) =>
  //   dayjs(date).format('DD-MM-YYYY')
  // );

  // multiLineChartData.labels = multiLineChartData.labels.map((date) =>
  //   dayjs(date).format('DD-MM-YYYY')
  // );

  const pieChartData = {
    maintainAspectRatio: false,
    responsive: false,
    labels: ["Total User"],
    datasets: [
      {
        data: [dashboard.users],
        backgroundColor: ["#e8538f"],
        hoverBackgroundColor: ["#e8538f"],
      },
    ],
  };

  //Apply button function for analytic
  const handleApply = (event, picker) => {
    picker.element.val(
      picker.startDate.format("YYYY-MM-DD") +
        " - " +
        picker.endDate.format("YYYY-MM-DD")
    );
    const dayStart = dayjs(picker.startDate).format("YYYY-MM-DD");

    const dayEnd = dayjs(picker.endDate).format("YYYY-MM-DD");

    setSDate(dayStart);
    setEDate(dayEnd);

    dispatch(getAnalytic(type, dayStart, dayEnd));
  };

  //Cancel button function for analytic
  const handleCancel = (event, picker) => {
    picker.element.val("");

    dispatch(getAnalytic(type, "ALL", "ALL"));
  };

  return (
    <>
      <div className="page-title">
        <div className="row">
          <div className="col-12 col-md-6 order-md-1 order-last">
            <h3 className="mb-3 text-white">Dashboard</h3>
          </div>
          <div className="col-12 col-md-6 order-md-2 order-first">
            <nav
              aria-label="breadcrumb"
              className="breadcrumb-header float-start float-lg-end"
            >
              <ol className="breadcrumb">
                <li className="breadcrumb-item">
                  <Link to="/admin/dashboard" className="text-danger">
                    Dashboard
                  </Link>
                </li>
              </ol>
            </nav>
          </div>
        </div>
      </div>
      <div class="row">
        <div class="col-lg-12 col-md-12 col-sm-12">
          <div class="row">
            <div class="col-lg-3 col-md-4 col-sm-6">
              <div class="card stats-card">
                <div class="card-body pointer-cursor">
                  <div class="stats-info">
                    <h5 class="card-title">
                      {dashboard.users ? dashboard.users.length : 0}
                      {/* <span class="stats-change stats-change-danger">-8%</span> */}
                    </h5>
                    <p class="stats-text">Total User</p>
                  </div>
                  <div class="stats-icon change-danger">
                    <i class="material-icons">people_alt</i>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* chart */}
      <h4 className="text-white">{type}</h4>
      <div className="d-flex justify-content-end">
        <DateRangePicker
          initialSettings={{
            autoUpdateInput: false,
            locale: {
              cancelLabel: "Clear",
            },
            maxDate: new Date(),
            buttonClasses: ["btn btn-dark"],
          }}
          onApply={handleApply}
          onCancel={handleCancel}
        >
          <input
            type="text"
            readOnly
            class="form-control float-left text-center"
            placeholder="Select Date"
            style={{ width: 195, fontWeight: 700 }}
          />
        </DateRangePicker>
      </div>

      {data?.length > 0 ? (
        type === "ACTIVE USER" ? (
          <div class="pie mt-3">
            <Doughnut data={pieChartData} options={{ responsive: true }} />
          </div>
        ) : type === "REVENUE" ? (
          <div class="pie mt-3">
            <div className="d-flex justify-content-end">
              <DateRangePicker
                initialSettings={{
                  autoUpdateInput: false,
                  locale: {
                    cancelLabel: "Clear",
                  },
                  maxDate: new Date(),
                  buttonClasses: ["btn btn-dark"],
                }}
                onApply={handleApply}
                onCancel={handleCancel}
              >
                <input
                  type="text"
                  readOnly
                  class="form-control float-left"
                  placeholder="Select Date"
                  style={{ width: 180, fontWeight: 700 }}
                />
              </DateRangePicker>
            </div>
            <Line data={multiLineChartData} options={{ responsive: true }} />
          </div>
        ) : (
          <div class="rows mt-3">
            <Line data={chartData} options={{ responsive: true }} />
          </div>
        )
      ) : (
        <p className="text-center">Chart not Available</p>
      )}
    </>
  );
};

export default connect(null, { getAgencyDashboard, getSetting, getAnalytic })(
  AgencyDashboard
);
