import React, { useEffect } from "react";

// js
import "../assets/js/main.min.js";

//router
import { Route, Switch, useHistory, useRouteMatch } from "react-router-dom";

// css
import "../assets/css/main.min.css";
import "../assets/css/custom.css";

// component
import Navbar from "../component/navbar/Navbar";
// import Topnav from "../component/navbar/Topnav";
import Topnav from "../component/navbar/Topnav.js";
import UserTable from "../component/table/User";
import Agencyuser from "../component/table/Agencyuser.js";
import UserDetail from "./UserDetail";
import UserHistory from "./UserHistory";
import Dashboard from "./Dashboard";
import Agencynavbar from "../component/navbar/Agencynav.js";
import AgencyDashboard from "./AgencyDashboard.js";
import AgencyRecharge from "./AgencyRecharge.js";

const Agency = () => {
  const location = useRouteMatch();
  const history = useHistory();

  useEffect(() => {
    if (
      history?.location?.pathname == "/" ||
      history?.location?.pathname == "/agency" ||
      history?.location?.pathname == ""
    ) {
      history.push("/agency/dashboard");
    }
  }, []);

  return (
    <>
      <div class="page-container">
        {/* <Navbar /> */}
        <Agencynavbar />
        <div class="page-content">
          <Topnav />
          <div class="main-wrapper">
            <Switch>
              <Route
                path={`${location.path}/dashboard`}
                exact
                component={AgencyDashboard}
              />
              <Route
                path={`${location.path}/user`}
                exact
                component={Agencyuser}
              />
              <Route
                path={`${location.path}/user/detail`}
                exact
                component={UserDetail}
              />
              <Route
                path={`${location.path}/user/history`}
                exact
                component={UserHistory}
              />
              <Route
                path={`${location.path}/recharge`}
                exact
                component={AgencyRecharge}
              />
            </Switch>
            {/* <Spinner /> */}
          </div>
        </div>
      </div>
    </>
  );
};

export default Agency;
