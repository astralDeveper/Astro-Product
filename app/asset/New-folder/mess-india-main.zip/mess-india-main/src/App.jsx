import React from "react";
import Routing from "./config/routing/Routing";
import { Provider } from "react-redux";
import { store } from "./redux/store";
import AuthContextProvider from "./Context/AuthContext";
// import { PersistGate } from "redux-persist/integration/react";

const App = () => {
  return (
    <Provider store={store}>
      <AuthContextProvider>
      {/* <PersistGate loading={null} persistor={persistor}> */}
        <Routing />
      {/* </PersistGate> */}
      </AuthContextProvider>
    </Provider>
  );
};

export default App;
