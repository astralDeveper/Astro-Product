import { BrowserRouter, Route, Routes, useNavigate } from "react-router-dom";
import Home from "../../screen/home/Home";
import SignIn from "../../screen/auth/SignIn";
import SignUp from "../../screen/auth/SignUp";
import AdminSignIn from "../../screen/admin/SignIn";
import Dashboard from "../../screen/Dashboard";
import Payment from "../../screen/payment/PaymentMethod";
import Home2 from "../../screen/home2/Home2";
import Cart from "../../screen/Cart";
import UserDetails from "../../components/UserDetails";
import UsersTable from "../../components/users/UsersTable";
import AddMenu from "../../components/AddMenu";
import Menu from "../../screen/Menu";
import { useContext, useEffect } from "react";
import { AuthContext } from "../../Context/AuthContext";
import { auth, db } from "../../firebase";
import UserRouteShell from "../../components/auth/RouteShell";
import UserAuthRouteShell from "../../components/auth/AuthRouteShell";
import AdminRouteShell from "../../components/admin/RouteShell";
import AdminAuthRouteShell from "../../components/admin/AuthRouteShell";
import { doc, getDoc } from "firebase/firestore";
import AllMealPlan from "../../screen/AllMealPlan/AllMealPlan";
import PasswordResetEmail from "../../screen/auth/PasswordResetEmail";
import SubscriptionTable from "../../components/SubscriptionTable";

const Routing = () => {
  const { setUser } = useContext(AuthContext);
  useEffect(() => {
    const unsubscribe = auth.onAuthStateChanged(async (userCredential) => {
      if (setUser) {
        if (userCredential) {
          const userDoc = await getDoc(doc(db, "users", userCredential.uid));
          const user = { ...userDoc.data() }
          const subscriptionDoc = await getDoc(doc(db, "subscription", userCredential.uid));

          if (subscriptionDoc.exists()) {
            user.subscription = { ...subscriptionDoc.data() }
          } else {
            user.subscription = null;
          }

          setUser(user);
        } else {
          setUser(null);
        }
      }
    });
    return () => unsubscribe();
  }, []);

  return (
    <BrowserRouter>
      <Routes>
        <Route path="/" element={<Home />} />
        <Route
          path="/login"
          element={
            <UserAuthRouteShell>
              <SignIn />
            </UserAuthRouteShell>
          }
        />

        <Route
          path="/signup"
          element={
            <UserAuthRouteShell>
              <SignUp />
            </UserAuthRouteShell>
          }
        />
        
        <Route
          path="/password-reset"
          element={
            <UserAuthRouteShell>
              <PasswordResetEmail />
            </UserAuthRouteShell>
          }
        />

        {/* <Route
          path="/admin/signup"
          element={
            <AuthRouteShell>
              <AdminSignUp />
            </AuthRouteShell>
          }
        /> */}
        {/* <Route
          path="/admin/login"
          element={
            <AdminAuthRouteShell>
              <AdminSignIn />
            </AdminAuthRouteShell>
          }
        /> */}
        <Route
          path="/dashboard"
          element={
            <AdminRouteShell>
              <Dashboard />
            </AdminRouteShell>
          }
        >
          <Route index={true} element={<AllMealPlan />} />
          <Route path="add-menu/:id" element={<AddMenu />} />
          <Route path="users" element={<UsersTable />} />
          <Route path="users/:id" element={<UserDetails />} />
          <Route path="subscriptions" element={<SubscriptionTable />} />
        </Route>

        <Route path="/payment" element={<Payment />} />
        <Route path="/menu/:id" element={<Home2 />} />

        <Route path="/menu" element={<Menu />} />

        <Route path="/cart" element={<Cart />} />
      </Routes>
    </BrowserRouter>
  );
};

export default Routing;
