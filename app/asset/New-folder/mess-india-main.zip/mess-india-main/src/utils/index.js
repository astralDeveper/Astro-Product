export function currencyFormatter(value) {
    return new Intl.NumberFormat('en-IN', { style: 'currency', currency: 'INR' }).format(value)
}
  
export function endDateOneMonthLater(startDate) {
    // Copy the startDate to avoid modifying the original date
    let endDate = new Date(startDate);
    
    // Get the current month and year
    let currentMonth = endDate.getMonth();
    let currentYear = endDate.getFullYear();
    
    // Add one month to the current month
    currentMonth += 1;
    
    // Check if the current month is December, if so, move to the next year and set the month to January
    if (currentMonth === 12) {
        currentYear += 1;
        currentMonth = 0; // January
    }
    
    // Set the new month and year to the endDate
    endDate.setMonth(currentMonth);
    endDate.setFullYear(currentYear);
    
    return endDate;
}

export async function fetchData(url, data) {
    const options = {
        method: "POST",
        headers: new Headers({ "Content-Type": "application/json" }),
        body: JSON.stringify(data),
      };

    const res = await fetch(url, options);
    return res;
}

export async function createOrder(price, planId, user) {
  const res = await fetchData("/.netlify/functions/create-order", {
    price: price,
    planId: planId,
    userId: user.id,
    email: user.email,
    name: user.name,
  });

  if (res.ok) {
    const json = await res.json();
    return json.order;
  } else {
    throw new Error("Error creating order");
  }
};

export async function verifySignature(signature, paymentId, orderId, user) {
  const res = await fetchData("/.netlify/functions/create-subscription", {
    signature,
    userId: user.id,
    orderId,
    paymentId,
  });

  if (res.ok) {
    const json = await res.json();
    return json.verified;
  } else {
    throw new Error("Error creating order");
  }
};