import { createSlice } from '@reduxjs/toolkit'

const initialState = {
  items: []
}

export const cartSlice = createSlice({
  name: 'cart',
  initialState,
  reducers: {
    increment: (state, action) => {
      const item = state.items.find((el) => el.id === action.payload.id && el.title === action.payload.title);
      item.quantity = item.quantity + 1;
    },
    decrement: (state, action) => {
      const item = state.items.find((el) => el.id === action.payload.id && el.title === action.payload.title);
      item.quantity = item.quantity > 0 ? item.quantity - 1 : item.quantity;
    },
    addItem: (state, action) => {
      if (state.items.length === 0) state.items.push({ ...action.payload, quantity: 1});
      else {
        if (state.items.some(item => item.id === action.payload.id && item.title === action.payload.title)) {
          const item = state.items.find((el) => el.id === action.payload.id && el.title === action.payload.title);
          item.quantity = item.quantity + 1;
        } else {
          state.items.push({ ...action.payload, quantity: 1});
        }
      }

      // if (state.items.length === 0) state.items.push(action.payload);
      // else {
      //   if (state.items.some(item => item.id === action.payload.id)) {
      //     const item = state.items.find((el) => el.id === action.payload.id);
      //     item.quantity = item.quantity + 1;
      //   } else {
      //     state.items.push(action.payload);
      //   }
      // }

    },
    removeItem: (state, action) => {
      const newState = { items: state.items.filter((el) => el.id !== action.payload.id || el.title !== action.payload.title)};
      return newState;
    }
  },
})

export const { increment, decrement, removeItem, addItem } = cartSlice.actions;
export default cartSlice.reducer