import { createSlice } from "@reduxjs/toolkit";

const AuthSlice = createSlice({
    name:"AuthSlice",
    initialState:{
        user:null
    },
    reducers:{
        setUser:(state,action)=>{
            state.user = action.payload
        },
        logoutUser:(state)=>{
            state.user = null
        },
    }
});

export const {setUser,logoutUser} = AuthSlice.actions;
export default AuthSlice.reducer;