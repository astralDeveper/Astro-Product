import { configureStore } from "@reduxjs/toolkit";
import storage from "redux-persist/lib/storage";
import RootReducer from "./rootReducer";
import cartReducer from "./reducers/CartSlice";

import {
  persistStore,
  persistReducer,
  FLUSH,
  REHYDRATE,
  PAUSE,
  PERSIST,
  PURGE,
  REGISTER,
} from 'redux-persist'

const persistConfig = {
  key: "root",
  storage,
};

// const persistedReducer = persistReducer(persistConfig, RootReducer);

const store = configureStore({
  reducer: {
    // persistedReducer,
    cart: cartReducer
  },
  // middleware: (getDefaultMiddleware) => getDefaultMiddleware({
  //     serializableCheck: {
  //       ignoredActions: [FLUSH, REHYDRATE, PAUSE, PERSIST, PURGE, REGISTER],
  //     },
  //   }),
});

// const persistor = persistStore(store);

export { store };
