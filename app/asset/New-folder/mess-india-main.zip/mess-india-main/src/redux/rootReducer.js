import { combineReducers } from "@reduxjs/toolkit"
import AuthSlice from "./reducers/AuthSlice"
// import CartSlice from "./reducers/CartSlice"

const RootReducer = combineReducers({ AuthSlice });
export default RootReducer;