import React from 'react'
import Header from '../../components/Header'
import Sidebar from '../../components/SideBar'
import UsersTable from '../../components/users/UsersTable'

const Users = () => {
  return (
    <div>
      <div className="bg-neutral-100 h-screen w-screen overflow-hidden grid grid-cols-1 lg:grid-cols-12">
        <div className=' hidden lg:block lg:col-span-3 2xl:col-span-2 h-screen'>
          <Sidebar />
        </div>

        <div className="flex flex-col md:col-span-8 lg:col-span-9 2xl:col-span-10 h-screen overflow-auto">
          <Header />
          <div className="p-2 lg:p-4 bg-[#FFFEF9] flex-1">
            <UsersTable/>
          </div>
        </div>
      </div>
    </div>
  )
}

export default Users