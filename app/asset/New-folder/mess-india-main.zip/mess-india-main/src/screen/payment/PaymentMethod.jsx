import Payment from '../../components/Payment'

const PaymentMethod = () => {
  return (
    <div>
      <Payment/>
    </div>
  )
}

export default PaymentMethod