import React, { useEffect, useState } from "react";
import HomeSec2Card from "../../components/HomeSec2Card";
import { getData } from "../../firebase";

const AllMealPlan = () => {
  const [mealsData, setMealsData] = useState(null);

  useEffect(() => {
    getData("mealPlans")
      .then((res) => {
        setMealsData(res);
      })
      .catch((err) => {
        console.log(err);
      });
  }, []);

  return (
    <>
      <div className="mt-24">
        {/* <p className="text-4xl font-bold text-center">
        Today <span className="text-[#87548C]">special</span> offers
      </p> */}
        {/* <img className="h-32" src={img} alt=" " /> */}

        <div className="flex justify-center">
          <div className="flex flex-wrap w-[80%] justify-center gap-14">
            {mealsData &&
              mealsData.map((item, i) => (
                <HomeSec2Card
                  key={i}
                  image={item.image}
                  id={item.id}
                  para={item.title}
                  price={item.price}
                  link={`/dashboard/add-menu/${item.id}`}
                />
              ))}
          </div>
        </div>
      </div>
    </>
  );
};

export default AllMealPlan;
