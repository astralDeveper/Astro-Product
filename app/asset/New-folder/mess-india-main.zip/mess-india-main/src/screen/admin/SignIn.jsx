import React, { useContext, useState } from "react";
import bike from "../../assets/bike.png";
import logo from "../../assets/main-logo.png";
import fruit from "../../assets/8.png";
import bowl from "../../assets/bowl.png";
import girl from "../../assets/girl-with-mobile.png";
import { useNavigate } from "react-router-dom";
import Notification from "../../components/Notification";
import { signInWithEmailAndPassword } from "firebase/auth";
import { auth } from "../../firebase";
import { AuthContext } from "../../Context/AuthContext";

const SignIn = () => {
  const { setUser } = useContext(AuthContext);

  const [formData, setFormData] = useState({
    email: "",
    password: "",
  });

  const navigate = useNavigate();

  const [showAlert, setShowAlert] = useState(false);

  const [alert, setAlert] = useState({
    type: "",
    message: "",
  });

  const handleSubmit = async (e) => {
    try {
      e.preventDefault();

      let { email, password } = formData;

      if (!email.trim().length || !password.trim().length) {
        setAlert({
          type: "error",
          message: "Email and password are required.",
        });
        setShowAlert(true);
        return;
      }

      let credentials = await signInWithEmailAndPassword(auth, email, password);


      if (setUser) {
        setUser(credentials.user);
        setAlert({
          type: "success",
          message: "Login Successful.",
        });
        setShowAlert(true);
        navigate("/dashboard");
      }
    } catch (error) {
      setAlert({
        type: "error",
        message: "Unexpected error occured.",
      });
      setShowAlert(true);
    }
  };

  return (
    <>
      <Notification
        open={showAlert}
        setOpen={setShowAlert}
        type={alert.type}
        message={alert.message}
      />
      <div className="flex h-[100vh] w-screen">
        <div className="h-full w-[50%] main-div absolute">
          <img className="h-12 mt-5 ml-5 max-[600px]:h-8" src={logo} alt="" />
          <img
            className="h-[200px] ml-[20vw] mt-[10vh] max-[700px]:hidden"
            src={bike}
            alt=""
          />
          <img
            className="h-[100px] absolute bottom-16 ml-10 max-[700px]:hidden"
            src={fruit}
            alt=""
          />
        </div>

        <div className="h-full w-[50%] absolute right-0 flex flex-col justify-center items-end">
          <img
            className="h-[100px] mr-16 max-[700px]:hidden"
            src={bowl}
            alt=""
          />
          <img className="h-[400px] max-[700px]:hidden" src={girl} alt="" />
        </div>
      </div>

      <div className="flex items-center justify-center absolute inset-0 max-[700px]:mt-8 max-[600px]:mt-10 transition-all mx-5">
        <div className="relative bg-white shadow-2xl h-auto w-[400px] rounded-3xl p-8">
          <h2 className="text-[#7F4A84] font-semibold text-3xl">Sign In</h2>
          <p className="text-[11px] mt-3">
            Please enter your credentials to access your account.
          </p>

          <form className="w-full mt-8" onSubmit={handleSubmit}>
            <label className="text-sm font-semibold">Email address</label>
            <input
              className="border-2 w-full mt-2 p-1 rounded-lg outline-none focus:border-[#FE854E] text-sm px-2 transition-all"
              type="type"
              required
              autoComplete="email"
              autoCorrect="email"
              placeholder="Enter your email"
              value={formData.email}
              onChange={(e) =>
                setFormData((s) => ({ ...s, email: e.target.value }))
              }
            />
            <label className="text-sm mt-6 font-semibold">Password</label>
            <input
              className="border-2 w-full mt-2 p-1 rounded-lg outline-none focus:border-[#FE854E] text-sm px-2 transition-all"
              type="password"
              required
              autoComplete="password"
              placeholder="Enter your password"
              value={formData.password}
              minLength={6}
              maxLength={40}
              onChange={(e) =>
                setFormData((s) => ({ ...s, password: e.target.value }))
              }
            />
            <h5 className="text-right text-[12px] mt-2 text-[#E60000] cursor-pointer font-semibold">
              Forgot Password?
            </h5>
            <button
              type="submit"
              className="text-center bg-[#FE854E] w-full mt-4 p-2 text-white font-semibold rounded-xl"
            >
              Sign In
            </button>
          </form>

          {/* <div className="flex justify-evenly items-center mt-3">
            <img className="w-[30%]" src={line} alt="" />
            <h2 className="font-semibold text-[#ABABAB]">OR</h2>
            <img className="w-[30%]" src={line} alt="" />
          </div>

          <div className="flex justify-evenly mt-3 flex-wrap">
            <button className="flex  items-center gap-3 bg-[#FFF4E3] p-3 px-5 rounded-lg max-[600px]:w-full max-[600px]:justify-center">
              <img className="w-5" src={google} alt="" />
              <h3 className="text-[#B87514] text-sm">Sign in with Google</h3>
            </button>

            <div className="flex justify-center max-[600px]:w-full gap-2 max-[600px]:mt-2">
              <button className="flex  items-center gap-3 bg-[#FFF4E3] p-3 rounded-lg max-[600px]:w-[50%] max-[600px]:justify-center">
                <img className="w-5" src={facebook} alt="" />
                <h3 className="text-[#0c87ee] text-sm hidden max-[600px]:block">
                  Facebook
                </h3>
              </button>

              <button className="flex  items-center gap-3 bg-[#FFF4E3] p-3 rounded-lg max-[600px]:w-[50%] max-[600px]:justify-center">
                <img className="w-5" src={apple} alt="" />
                <h3 className="text-[#283544] text-sm hidden max-[600px]:block">
                  Apple
                </h3>
              </button>
            </div>
          </div> */}

          {/* <p className="text-sm text-center mt-6">
            Have an Account ?{" "}
            <span className="text-[#B87514] cursor-pointer">
              <Link to={"/signup"}>Sign Up</Link>
            </span>
          </p> */}
        </div>
      </div>
    </>
  );
};

export default SignIn;
