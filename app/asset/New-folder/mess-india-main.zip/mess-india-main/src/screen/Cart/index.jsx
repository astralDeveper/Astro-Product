import { useContext, useState } from "react";
import { Link, Navigate, useLocation } from "react-router-dom";
import { AuthContext } from "../../Context/AuthContext";
import Navbar from "../../components/Navbar";
import { createOrder, currencyFormatter, verifySignature } from "../../utils";
import AlertModal from "../../components/AlertModal";
import { createSubscription } from "../../firebase";

export default function Cart() {
  const location = useLocation();
  const { user } = useContext(AuthContext);

  const [alertMessage, setAlertMessage] = useState("");
  const [open, setOpen] = useState(false);

  const handleCheckoutBtn = async () => {
    let order;
    try {
      order = await createOrder(location.state.item.price, location.state.item.id, user);
    } catch (err) {
      setAlertMessage("Something went wrong, Try again later");
      setOpen(true);
    }

    if (!order) return;

    const options = {
      key: import.meta.env.VITE_RAZORPAY_APIKEYID,
      amount: location.state.item.price * 100,
      currency: "INR",
      name: location.state.item.title,
      image: location.state.item.image,
      order_id: order.id,
      handler: async function (res) {
        const verified = await verifySignature(res.razorpay_signature, res.razorpay_payment_id, res.razorpay_order_id, user);
        if (verified) {
          await createSubscription({
            userId: user.id,
            mealPlanId: location.state.item.id,
            price: location.state.item.price,
            paymentId: res.razorpay_payment_id,
            orderId: res.razorpay_order_id,
            signature: res.razorpay_signature,
          });

          setAlertMessage("Your order was successfully placed");
          setOpen(true);
        } else {
          setAlertMessage("Something went wrong, Try again later");
          setOpen(true);
        }
      },
      prefill: {
        name: user.name,
        email: user.email,
      },
      theme: {
        color: "#FA8232",
      },
    };
    const rzp1 = new Razorpay(options);
    rzp1.open();
  };

  if (!user) return <Navigate to="/login" replace />;

  return (
    <div className="bg-[#FFFEF9]">
      <Navbar />

      <main>
        <div className="max-w-screen-xl mx-auto min-h-screen px-4">
          <h1 className="text-3xl font-semibold">Checkout Details</h1>

          <div className="grid grid-cols-[3fr_1fr] max-lg:grid-cols-1 gap-4 mt-14">
            <div className="overflow-x-auto bg-white border max-sm:text-sm">
              <table className="w-full border-b">
                <thead className="bg-zinc-100 text-zinc-700">
                  <tr className="*:p-2 *:font-medium uppercase *:text-start">
                    <th>Products</th>
                    <th>Price</th>
                    <th>Quantity</th>
                    {/* <th>Sub-total</th> */}
                  </tr>
                </thead>
                <tbody>
                  {/* {cartItems?.map((item, i) => (<CartItem item={item} key={i} />))} */}
                  {location.state.item && ( <CartItem item={location.state.item} />)}
                </tbody>
              </table>

              <div className="flex justify-between p-6">
                <Link
                  to={-1}
                  className="border-2 border-[#FDC55E] p-2 text-[#FDC55E] uppercase font-medium"
                >
                  Return to menu
                </Link>
                {/* <button className="border-2 border-[#FDC55E] p-2 text-[#FDC55E] uppercase font-medium">
                  Update cart
                </button> */}
              </div>
            </div>

            <div className="bg-white border p-2">
              <h2 className="text-xl font-medium">Cart totals</h2>

              <div className="mt-8 py-2 border-b">
                <ul className="flex flex-col gap-2 text-sm">
                  <li className="flex justify-between">
                    <span className="text-zinc-500">Sub-total</span>
                    {/* <span className="font-medium">{currencyFormatter(cartItems?.reduce((acc, item) => acc + (item.price * 1), 0))}</span> */}
                    <span className="font-medium">
                      {currencyFormatter(location.state.item.price)}
                    </span>
                  </li>
                  {/* <li className="flex justify-between">
                    <span className="text-zinc-500">Shipping</span>
                    <span className="font-medium">Free</span>
                  </li> */}
                  {/* <li className="flex justify-between">
                    <span className="text-zinc-500">Discount</span>
                    <span className="font-medium">{currencyFormatter(discount)}</span>
                  </li> */}
                  {/* 
                  <li className="flex justify-between">
                    <span className="text-zinc-500">Tax</span>
                    <span className="font-medium">{currencyFormatter(tax)}</span>
                  </li> */}
                </ul>
              </div>

              <div className="flex justify-between text-lg font-semibold mt-2">
                <p>Total</p>
                <p>{calculateTotal(location.state.item.price, 0, 0)}</p>
                {/* <p>{calculateTotal(cartItems?.reduce((acc, item) => acc + (item.price * 1), 0), discount, tax)}</p> */}
              </div>

              <button
                onClick={handleCheckoutBtn}
                className="block text-center p-2 bg-[#FA8232] text-white uppercase font-semibold w-full mt-12"
              >
                Proceed to checkout
              </button>
            </div>
          </div>
        </div>
        <AlertModal
          open={open}
          onclose={() => setOpen(false)}
          message={alertMessage}
        />
      </main>
    </div>
  );
}

function CartItem({ item }) {
  // const dispatch = useDispatch()

  return (
    <tr className="*:p-2">
      <td>
        <div className="flex gap-4 items-center max-sm:gap-2">
          {/* <button onClick={() => dispatch(removeItem({ id: item.id, title: item.title }))} className="p-1 border border-red-500 rounded-full self-center size-6 flex justify-center items-center">
            <Close fontSize="18" className="text-red-500" />
          </button> */}
          <img
            src={item.image}
            alt=""
            className="size-16 max-sm:size-8 rounded-full"
          />
          <div className="flex flex-col gap-1 max-w-80 text-start">
            <p className="font-medium">{item.title}</p>
            {/* <p className="line-clamp-2">{item.description}</p> */}
          </div>
        </div>
      </td>

      <td>
        <p>{currencyFormatter(item.price)}</p>
      </td>

      <td>
        <p className="p-2 max-sm:p-1">1</p>
        {/* <div className="flex border justify-between">
          <button onClick={() => dispatch(decrement({ id: item.id, title: item.title }))} className="p-2 max-sm:p-1">
            <Remove fontSize="18" />
          </button>
          <button onClick={() => dispatch(increment({ id: item.id, title: item.title }))} className="p-2 max-sm:p-1">
            <Add fontSize="18" />
          </button>
        </div> */}
      </td>

      {/* <td>
        <p>{currencyFormatter(1 * item.price)}</p>
      </td> */}
    </tr>
  );
}

function calculateTotal(value, discount, tax) {
  if (value === 0) return currencyFormatter(value);
  return currencyFormatter(value - discount + tax);
}
