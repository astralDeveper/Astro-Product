import React, { useContext, useState } from "react";
import bike from "../../assets/bike.png";
import logo from "../../assets/main-logo.png";
import fruit from "../../assets/8.png";
import bowl from "../../assets/bowl.png";
import girl from "../../assets/girl-with-mobile.png";
import { sendPasswordResetEmail } from "firebase/auth";
import { auth } from "../../firebase";
import AlertModal from "../../components/AlertModal";

const PasswordResetEmail = () => {
  const [alertMessage , setAlertMessage] = useState()
  const [open , setOpen] = useState(false)


  const [formData, setFormData] = useState({
    email: "",
  });

  const handleSubmit = async (e) => {
    try {
      e.preventDefault();

      await sendPasswordResetEmail(auth, formData.email);

      setAlertMessage("Your password reset link has been sent on your email")
      setOpen(true)

    } catch (error) {
      setAlertMessage("Something went wrong, Try again later")
      setOpen(true)
    }
  };

  return (
    <>
      <div className="flex h-[100vh] w-screen">
        <div className="h-full w-[50%] main-div absolute">
          <img className="h-12 mt-5 ml-5 max-[600px]:h-8" src={logo} alt="" />
          <img
            className="h-[200px] ml-[20vw] mt-[10vh] max-[700px]:hidden"
            src={bike}
            alt=""
          />
          <img
            className="h-[100px] absolute bottom-16 ml-10 max-[700px]:hidden"
            src={fruit}
            alt=""
          />
        </div>

        <div className="h-full w-[50%] absolute right-0 flex flex-col justify-center items-end">
          <img
            className="h-[100px] mr-16 max-[700px]:hidden"
            src={bowl}
            alt=""
          />
          <img className="h-[400px] max-[700px]:hidden" src={girl} alt="" />
        </div>
      </div>

      <div className="flex items-center justify-center absolute inset-0 max-[700px]:mt-8 max-[600px]:mt-10 transition-all mx-5">
        <div className="relative bg-white shadow-2xl h-auto w-[400px] rounded-3xl p-8">
          <h2 className="text-[#7F4A84] font-semibold text-3xl">Password Reset</h2>
          <p className="text-[11px] mt-3">
            Please enter your email address associated with your account.
          </p>

          <form className="w-full mt-8" onSubmit={handleSubmit}>
            <label className="text-sm font-semibold">Email address</label>
            <input
              className="border-2 w-full mt-0.5 p-1.5 rounded-lg outline-none focus:border-[#FE854E] text-sm px-2 transition-all"
              type="email"
              required
              autoComplete="email"
              autoCorrect="email"
              placeholder="Enter your email"
              value={formData.email}
              onChange={(e) =>
                setFormData((s) => ({ ...s, email: e.target.value }))
              }
            />
            <button
              type="submit"
              className="text-center bg-[#FE854E] w-full mt-4 p-2 text-white font-semibold rounded-xl"
            >
              Send email
            </button>
          </form>
        </div>
      </div>

      <AlertModal open={open} onclose={()=>setOpen(false)} message={alertMessage}/>

    </>
  );
};

export default PasswordResetEmail;