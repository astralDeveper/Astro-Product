import Home2Sec1 from '../../components/Home2Sec1'
import Home2Sec2 from '../../components/Home2Sec2'
import Footer from '../../components/Footer'
import { useParams } from 'react-router-dom'
import { useEffect, useState } from 'react'
import { getSingleDoc } from '../../firebase'

const Home2 = () => {
  const {id} = useParams();

  const [mealPlan, setMealPlan] = useState(null);
  
  useEffect(() => {
    getSingleDoc('mealPlans', id).then((res) => {
      setMealPlan(res);
    })
  }, [])

  if (!mealPlan) return null;
  return (
    <>
        <Home2Sec1 item={mealPlan} />
        <Home2Sec2 item={mealPlan} />
        <Footer/>
    </>
  )
}

export default Home2
