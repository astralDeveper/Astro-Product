import { Add } from "@mui/icons-material";
import logo from "../../assets/main-logo.png";
import circleImage from "../../assets/home2Sec1.png"
import steak from "../../assets/form2.png"
import { useDispatch } from "react-redux"
import { addItem } from "../../redux/reducers/CartSlice";
import { Link } from "react-router-dom";
import Footer from "../../components/Footer";

export default function Menu() {
  const today = getDayOfWeek().toLocaleLowerCase();

  return (
    <>
      <header className="">
        <div className="max-w-screen-xl mx-auto p-2 flex justify-between items-center">
          <img className="h-12" src={logo} alt="logo" />
        </div>

        <div className="max-w-screen-xl mx-auto flex mt-20 md:40 px-4">
          <div className="grid grid-cols-1 gap-x-4 gap-y-20 md:grid-cols-2 w-full">
            <div className="">
              <h1 className="text-4xl md:text-5xl font-bold mt-12 md:mt-24">
                {menu.title}
              </h1>

              <p className="text-3xl md:text-4xl text-[#87548C] font-bold mt-6 self-start">
                {menu.price}
              </p>
            </div>

            <div className="self-center justify-self-center">
              <div className='flex bg-gradient-to-b from-[#FDC55E] to-[#F54748] w-full max-w-[400px] mx-auto p-4 items-center justify-center rounded-full'>
                <img className="w-full max-w-96 object-contain" src={circleImage} alt="pilate" />
              </div>
            </div>
          </div>
        </div>
      </header>


      <main className="mt-48">
        <h2 className="text-4xl md:text-5xl text-center font-bold capitalize">
          {today}
        </h2>

        <div className="mt-16 max-w-screen-xl mx-auto px-4">
          <h3 className="font-semibold text-center text-3xl md:text-4xl">
            Breakfast <span className="text-[#FDC55E]">(8:00 to 9:00)</span>
          </h3>
          
          <div className="grid grid-cols-1 gap-4 gap-y-10 md:grid-cols-2 mt-20">
            <DayItems item={menu.menu[today].breakfast.item1} price={menu.price} menu={menu.title} id={menu.id} />
            <DayItems item={menu.menu[today].breakfast.item2} price={menu.price} menu={menu.title} id={menu.id} />
          </div>
        </div>
        
        <div className="mt-16 max-w-screen-xl mx-auto px-4">
          <h3 className="font-semibold text-center text-3xl md:text-4xl">
            Lunch <span className="text-[#FDC55E]">(12:00 to 1:00)</span>
          </h3>
          
          <div className="grid grid-cols-1 gap-4 gap-y-10 md:grid-cols-2 mt-20">
            <DayItems item={menu.menu[today].lunch.item1} price={menu.price} menu={menu.title} id={menu.id} />
            <DayItems item={menu.menu[today].lunch.item2} price={menu.price} menu={menu.title} id={menu.id} />
          </div>
        </div>
        
        <div className="mt-16 max-w-screen-xl mx-auto px-4">
          <h3 className="font-semibold text-center text-3xl md:text-4xl">
            Dinner <span className="text-[#FDC55E]">(7:00 to 8:00)</span>
          </h3>
          
          <div className="grid grid-cols-1 gap-4 gap-y-10 md:grid-cols-2 mt-20">
            <DayItems item={menu.menu[today].dinner.item1} price={menu.price} menu={menu.title} id={menu.id} />
            <DayItems item={menu.menu[today].dinner.item2} price={menu.price} menu={menu.title} id={menu.id} />
          </div>
        
        
          <Link to="/cart" className="bg-[#FE854E] hover:bg-[#e67845] transition-colors text-lg rounded-md p-2 max-w-80 w-full block mx-auto text-white font-medium text-center mt-24">
            Cart
          </Link>
        </div>

        <Footer />
      </main>
    </>
  )
}

function DayItems({ item, price, title, id }) {
  const dispatch = useDispatch();

  return (
    <article className="grid grid-cols-[auto_1fr_auto] max-w-xl w-full mx-auto">
      <div className="flex size-28 items-center justify-center self-center rounded-full bg-gradient-to-r from-[#f5474736] from-0% to-transparent to-50% p-1 md:size-36 md:p-2">
        <div className="p-2 md:p-1 bg-[#fff6e41f] rounded-full">
          <img src={item.img} alt="" className=" w-full object-cover" />
        </div>
      </div>
      <div className="p-3 pr-10 bg-gradient-to-l from-[#ffdddd] to-transparent rounded-xl self-center">
        <p className="font-medium text-base sm:text-lg">{item.title}</p>
        <p className="line-clamp-2 text-sm sm:text-base">{item.description}</p>
      </div>

      <div className="self-center -translate-x-1/2">
        <button onClick={() => dispatch(addItem({ ...item, price, menu: title, id }))} className='size-14 flex justify-center bg-[#FDC55E] items-center rounded-full shadow-xl hover:scale-110 transition-all hover:bg-[#e4b04f] active:scale-100'>
          <span className='text-4xl font-semibold text-white'>
            <Add />
          </span>
        </button>
      </div>
    </article>
  )
}

function getDayOfWeek() {
  const dayOfWeek = new Date().getDay();
  return isNaN(dayOfWeek) ? null : ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'][dayOfWeek];
}

const menu = {
  id: "1234567890",
  title: 'Mess Non Veg (All Days)',
  price: 4500,
  menu: {
    monday: {
      breakfast: {
        item1: {
          title: 'Steak and Eggs',
          img: steak,
          description: 'Grilled steak served with sunny-side-up eggs, roasted potatoes.',
        },
        item2: {
          title: 'Classic Bacon and Eggs',
          img: steak,
          description: 'Served with toast, hash browns, or roasted tomatoes.',
        }
      },
      lunch: {
        item1: {
          title: 'Steak and Eggs',
          img: steak,
          description: 'Grilled steak served with sunny-side-up eggs, roasted potatoes.',
        },
        item2: {
          title: 'Classic Bacon and Eggs',
          img: steak,
          description: 'Served with toast, hash browns, or roasted tomatoes.',
        }
      },
      dinner: {
        item1: {
          title: 'Steak and Eggs',
          img: steak,
          description: 'Grilled steak served with sunny-side-up eggs, roasted potatoes.',
        },
        item2: {
          title: 'Classic Bacon and Eggs',
          img: steak,
          description: 'Served with toast, hash browns, or roasted tomatoes.',
        }
      },
    },
    tuesday: {
      breakfast: {
        item1: {
          title: 'Steak and Eggs',
          img: steak,
          description: 'Grilled steak served with sunny-side-up eggs, roasted potatoes.',
        },
        item2: {
          title: 'Classic Bacon and Eggs',
          img: steak,
          description: 'Served with toast, hash browns, or roasted tomatoes.',
        }
      },
      lunch: {
        item1: {
          title: 'Steak and Eggs',
          img: steak,
          description: 'Grilled steak served with sunny-side-up eggs, roasted potatoes.',
        },
        item2: {
          title: 'Classic Bacon and Eggs',
          img: steak,
          description: 'Served with toast, hash browns, or roasted tomatoes.',
        }
      },
      dinner: {
        item1: {
          title: 'Steak and Eggs',
          img: steak,
          description: 'Grilled steak served with sunny-side-up eggs, roasted potatoes.',
        },
        item2: {
          title: 'Classic Bacon and Eggs',
          img: steak,
          description: 'Served with toast, hash browns, or roasted tomatoes.',
        }
      },
    },
    wednesday: {
      breakfast: {
        item1: {
          title: 'Steak and Eggs',
          img: steak,
          description: 'Grilled steak served with sunny-side-up eggs, roasted potatoes.',
        },
        item2: {
          title: 'Classic Bacon and Eggs',
          img: steak,
          description: 'Served with toast, hash browns, or roasted tomatoes.',
        }
      },
      lunch: {
        item1: {
          title: 'Steak and Eggs',
          img: steak,
          description: 'Grilled steak served with sunny-side-up eggs, roasted potatoes.',
        },
        item2: {
          title: 'Classic Bacon and Eggs',
          img: steak,
          description: 'Served with toast, hash browns, or roasted tomatoes.',
        }
      },
      dinner: {
        item1: {
          title: 'Steak and Eggs',
          img: steak,
          description: 'Grilled steak served with sunny-side-up eggs, roasted potatoes.',
        },
        item2: {
          title: 'Classic Bacon and Eggs',
          img: steak,
          description: 'Served with toast, hash browns, or roasted tomatoes.',
        }
      },
    },
    thursday: {
      breakfast: {
        item1: {
          title: 'Steak and Eggs',
          img: steak,
          description: 'Grilled steak served with sunny-side-up eggs, roasted potatoes.',
        },
        item2: {
          title: 'Classic Bacon and Eggs',
          img: steak,
          description: 'Served with toast, hash browns, or roasted tomatoes.',
        }
      },
      lunch: {
        item1: {
          title: 'Steak and Eggs',
          img: steak,
          description: 'Grilled steak served with sunny-side-up eggs, roasted potatoes.',
        },
        item2: {
          title: 'Classic Bacon and Eggs',
          img: steak,
          description: 'Served with toast, hash browns, or roasted tomatoes.',
        }
      },
      dinner: {
        item1: {
          title: 'Steak and Eggs',
          img: steak,
          description: 'Grilled steak served with sunny-side-up eggs, roasted potatoes.',
        },
        item2: {
          title: 'Classic Bacon and Eggs',
          img: steak,
          description: 'Served with toast, hash browns, or roasted tomatoes.',
        }
      },
    },
    friday: {
      breakfast: {
        item1: {
          title: 'Steak and Eggs',
          img: steak,
          description: 'Grilled steak served with sunny-side-up eggs, roasted potatoes.',
        },
        item2: {
          title: 'Classic Bacon and Eggs',
          img: steak,
          description: 'Served with toast, hash browns, or roasted tomatoes.',
        }
      },
      lunch: {
        item1: {
          title: 'Steak and Eggs',
          img: steak,
          description: 'Grilled steak served with sunny-side-up eggs, roasted potatoes.',
        },
        item2: {
          title: 'Classic Bacon and Eggs',
          img: steak,
          description: 'Served with toast, hash browns, or roasted tomatoes.',
        }
      },
      dinner: {
        item1: {
          title: 'Steak and Eggs',
          img: steak,
          description: 'Grilled steak served with sunny-side-up eggs, roasted potatoes.',
        },
        item2: {
          title: 'Classic Bacon and Eggs',
          img: steak,
          description: 'Served with toast, hash browns, or roasted tomatoes.',
        }
      },
    },
    saturday: {
      breakfast: {
        item1: {
          title: 'Steak and Eggs',
          img: steak,
          description: 'Grilled steak served with sunny-side-up eggs, roasted potatoes.',
        },
        item2: {
          title: 'Classic Bacon and Eggs',
          img: steak,
          description: 'Served with toast, hash browns, or roasted tomatoes.',
        }
      },
      lunch: {
        item1: {
          title: 'Steak and Eggs',
          img: steak,
          description: 'Grilled steak served with sunny-side-up eggs, roasted potatoes.',
        },
        item2: {
          title: 'Classic Bacon and Eggs',
          img: steak,
          description: 'Served with toast, hash browns, or roasted tomatoes.',
        }
      },
      dinner: {
        item1: {
          title: 'Steak and Eggs',
          img: steak,
          description: 'Grilled steak served with sunny-side-up eggs, roasted potatoes.',
        },
        item2: {
          title: 'Classic Bacon and Eggs',
          img: steak,
          description: 'Served with toast, hash browns, or roasted tomatoes.',
        }
      },
    },
    sunday: {
      breakfast: {
        item1: {
          title: 'Steak and Eggs',
          img: steak,
          description: 'Grilled steak served with sunny-side-up eggs, roasted potatoes.',
        },
        item2: {
          title: 'Classic Bacon and Eggs',
          img: steak,
          description: 'Served with toast, hash browns, or roasted tomatoes.',
        }
      },
      lunch: {
        item1: {
          title: 'Steak and Eggs',
          img: steak,
          description: 'Grilled steak served with sunny-side-up eggs, roasted potatoes.',
        },
        item2: {
          title: 'Classic Bacon and Eggs',
          img: steak,
          description: 'Served with toast, hash browns, or roasted tomatoes.',
        }
      },
      dinner: {
        item1: {
          title: 'Steak and Eggs',
          img: steak,
          description: 'Grilled steak served with sunny-side-up eggs, roasted potatoes.',
        },
        item2: {
          title: 'Classic Bacon and Eggs',
          img: steak,
          description: 'Served with toast, hash browns, or roasted tomatoes.',
        }
      },
    }
  }
}

const dayMenu = {
  id: '123432',
  day: 'monday',
  title: 'Mess Non Veg (All Days)',
  price: 4500,
  menu: {
    breakfast: {
      item1: {
        title: 'Steak and Eggs',
        img: steak,
        description: 'Grilled steak served with sunny-side-up eggs, roasted potatoes.',
      },
      item2: {
        title: 'Classic Bacon and Eggs',
        img: steak,
        description: 'Served with toast, hash browns, or roasted tomatoes.',
      }
    },
    lunch: {
      item1: {
        title: 'Steak and Eggs',
        img: steak,
        description: 'Grilled steak served with sunny-side-up eggs, roasted potatoes.',
      },
      item2: {
        title: 'Classic Bacon and Eggs',
        img: steak,
        description: 'Served with toast, hash browns, or roasted tomatoes.',
      }
    },
    dinner: {
      item1: {
        title: 'Steak and Eggs',
        img: steak,
        description: 'Grilled steak served with sunny-side-up eggs, roasted potatoes.',
      },
      item2: {
        title: 'Classic Bacon and Eggs',
        img: steak,
        description: 'Served with toast, hash browns, or roasted tomatoes.',
      }
    },
  },
}