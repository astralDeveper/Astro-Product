import classNames from "classnames";
import { Restaurant, People } from '@mui/icons-material';
import { Link } from "react-router-dom";
import logo from "../assets/logo.png";
import {
  Avatar,
  Divider,
  IconButton,
  ListItemIcon,
  Menu,
  MenuItem,
  Tooltip,
} from "@mui/material";
import { Logout, PersonAdd, Settings, MoreVert } from "@mui/icons-material";
import { useContext, useState } from "react";
import { AuthContext } from "../Context/AuthContext";
import { auth } from "../firebase";

const linkClass =
  "flex items-center gap-2 font-light px-3 py-2 hover:bg-neutral-700 hover:no-underline active:bg-neutral-600 rounded-sm text-base transition-all duration-300";

const routes = [
  {
    title: "Meal Plans",
    path: "/dashboard",
    icon: <Restaurant />,
  },
  {
    title: "Users",
    path: "/dashboard/users",
    icon: <People />,
  },
  {
    title: "Subscription",
    path: "/dashboard/subscriptions",
    icon: <People />,
  },
];

export default function Sidebar() {
  const {user, setUser} = useContext(AuthContext)
  const [anchorEl, setAnchorEl] = useState(null);
  const open = Boolean(anchorEl);
  const handleClick = (event) => {
    setAnchorEl(event.currentTarget);
  };

  const handleClose = () => {
    setAnchorEl(null);
  };

  const handleLogout = async ()=>{
    try {

      await auth.signOut();
      setUser(null);
      setAnchorEl(null)
      
    } catch (error) {
      console.log(error)
    }
  }
  return (
    <div className="bg-[#FE854E] flex flex-col h-screen">
      <Link to="/" className="flex justify-center gap-2 px-1 py-3 bg-[#87548C]">
        <img className="w-[200px]" src={logo} alt="" />
      </Link>

      <div className="flex flex-row items-center justify-between py-2">
        <Tooltip>
          <div className="flex flex-row items-center justify-between gap-4 px-4 w-full">
            <div className="flex-col text-start">
              <p className="text-white text-sm">{user.email}</p>
              <p className="text-[#FED600]">Admin</p>
            </div>
            <IconButton
              onClick={handleClick}
              size="small"
              sx={{ ml: 2, color: 'white' }}
              aria-controls={open ? "account-menu" : undefined}
              aria-haspopup="true"
              aria-expanded={open ? "true" : undefined}
            >
              <MoreVert />
            </IconButton>
          </div>
        </Tooltip>

        <Menu
          anchorEl={anchorEl}
          id="account-menu"
          open={open}
          onClose={handleClose}
          // onClick={handleClose}
          PaperProps={{
            elevation: 0,
            sx: {
              overflow: "visible",
              filter: "drop-shadow(0px 2px 8px rgba(0,0,0,0.32))",
              mt: 1.5,
              "& .MuiAvatar-root": {
                width: 32,
                height: 32,
                ml: -0.5,
                mr: 1,
              },
              "&::before": {
                content: '""',
                display: "block",
                position: "absolute",
                top: 0,
                left: 20,
                width: 10,
                height: 10,
                bgcolor: "background.paper",
                transform: "translateY(-50%) rotate(45deg)",
                zIndex: 0,
              },
            },
          }}
          // transformOrigin={{ horizontal: "left", vertical: "top" }}
          // anchorOrigin={{ horizontal: "left", vertical: "bottom" }}
        >
          {/* <MenuItem onClick={handleClose}>
            <Avatar /> Profile
          </MenuItem>
          <MenuItem onClick={handleClose}>
            <Avatar /> My account
          </MenuItem> */}
          {/* <Divider /> */}
          {/* <MenuItem onClick={handleClose}>
            <ListItemIcon>
              <PersonAdd fontSize="small" />
            </ListItemIcon>
            Add another account
          </MenuItem> */}
          {/* <MenuItem onClick={handleClose}>
            <ListItemIcon>
              <Settings fontSize="small" />
            </ListItemIcon>
            Settings
          </MenuItem> */}
          <MenuItem onClick={handleLogout}>
            <ListItemIcon>
              <Logout fontSize="small" />
            </ListItemIcon>
            Logout
          </MenuItem>
        </Menu>

      </div>

      <div className="py-2 flex flex-1 flex-col gap-3 mx-3">
        {routes?.map((item, index) => {
          return (
            <Link
              key={index}
              to={item.path}
              className={classNames(
                linkClass,
                "rounded-md overflow-hidden cursor-pointer hover:bg-[#87548C] text-white bg-[#E47340] py-4"
              )}
            >
              <span className="text-2xl">{item.icon}</span>
              {item.title}
            </Link>
          );
        })}
      </div>

      <div className="flex flex-col gap-0.5 pt-2">
        <div
          className={classNames(
            linkClass,
            "cursor-pointer hover:bg-[#87548C] items-center font-bold text-white bg-[#E47340] py-4"
          )}
        >
          Powered by Hashtag19 © 2024
        </div>
      </div>
    </div>
  );
}
