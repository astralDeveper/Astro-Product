import React, { useState } from 'react'
import Home2Sec2Card from './Home2Sec2Card'
import { Link } from 'react-router-dom'
import { ChevronLeft, ChevronRight } from '@mui/icons-material';

const Home2Sec2 = ({ item }) => {
  const [day, setDay] = useState(0);
  const daysOfWeek = ['sunday', 'monday', 'tuesday', 'wednesday', 'thursday', 'friday', 'saturday'];
  const currentDay = daysOfWeek[day]

  return (
    <>
      <div className='mt-24 '>
        <div className='flex items-center justify-center gap-6'>
          <button onClick={() => setDay(day - 1)} disabled={day === 0}>
            <ChevronLeft fontSize='large' color={day === 0 ? 'disabled': 'black'} />
          </button>

          <h2 className='text-center font-bold text-5xl'>
            {currentDay.toLocaleUpperCase()}
          </h2>

          <button onClick={() => setDay(day + 1)} disabled={day === 6}>
            <ChevronRight fontSize='large' color={day === 6 ? 'disabled' : 'black'} />
          </button>
        </div>

        <div>
          <h3 className='text-center font-semibold text-3xl mt-10'>Breakfast <span className='text-[#FDC55E]'>(8:00 to 9:00)</span></h3>

          <div className='flex justify-center gap-10 mt-10 flex-wrap' >
            <Home2Sec2Card item={{ id: `${item.id}.${currentDay}.breakfast.item1`, price: item.price, ...item.items[currentDay].breakfast.item1 }} />
            <Home2Sec2Card item={{ id: `${item.id}.${currentDay}.breakfast.item2`, price: item.price, ...item.items[currentDay].breakfast.item2 }} />
          </div>
        </div>

        <div>
          <h3 className='text-center font-semibold text-3xl mt-10'>Lunch <span className='text-[#FDC55E]'>(12:00 to 1:00)</span></h3>

          <div className='flex justify-center gap-10 mt-10 flex-wrap' >
            <Home2Sec2Card item={{ id: `${item.id}.${currentDay}.lunch.item1`, price: item.price, ...item.items[currentDay].lunch.item1 }} />
            <Home2Sec2Card item={{ id: `${item.id}.${currentDay}.lunch.item2`, price: item.price, ...item.items[currentDay].lunch.item2 }} />
          </div>
        </div>

        <div>
          <h3 className='text-center font-semibold text-3xl mt-10'>Dinner <span className='text-[#FDC55E]'>(7:00 to 8:00)</span></h3>

          <div className='flex justify-center gap-10 mt-10 flex-wrap' >
            <Home2Sec2Card item={{ id: `${item.id}.${currentDay}.dinner.item1`, price: item.price, ...item.items[currentDay].dinner.item1 }} />
            <Home2Sec2Card item={{ id: `${item.id}.${currentDay}.dinner.item2`, price: item.price, ...item.items[currentDay].dinner.item2 }} />
          </div>
        </div>

        <div className="flex justify-center mt-20">
          <Link to={"/cart"} state={{ item }} className='w-[350px] mb-10 flex justify-center p-2 text-white rounded-xl cursor-pointer bg-[#FE854E]'>
            Confirm
          </Link>
        </div>
      </div>
    </>
  )
}

export default Home2Sec2;
