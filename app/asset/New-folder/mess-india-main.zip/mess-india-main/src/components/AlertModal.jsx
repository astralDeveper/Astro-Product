import { Snackbar } from "@mui/material";
import React from "react";

const AlertModal = (props) => {
  return (
    <>
      <Snackbar
        autoHideDuration={2000}
        anchorOrigin={{ vertical: "top", horizontal: "center" }}
        open={props.open}
        onClose={props.onclose}
        message={props.message}
      />
    </>
  );
};

export default AlertModal;
