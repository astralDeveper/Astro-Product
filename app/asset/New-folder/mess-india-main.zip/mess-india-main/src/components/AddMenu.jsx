import React, { useEffect, useState } from 'react'
import { Add } from '@mui/icons-material'
import { produce } from "immer";
import CircularProgress from '@mui/material/CircularProgress';
import Backdrop from '@mui/material/Backdrop';
import { getSingleDoc, updateMealPlan, uploadFile } from '../firebase'
import { useParams } from 'react-router-dom'

const AddMenu = () => {
  const params = useParams();
  const [mealPlan, setMealPlan] = useState(null);
  const [mealPlanTitle, setMealPlanTitle] = useState('');
  const [mealPlanPrice, setMealPlanPrice] = useState(1000);
  const [formDataUploaded, setFormDataUploaded] = useState(false);

  const [day, setDay] = useState('monday');
  const [images, setImages] = useState({
    'breakfast.1': null,
    'breakfast.2': null,
    'lunch.1': null,
    'lunch.2': null,
    'dinner.1': null,
    'dinner.2': null,
  });
  
  useEffect(() => {
    getSingleDoc('mealPlans', params.id).then((res) => {
      setMealPlan(res);
      setFormData(res.items[day])
      setMealPlanTitle(res.title)
      setMealPlanPrice(res.price)
    })
  }, [day, formDataUploaded])

  const [loading, setLoading] = useState(false);
  const [formData, setFormData] = useState(null);
  const [imagesUploaded, setImagesUploaded] = useState(false);

  const handleChange = (e) => {
    if (e.target.files) {
      const file = e.target.files[0];

      const newName = `${mealPlan.slug}/${day}/${e.target.name}`;
      const renamedFile = new File([file], newName, {
        type: file.type,
        lastModified: file.lastModified,
      })
      setImages((s) => ({ ...s, [e.target.name]: renamedFile }))
    }
  }

  const uploadImages = async () => {
    // Filter empty images and store their keys in a separate array
    let keyNames = [];
    const promiseArr = Object.entries(images).filter(([key, value]) => Boolean(value)).map(([key, value]) => {
      keyNames.push(key);
      return uploadFile(value);
    });

    const urlArr = await Promise.all(promiseArr);

    // Map the returned urls to their keys
    let imgObj = {};
    urlArr.forEach((item, i) => { imgObj[keyNames[i]] = item; });

    return imgObj;
  }
  
  const handleSubmit = async (e) => {
    e.preventDefault();

    setLoading(true)
    try {
      const res = await uploadImages();
      
      // store the urls in formData
      Object.entries(res).forEach(([key, value]) => {
        const keyItem = key.split('.');
        setFormData(produce((s) => { s[keyItem[0]][`item${keyItem[1]}`].img = value }))
      });

      setImagesUploaded(true);
    } catch (error) {
      console.log(error);
    } finally {
      setLoading(false);
    }
  }

  useEffect(() => {
    if (!imagesUploaded) return;
    const uploadData = async () => {
      const items = {
        title: mealPlanTitle,
        price: Number(mealPlanPrice),
        items: {
          ...mealPlan.items,
          [day]: formData
        },
      }

      setLoading(true)

      try {
        await updateMealPlan(params.id, items)
        setFormDataUploaded(true);
        setImagesUploaded(false);
      } catch (error) {
        console.log(error);
      } finally {
        setLoading(false)
      }
    }
    uploadData()
  }, [imagesUploaded, formData]);

  const handleDayChange = (e) => {
    setFormDataUploaded(false);
    setDay(e.target.value);
    setImages({
      'breakfast.1': null,
      'breakfast.2': null,
      'lunch.1': null,
      'lunch.2': null,
      'dinner.1': null,
      'dinner.2': null,
    })
  }

  if (!mealPlan) return null;

  return (
    <main className='bg-white rounded-xl border border-gray-200 p-6'>
      <h1 className="text-[#1A1C1E] text-2xl font-semibold border-b pb-12 max-sm:text-base">
        {mealPlan.title}
      </h1>

      <form onSubmit={handleSubmit}>
        <div className='mt-2 flex gap-4 items-center justify-between *:flex-1'>
          <TextInput label="Plan title" value={mealPlanTitle} onChange={(e) => setMealPlanTitle(e.target.value)} />
          <TextInput label="Price" value={mealPlanPrice} onChange={(e) => setMealPlanPrice(e.target.value)} />
        </div>
        
        <div className='relative mt-12'>
          <label className="text-sm absolute bg-white px-2 top-0 left-4 -translate-y-1/2 text-zinc-400">Day</label>

          <select value={day} onChange={handleDayChange} name="day" id="" className="border rounded-xl h-14 px-4 py-2">
            <option value="monday">Monday</option>
            <option value="tuesday">Tuesday</option>
            <option value="wednesday">Wednesday</option>
            <option value="thursday">Thursday</option>
            <option value="friday">Friday</option>
            <option value="saturday">Saturday</option>
            <option value="sunday">Sunday</option>
          </select>
        </div>
        

        <h2 className="text-[#1A1C1E] text-2xl font-semibold border-b mt-12 pb-4 max-sm:text-lg">
          Breakfast (8:00 to 9:00)
        </h2>

        <div className="grid grid-cols-2 gap-8">
          <div className="mt-4 max-w-xl">
            <h3 className="text-xl max-sm:text-base font-medium">
              Item 1
            </h3>

            <div className="flex flex-col gap-4">
              <ImageInput onChange={handleChange} name="breakfast.1" src={images['breakfast.1'] ? URL.createObjectURL(images['breakfast.1']) : formData.breakfast.item1.img} />

              <TextInput label="Title" value={formData.breakfast.item1.title} onChange={(e) => setFormData(produce((s) => { s.breakfast.item1.title = e.target.value }))} />

              <TextInput label="Description" value={formData.breakfast.item1.description} onChange={(e) => setFormData(produce((s) => { s.breakfast.item1.description = e.target.value }))} />
            </div>
          </div>

          <div className="mt-4 max-w-xl">
            <h3 className="text-xl max-sm:text-base font-medium">
              Item 2
            </h3>

            <div className="flex flex-col gap-4">
              <ImageInput onChange={handleChange} name="breakfast.2" src={images['breakfast.2'] ? URL.createObjectURL(images['breakfast.2']) : formData.breakfast.item2.img} />

              <TextInput label="Title" value={formData.breakfast.item2.title} onChange={(e) => setFormData(produce((s) => { s.breakfast.item2.title = e.target.value }))} />

              <TextInput label="Description" value={formData.breakfast.item2.description} onChange={(e) => setFormData(produce((s) => { s.breakfast.item2.description = e.target.value }))} />

            </div>
          </div>
        </div>

        <h2 className="text-[#1A1C1E] text-2xl font-semibold border-b mt-12 pb-4 max-sm:text-lg">
          Lunch (12:00 to 1:00)
        </h2>

        <div className="grid grid-cols-2 gap-8">
          <div className="mt-4 max-w-xl">
            <h3 className="text-xl max-sm:text-base font-medium">
              Item 1
            </h3>

            <div className="flex flex-col gap-4">
              <ImageInput onChange={handleChange} name="lunch.1" src={images['lunch.1'] ? URL.createObjectURL(images['lunch.1']) : formData.lunch.item1.img} />

              <TextInput label="Title" value={formData.lunch.item1.title} onChange={(e) => setFormData(produce((s) => { s.lunch.item1.title = e.target.value }))} />

              <TextInput label="Description" value={formData.lunch.item1.description} onChange={(e) => setFormData(produce((s) => { s.lunch.item1.description = e.target.value }))} />
            </div>
          </div>

          <div className="mt-4 max-w-xl">
            <h3 className="text-xl max-sm:text-base font-medium">
              Item 2
            </h3>

            <div className="flex flex-col gap-4">
              <ImageInput onChange={handleChange} name="lunch.2" src={images['lunch.2'] ? URL.createObjectURL(images['lunch.2']) : formData.lunch.item2.img} />

              <TextInput label="Title" value={formData.lunch.item2.title} onChange={(e) => setFormData(produce((s) => { s.lunch.item2.title = e.target.value }))} />

              <TextInput label="Description" value={formData.lunch.item2.description} onChange={(e) => setFormData(produce((s) => { s.lunch.item2.description = e.target.value }))} />
            </div>
          </div>
        </div>

        <h2 className="text-[#1A1C1E] text-2xl font-semibold border-b mt-12 pb-4 max-sm:text-lg">
          Dinner (7:00 to 8:00)
        </h2>

        <div className="grid grid-cols-2 gap-8">
          <div className="mt-4 max-w-xl">
            <h3 className="text-xl max-sm:text-base font-medium">
              Item 1
            </h3>

            <div className="flex flex-col gap-4">
              <ImageInput onChange={handleChange} name="dinner.1" src={images['dinner.1'] ? URL.createObjectURL(images['dinner.1']) : formData.dinner.item1.img} />

              <TextInput label="Title" value={formData.dinner.item1.title} onChange={(e) => setFormData(produce((s) => { s.dinner.item1.title = e.target.value }))} />

              <TextInput label="Description" value={formData.dinner.item1.description} onChange={(e) => setFormData(produce((s) => { s.dinner.item1.description = e.target.value }))} />
            </div>
          </div>

          <div className="mt-4 max-w-xl">
            <h3 className="text-xl max-sm:text-base font-medium">
              Item 2
            </h3>

            <div className="flex flex-col gap-4">
              <ImageInput onChange={handleChange} name="dinner.2" src={images['dinner.2'] ? URL.createObjectURL(images['dinner.2']) : formData.dinner.item2.img} />

              <TextInput label="Title" value={formData.dinner.item2.title} onChange={(e) => setFormData(produce((s) => { s.dinner.item2.title = e.target.value }))} />

              <TextInput label="Description" value={formData.dinner.item2.description} onChange={(e) => setFormData(produce((s) => { s.dinner.item2.description = e.target.value }))} />
            </div>
          </div>
        </div>

        <button type="submit" className="bg-[#FE854E] hover:bg-[#e67845] transition-colors text-lg rounded-md p-2 max-w-80 w-full block ml-auto text-white font-medium text-center mt-24">
          Save
        </button>

        <Backdrop
          sx={{ color: '#fff' }}
          open={loading}
            >
          <CircularProgress
            size={42}
              sx={{
              position: 'absolute',
              top: '50%',
              left: '50%',
              marginTop: '-12px',
              marginLeft: '-12px',
              color: '#FE854E'
            }}
          />
          </Backdrop>
      </form>
    </main>
  )
}

function TextInput({ value, onChange, label }) {
  return (
    <div className='relative mt-12'>
      <label className="text-sm absolute bg-white px-2 top-0 left-4 -translate-y-1/2 text-zinc-400">{label}</label>
      <input type='text' value={value} onChange={onChange} className="border rounded-xl h-14 px-4 py-2 w-full text-sm" />
    </div>
  )
}

function ImageInput({ src, name, onChange }) {
  return (
    <div className='flex justify-start mt-6'>
      <div className='shrink-0'>
        <img src={src} alt="" className='size-20 rounded-full object-cover' />
      </div>

      <label className="-translate-x-1/2 self-end size-8 text-white rounded-full p-2 bg-[#FDC55E] cursor-pointer flex justify-center items-center">
        <input type="file" name={name} className="sr-only" onChange={onChange} />
        <Add />
      </label>
    </div>
  )
}
export default AddMenu;




// useState({
//   breakfast: {
//     item1: {
//       title: 'Steak and Eggs',
//       img: '',
//       description: 'Grilled steak served with sunny-side-up eggs, roasted potatoes.',
//     },
//     item2: {
//       title: 'Classic Bacon and Eggs',
//       img: '',
//       description: 'Served with toast, hash browns, or roasted tomatoes.',
//     }
//   },
//   lunch: {
//     item1: {
//       title: 'Steak and Eggs',
//       img: '',
//       description: 'Grilled steak served with sunny-side-up eggs, roasted potatoes.',
//     },
//     item2: {
//       title: 'Classic Bacon and Eggs',
//       img: '',
//       description: 'Served with toast, hash browns, or roasted tomatoes.',
//     }
//   },
//   dinner: {
//     item1: {
//       title: 'Steak and Eggs',
//       img: '',
//       description: 'Grilled steak served with sunny-side-up eggs, roasted potatoes.',
//     },
//     item2: {
//       title: 'Classic Bacon and Eggs',
//       img: '',
//       description: 'Served with toast, hash browns, or roasted tomatoes.',
//     }
//   },
// })