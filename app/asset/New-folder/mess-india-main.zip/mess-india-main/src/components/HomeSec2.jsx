import HomeSec2Card from "./HomeSec2Card";
import img from "../assets/Section2-1.png";

import homeSec1 from "../assets/homeSec1.png"
import homeSec2 from "../assets/homeSec2.png"
import homeSec3 from "../assets/homeSec3.png"
import homeSec4 from "../assets/homeSec4.png"
import homeSec5 from "../assets/homeSec5.png"
import { useEffect, useState } from "react";
import { getData } from "../firebase";


const HomeSec2 = () => {
  const [mealsData , setMealsData] = useState(null)

  useEffect(() => {
    getData("mealPlans").then((res)=>{
      setMealsData(res)
    }).catch((err)=>{
      console.log(err);
    })
  }, [])

  if (!mealsData) return null;

  return (
    <div>
      <div className="-mt-96 max-sm:-mt-56">
        <p className="text-4xl font-bold text-center">
          Today <span className="text-[#87548C]">special</span> offers
        </p>
        <img className="h-32" src={img} alt=" " />

        <div className="flex justify-center">
          <div className="flex flex-wrap w-[80%] justify-center gap-14">
            {mealsData.map((item, i) => <HomeSec2Card key={i} image={item.image} para={item.title} price={item.price} id={item.id} link={`/menu/${item.id}`}/>)}
          </div>
        </div>
      </div>
    </div>
  );
};

export default HomeSec2;
