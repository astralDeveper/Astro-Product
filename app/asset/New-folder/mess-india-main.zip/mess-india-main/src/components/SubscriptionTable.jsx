import { DataGrid } from '@mui/x-data-grid';
import * as React from 'react';
import { getData } from '../firebase';
import { endDateOneMonthLater } from '../utils';

export default function SubscriptionTable() {
  const [users, setUsersData] = React.useState([])
  const [subscription, setSubscriptionData] = React.useState([]);
  const [meals, setMealPlan] = React.useState([]);

  const columns = [
    { field: 'userId', headerName: 'User', width: 200, valueGetter: (value) => users.find((el) => el.id === value).name },
    { field: 'mealPlanId', headerName: 'Meal Plan', width: 200, valueGetter: (value) => meals.find((el) => el.id === value).title },
    { field: 'orderId', headerName: 'Order ID', width: 130 },
    { field: 'paymentId', headerName: 'Payment ID', width: 100 },
    { field: 'price', headerName: 'Price', width: 150 },
    { field: 'purchaseDate', headerName: 'Purrchase Date', valueGetter: (value) => (new Date(value.seconds*1000)).toLocaleDateString() },
    { field: 'expiryDate', headerName: 'Expiry Date', valueGetter: (value, row) => endDateOneMonthLater(row.purchaseDate.seconds*1000).toLocaleDateString() },
    { field: 'status', headerName: 'Status', renderCell: (props) => {
        const endDate = endDateOneMonthLater(props.row.purchaseDate.seconds*1000);
        if (endDate.getTime() > Date.now())
            return <span className='p-1 text-xs bg-green-700 text-white rounded-full'>Active</span>
        else 
            return <span className='p-1 text-xs bg-red-700 text-white rounded-full'>Expired</span>
    } }
  ];

  React.useEffect(() => {
    const getUsersSubscriptionData = async () => {
        const subscriptionPromiseArr = getData('subscription');
        const usersPromiseArr = getData('users');
        const mealPlansPromiseArr = getData('mealPlans');
        const [subs, users, mealPlans] = await Promise.all([subscriptionPromiseArr, usersPromiseArr, mealPlansPromiseArr]);
        setSubscriptionData(subs);
        setMealPlan(mealPlans);
        // Filter the users that have purchased a subscription
        const filteredUsers = users.filter((user) => subs.some((e) => e.id === user.id));
        setUsersData(filteredUsers);
    }
    getUsersSubscriptionData();
  }, [])

  return (
    <div style={{ height: 400, width: '100%' }}>
      <DataGrid
        rows={subscription}
        columns={columns}
        initialState={{
          pagination: {
            paginationModel: { page: 0, pageSize: 10 },
          },
        }}
        pageSizeOptions={[5, 10]}
      />
    </div>
  );
}