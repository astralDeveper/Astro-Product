import MenuIcon from '@mui/icons-material/Menu';
import MoreVertIcon from '@mui/icons-material/MoreVert';
import Box from '@mui/material/Box';
import Drawer from '@mui/material/Drawer';
import classNames from 'classnames';
import * as React from 'react';
import { HiOutlineViewGrid } from 'react-icons/hi';
import logo from '../assets/logo.png';
import UserAvatar from './UserAvatar';
import Sidebar from './SideBar';

const linkClass =
  'flex items-center gap-2 font-light px-3 py-2 hover:bg-neutral-700 hover:no-underline active:bg-neutral-600 rounded-sm text-base transition-all duration-300'

export default function SmMenu() {
  const [open, setOpen] = React.useState(false);

  const toggleDrawer = (newOpen) => () => {
    setOpen(newOpen);
  };

  // const DrawerList = (
  //   <Box sx={{ width: 300 }} className={"block lg:hidden"} role="presentation">
  //     <div className="bg-[#FE854E] flex flex-col h-screen">
  //       <div className="flex justify-center gap-2 px-1 py-3 bg-[#87548C]">
  //         <img className='w-[200px]' src={logo} alt="" />
  //       </div>


  //       <div className="flex flex-row items-center justify-between p-5">
  //         <div className='flex flex-row items-center gap-4'>
  //           <UserAvatar />
  //           <div className="flex-col">
  //             <p className='text-white text-sm'>Anni</p>
  //             <p className='text-[#FED600] '>Super Admin</p>
  //           </div>
  //         </div>

  //         <MoreVertIcon className='cursor-pointer text-white' />
  //       </div>

  //       <div className="py-2 flex flex-1 flex-col gap-0.5">
  //         <div className={classNames(linkClass, 'cursor-pointer hover:bg-[#87548C] text-white bg-[#E47340] py-4')}>
  //           <span className="text-2xl">
  //             <HiOutlineViewGrid />
  //           </span>
  //           Dashboard
  //         </div>
  //       </div>

  //       <div className="flex flex-col gap-0.5 pt-2">
  //         <div className={classNames(linkClass, 'cursor-pointer hover:bg-[#87548C] items-center font-bold text-white bg-[#E47340] py-4')}>
  //           Powered by Hashtag19 © 2024
  //         </div>
  //       </div>
  //     </div>
  //   </Box>
  // );

  return (
    <div>
      <MenuIcon className='text-white cursor-pointer' style={{ fontSize: "35px" }} onClick={toggleDrawer(true)} />
      <Drawer open={open} onClose={toggleDrawer(false)}>
        {/* {DrawerList} */}
        <Sidebar />
      </Drawer>
    </div>
  );
}
