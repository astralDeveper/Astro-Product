import React, { useContext, useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import { AuthContext } from "../../Context/AuthContext";

const RouteShell = ({ children }) => {

  const {user} = useContext(AuthContext);
  const navigate = useNavigate();
  useEffect(()=>{
    if(!user){
      navigate("/login")
    }
  },[user]);

  return <>{user && children}</>;
};

export default RouteShell;
