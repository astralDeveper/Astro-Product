import { DataGrid } from '@mui/x-data-grid';
import * as React from 'react';
import { getData } from '../../firebase';
import { Link } from 'react-router-dom';
import classNames from 'classnames';

const columns = [
  { field: 'name', headerName: 'Name', width: 200 },
  { field: 'email', headerName: 'Email', width: 200 },
  { field: 'contact', headerName: 'Contact', width: 130 },
  { field: 'hostel', headerName: 'Hostel', width: 100 },
  { field: 'address', headerName: 'Address', width: 150 },
  { field: 'role', headerName: 'Role', valueGetter: (value) =>  value === 1 ? 'Admin' : 'User' },
  { field: 'id', headerName: 'Details', renderCell: (cell) => <Link to={`/dashboard/users/${cell.id}`} className='text-sky-600 underline hover:decoration-transparent transition-colors'>View details</Link> },
];

export default function UsersTable() {
  const [users, setUsersData] = React.useState([])

  React.useEffect(() => {
    getData('users').then((res) => {
      setUsersData(res);
    })
  }, [])

  return (
    <div style={{ height: 400, width: '100%' }}>
      <DataGrid
        rows={users}
        columns={columns}
        initialState={{
          pagination: {
            paginationModel: { page: 0, pageSize: 10 },
          },
        }}
        pageSizeOptions={[5, 10]}
        // checkboxSelection
      />
    </div>
  );
}



// // Example usage:
// let startDate = new Date(2024, 5, 10); // June 10, 2024
// let endDate = endDateOneMonthLater(startDate);
// console.log(endDate); // Output will be the end date one month later
