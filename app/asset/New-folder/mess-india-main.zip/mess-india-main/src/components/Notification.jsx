import { Alert } from "@mui/material";
import React from "react";

const Notification = ({ open, type, message, setOpen }) => {
  return (
    <>
      {open ? (
        <div className="absolute z-50 right-0 top-0 w-4/12">
          <Alert
            severity={type}
            className="shadow-2xl"
            onClose={() => {
              setOpen(!open);
            }}
          >
            {message}
          </Alert>
        </div>
      ) : (
        ""
      )}
    </>
  );
};

export default Notification;
