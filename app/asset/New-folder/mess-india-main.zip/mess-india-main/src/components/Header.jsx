import React from 'react';
import logo from '../assets/logo.png';
import SmMenu from './SmMenu';

const Header = () => {
  return (
    <div>
      <div className="h-[90px] bg-[#87548C] lg:bg-[#FEF8FF] flex px-2 flex-row items-center justify-between">
        <div className="block lg:hidden">
          <img className='w-[160px]' src={logo} alt="" />
        </div>

        <div className='block lg:hidden'>
          <SmMenu />
        </div>
      </div>
    </div>
  )
}

export default Header