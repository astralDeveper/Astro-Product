import { Link, useNavigate } from "react-router-dom";
import MenuIcon from "@mui/icons-material/Menu";
import CloseIcon from "@mui/icons-material/Close";
import logo from "../assets/main-logo.png";
import { useContext, useRef, useState } from "react";
import { AuthContext } from "../Context/AuthContext";
import { auth, createSubscription, db, getSingleDoc } from "../firebase";
import AlertModal from "./AlertModal";
import { createOrder, endDateOneMonthLater, verifySignature } from "../utils";
import { doc, getDoc } from "firebase/firestore";

export default function Navbar() {
  const drawerRef = useRef(null);

  const { user, setUser } = useContext(AuthContext);
  
  const [alertMessage, setAlertMessage] = useState("");
  const [open, setOpen] = useState(false);

  const openNavbar = () => {
    drawerRef.current.classList.toggle("translate-x-full");
    document.body.classList.toggle("overflow-hidden");
  };

  const handleLogout = async () => {
    await auth.signOut();
    setUser(null);
  };


  return (
    <div className="flex justify-between items-center gap-4 p-2">
      <div className="">
        <Link to={"/"}>
          <img className="w-[250px]" src={logo} alt="logo" />
        </Link>
      </div>

      <div
        ref={drawerRef}
        className="fixed top-0 right-0 inset-0 w-full h-full bg-white/80 z-50 backdrop-blur-sm sm:static translate-x-full sm:translate-x-0 transition-transform sm:bg-transparent sm:backdrop-blur-none"
      >
        <div className="flex flex-col items-center justify-center gap-4 text-sm font-medium sm:flex-row sm:justify-end h-full">
          {user ? (
            <>
              {user?.subscription 
                && (endDateOneMonthLater(user.subscription.purchaseDate.seconds*1000).getTime() < Date.now()) 
                && <RenewSubscription setAlertMessage={setAlertMessage} setOpen={setOpen} />
              }
              {user?.role === 1 && (
                <Link className="bg-white transition-all px-6 py-2 rounded shadow-md hover:bg-orange-300 text-black hover:text-white" to={"/dashboard"}>
                  Dashboard
                </Link>
              )}
              <button onClick={handleLogout} className="text-white transition-all px-6 py-2 rounded shadow-md bg-orange-300">
                Logout
              </button>
              </>
            ) : (
            <>
              <Link
                className="bg-white transition-all px-6 py-2 rounded shadow-md hover:bg-orange-300 text-black hover:text-white"
                to={"/signup"}
              >
                Sign Up
              </Link>
              <Link
                to={"/login"}
                className="text-white transition-all px-6 py-2 rounded shadow-md bg-orange-300"
              >
                Login
              </Link>
            </>
          )}

          <button onClick={openNavbar} className="absolute top-4 right-4 sm:hidden">
            <CloseIcon />
          </button>
        </div>
      </div>
      
      <div className="flex gap-2 items-center">
      <button onClick={openNavbar} className="sm:hidden">
        <MenuIcon />
      </button>
      </div>

      <AlertModal
        open={open}
        onclose={() => setOpen(false)}
        message={alertMessage}
      />
    </div>
  );
}


function RenewSubscription({ setAlertMessage, setOpen }) {
  const { user, setUser } = useContext(AuthContext);

  const handleCheckoutBtn = async () => {
    const mealPlan = await getSingleDoc('mealPlans', user.subscription.mealPlanId);

    let order;
    try {
      order = await createOrder(mealPlan.price, user.subscription.mealPlanId, user);
    } catch (err) {
      setAlertMessage("Something went wrong, Try again later");
      setOpen(true);
    }

    if (!order) return;

    const options = {
      key: import.meta.env.VITE_RAZORPAY_APIKEYID,
      amount: mealPlan.price * 100,
      currency: "INR",
      name: mealPlan.title,
      image: mealPlan.image,
      order_id: order.id,
      handler: async function (res) {
        const verified = await verifySignature(res.razorpay_signature, res.razorpay_payment_id, res.razorpay_order_id, user);

        if (verified) {
          const ref = await createSubscription({
            userId: user.id,
            mealPlanId: mealPlan.id,
            price: mealPlan.price,
            paymentId: res.razorpay_payment_id,
            orderId: res.razorpay_order_id,
            signature: res.razorpay_signature,
          });
          
          const subscriptionDoc = await getDoc(doc(db, "subscription", user.id));

          setUser({ ...user, subscription: { ...subscriptionDoc.data() } });
          setAlertMessage("Your order was successfully placed");
          setOpen(true);
        } else {
          setAlertMessage("Something went wrong, Try again later");
          setOpen(true);
        }
      },
      prefill: {
        name: user.name,
        email: user.email,
      },
      theme: {
        color: "#FA8232",
      },
    };
    const rzp1 = new Razorpay(options);
    rzp1.open();
  };

  return (
    <button onClick={handleCheckoutBtn} className="bg-white transition-all px-6 py-2 rounded shadow-md hover:bg-orange-300 text-black hover:text-white">
      Renew Subscription
    </button>
  )
}