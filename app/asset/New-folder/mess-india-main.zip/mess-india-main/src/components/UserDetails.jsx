import React, { useEffect, useState } from "react";
import { Link, useParams } from "react-router-dom";
import { getSingleDoc } from "../firebase";

const UserDetails = () => {
  const { id } = useParams();
  const [userData, setUserData] = useState();

  useEffect(() => {
    getSingleDoc('users', id).then((res) => {
      setUserData(res)
    })
  }, [])

  if (!userData) return null

  return (
    <div className="bg-white rounded-xl border border-gray-200 flex-1 m-5 lg:m-11 px-12">
      {/* form1 */}
      <h1 className="text-[#1A1C1E] text-2xl font-semibold py-2 max-sm:text-base max-sm:py-0 mt-12">
        User Details
      </h1>
      
      <div className="mt-8 space-y-4 max-w-xl text-sm">
        <p className="flex gap-6 justify-between">
          <span className="font-medium">Name</span>
          <span className="text-right">{userData.name}</span>
        </p>

        <p className="flex gap-6 justify-between">
          <span className="font-medium">Email</span>
          <span className="text-right">{userData.email}</span>
        </p>

        <p className="flex gap-6 justify-between">
          <span className="font-medium">Contact</span>
          <span className="text-right">{userData.contact}</span>
        </p>

        <p className="flex gap-6 justify-between">
          <span className="font-medium">Hostel</span>
          <span className="text-right">{userData.hostel}</span>
        </p>

        <p className="flex gap-6 justify-between">
          <span className="font-medium">Address</span>
          <span className="text-right">{userData.address}</span>
        </p>
      </div>

      {/* <div className="ml-11 max-2xl:m-8">
        <img src={form1} alt="" className="py-4" />
        <form action="" method="post">
          <input
            className="border rounded-xl w-[43rem] max-2xl:w-full border-gray h-14 text-sm px-8 mr-2 mb-5"
            type="text"
            placeholder="First Name"
            required
          />
          <input
            className="border rounded-xl w-[43rem] max-2xl:w-full border-gray h-14 text-sm px-8 mr-2 mb-5"
            type="text"
            placeholder="Last Name"
            required
          />
          <input
            className="border rounded-xl w-[43rem] max-2xl:w-full border-gray h-14 text-sm px-8 mr-2 mb-5"
            type="text"
            placeholder="Address"
            required
          />
          <input
            className="border rounded-xl w-[43rem] max-2xl:w-full border-gray h-14 text-sm px-8 mr-2 mb-5"
            type="number"
            placeholder="Telephone Number"
            required
          />
        </form>
      </div> */}
      
      {/* <h1 className="text-[#1A1C1E] text-2xl font-semibold border-b border-gray-100 m-11 pb-11">
        Breakfast (8:00 to 9:00)
      </h1>
      <div className="ml-11 max-2xl:m-8">
        <img src={form2} alt="" className="py-4" />
        <form action="" method="post">
          <input
            className="border rounded-xl w-[43rem] max-2xl:w-full border-gray h-14 text-sm px-8 mr-2 mb-5"
            type="text"
            placeholder="Option-1"
            required
          />
          <input
            className="border rounded-xl w-[43rem] max-2xl:w-full border-gray h-14 text-sm px-8 mr-2 mb-5"
            type="text"
            placeholder="Option-2"
            required
          />
        </form>
      </div> */}
      
      
      {/* <h1 className="text-[#1A1C1E] text-2xl font-semibold border-b border-gray-100 m-11 pb-11">
        Lunch (12:00 to 1:00)
      </h1>
      <div className="ml-11 max-2xl:m-8">
        <img src={form2} alt="" className="py-4" />
        <form action="" method="post">
          <input
            className="border rounded-xl w-[43rem] max-2xl:w-full border-gray h-14 text-sm px-8 mr-2 mb-5"
            type="text"
            placeholder="Option-1"
            required
          />
          <input
            className="border rounded-xl w-[43rem] max-2xl:w-full border-gray h-14 text-sm px-8 mr-2 mb-5"
            type="text"
            placeholder="Option-2"
            required
          />
        </form>
      </div> */}
      
      {/* <h1 className="text-[#1A1C1E] text-2xl font-semibold border-b border-gray-100 m-11 pb-11">
        Dinner (7:00 to 8:00)
      </h1>
      <div className="ml-11 max-2xl:m-8">
        <img src={form2} alt="" className="py-4" />
        <form action="" method="post">
          <input
            className="border rounded-xl w-[43rem] max-2xl:w-full border-gray h-14 text-sm px-8 mr-2 mb-5"
            type="text"
            placeholder="Option-1"
            required
          />
          <input
            className="border rounded-xl w-[43rem] max-2xl:w-full border-gray h-14 text-sm px-8 mr-2 mb-5"
            type="text"
            placeholder="Option-2"
            required
          />
        </form>
      </div> */}
      {/* button */}
      <div className="flex justify-end">
        <Link to="/dashboard/users" className="felx justify-center items-center px-6 py-3 bg-[#FE854E] rounded-md text-white m-11">
          Back
        </Link>
      </div>
    </div>
  );
};

export default UserDetails;
