import { initializeApp } from "firebase/app";
import {
  createUserWithEmailAndPassword,
  getAuth,
  signInWithEmailAndPassword,
  signOut,
} from "firebase/auth";
import {
  addDoc,
  collection,
  deleteDoc,
  doc,
  getDoc,
  getDocs,
  getFirestore,
  orderBy,
  query,
  serverTimestamp,
  setDoc,
  updateDoc,
  where,
} from "firebase/firestore";
import { getDownloadURL, getStorage, ref, uploadBytes } from "firebase/storage";

const firebaseConfig = {
  apiKey: import.meta.env.VITE_APIKEY,
  authDomain: import.meta.env.VITE_AUTHDOMAIN,
  projectId: import.meta.env.VITE_PROJECTID,
  storageBucket: import.meta.env.VITE_STORAGEBUCKET,
  messagingSenderId: import.meta.env.VITE_MESSAGINGSENDERID,
  appId: import.meta.env.VITE_APPID,
  databaseURL: import.meta.env.VITE_DATABASEURL
};

const app = initializeApp(firebaseConfig);
export const auth = getAuth(app);
export const db = getFirestore(app);
const storage = getStorage();

export async function signup(email, password) {
  const { user } = await createUserWithEmailAndPassword(auth, email, password);
  return user;
}

export async function signin(email, password) {
  const { user } = await signInWithEmailAndPassword(auth, email, password);
  return user;
}

export async function signout() {
  await signOut(auth);
  return true;
}

export async function getUser(id) {
  const docRef = doc(db, "users", id);
  const docSnap = await getDoc(docRef);
  return docSnap;
}

export async function setUser(id, data) {
  await setDoc(doc(db, "users", id), {
    email: data.email,
    contact: data.contact,
    address: data.address,
    hostel: data.hostel,
    type: "user",
  });
}

export async function uploadFile(file) {
  const storageRef = ref(storage, file.name);
  const response = await uploadBytes(storageRef, file);
  const url = await getDownloadURL(response.ref);
  return url;
}

//send data to firestore
const sendData = (obj, colName) => {
  return new Promise((resolve, reject) => {
    addDoc(collection(db, colName), obj)
      .then((res) => {
        resolve("data send to db successfully");
      })
      .catch((err) => {
        reject(err);
      });
  });
};

const updateDocument = async (obj, id, name) => {
  return new Promise((resolve, reject) => {
    const update = doc(db, name, id);
    updateDoc(update, obj);
    resolve("document updated");
    reject("error occured");
  });
};

//get data with id from firestore
const getData = (colName) => {
  return new Promise(async (resolve, reject) => {
    const dataArr = [];
    const q = query(
      collection(db, colName)
      // where("id", "==", auth.currentUser.uid)
    );
    const querySnapshot = await getDocs(q);
    querySnapshot.forEach((doc) => {
      dataArr.push({ id: doc.id, ...doc.data() });
      // console.log(dataArr);
      resolve(dataArr);
    });
    reject("error occured");
  });
};

const getSingleDoc = async (colName, id) => {
  const docRef = doc(db, colName, id);
  const docSnap = await getDoc(docRef);
  if (docSnap.exists()) {
    const doc = {id: docSnap.id, ...docSnap.data()}
    return doc;
  } else {
    console.log("No such document!");
  }
};

export const roles = {
  admin: 1,
  user: 2,
};

export { sendData, updateDocument, getData, getSingleDoc };

export async function updateMealPlan(id, data) {
  await updateDoc(doc(db, 'mealPlans', id), data);
}

export async function createSubscription(data) {
  const docRef = await setDoc(doc(db, "subscription", data.userId), {
    userId: data.userId,
    mealPlanId: data.mealPlanId,
    price: data.price,
    paymentId: data.paymentId,
    orderId: data.orderId,
    signature: data.signature,
    purchaseDate: serverTimestamp()
  });

  return docRef
}
