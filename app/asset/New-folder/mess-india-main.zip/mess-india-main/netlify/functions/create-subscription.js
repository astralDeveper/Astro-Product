import crypto from 'node:crypto'
import { initializeApp } from "firebase/app";
import { doc, getDoc, getFirestore } from "firebase/firestore";

const firebaseConfig = {
  apiKey: process.env.VITE_APIKEY,
  authDomain: process.env.VITE_AUTHDOMAIN,
  projectId: process.env.VITE_PROJECTID,
  storageBucket: process.env.VITE_STORAGEBUCKET,
  messagingSenderId: process.env.VITE_MESSAGINGSENDERID,
  appId: process.env.VITE_APPID,
  databaseURL: process.env.VITE_DATABASEURL
};

const app = initializeApp(firebaseConfig);
const db = getFirestore(app);

export default async (req) => {
    const json = await req.json();

    const docRef = doc(db, 'orders', json.userId);
    const docSnap = await getDoc(docRef);
    const data = { ...docSnap.data() }

    if (docSnap.exists()) {
        const hash = crypto.createHmac('sha256', process.env.RAZORPAY_SECRET).update(`${data.order}|${json.paymentId}`).digest('hex');

        if (hash === json.signature) {
            return new Response(JSON.stringify({ verified: true }));
        } else {
            return new Response(JSON.stringify({ verfied: false }));
        }
    } else {
        return new Response(JSON.stringify({ verfied: false }));
    }
}
