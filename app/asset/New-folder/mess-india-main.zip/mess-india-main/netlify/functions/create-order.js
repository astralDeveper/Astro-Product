import Razorpay from "razorpay";
import { initializeApp } from "firebase/app";
import { doc, getFirestore, setDoc } from "firebase/firestore";

const firebaseConfig = {
  apiKey: process.env.VITE_APIKEY,
  authDomain: process.env.VITE_AUTHDOMAIN,
  projectId: process.env.VITE_PROJECTID,
  storageBucket: process.env.VITE_STORAGEBUCKET,
  messagingSenderId: process.env.VITE_MESSAGINGSENDERID,
  appId: process.env.VITE_APPID,
  databaseURL: process.env.VITE_DATABASEURL
};

const app = initializeApp(firebaseConfig);
const db = getFirestore(app);

export default async (req) => {
    const json = await req.json();
    const instance = new Razorpay({ key_id: process.env.RAZORPAY_APIKEYID, key_secret: process.env.RAZORPAY_SECRET })

    const order = await instance.orders.create({
        amount: json.price * 100,
        currency: "INR",
        notes: {
            customer_name: json.name,
            customer_email: json.email,
            customer_id: json.userId,
            mealPlan_id: json.planId,
        }
    })

    await setDoc(doc(db, "orders", json.userId), {
        plan: json.planId,
        order: order.id,
    });

    return new Response(JSON.stringify({ order }))
}
