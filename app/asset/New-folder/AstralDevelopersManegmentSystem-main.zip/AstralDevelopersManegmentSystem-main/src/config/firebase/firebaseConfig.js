import { initializeApp } from "firebase/app";
import { getAuth } from "firebase/auth";
import { getFirestore } from "firebase/firestore";
import { getStorage } from "firebase/storage";

const firebaseConfig = {
    apiKey: "AIzaSyAK1CJDP3Vz93hv0GIQDNo1PzAjK5o2N8k",
    authDomain: "astraldevelopersmanagement.firebaseapp.com",
    projectId: "astraldevelopersmanagement",
    storageBucket: "astraldevelopersmanagement.appspot.com",
    messagingSenderId: "360070777507",
    appId: "1:360070777507:web:681996ed0a7f07fbb4cd16",
    measurementId: "G-TD7TB1EH2M"
  };

export const app = initializeApp(firebaseConfig);
export const auth = getAuth(app);
export const db = getFirestore(app);
export const storage = getStorage(app)