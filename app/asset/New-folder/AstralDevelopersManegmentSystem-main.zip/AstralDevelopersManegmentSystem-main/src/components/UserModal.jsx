import { RiCheckDoubleLine, RiCloseLargeFill, RiEdit2Line } from '@remixicon/react';
import { doc, setDoc } from 'firebase/firestore';
import React, { useEffect, useState } from 'react'
import { db, storage } from '../config/firebase/firebaseConfig';
import Swal from 'sweetalert2'
import withReactContent from 'sweetalert2-react-content'
import { getDownloadURL, ref, uploadBytes } from 'firebase/storage';

const MySwal = withReactContent(Swal)

const UserModal = ({ user, handleOutsideClick, closeModal, getData }) => {


    const formatTimeToHHMM = (timeString) => {
        // Extract hours, minutes, and period (AM/PM) from the time string
        const [time, period] = timeString.split(' ');
        const [hoursStr, minutesStr] = time.split(':');
        let hours = parseInt(hoursStr, 10);
        const minutes = parseInt(minutesStr, 10);

        // Convert hours to 24-hour format if necessary
        if (period === "PM" && hours !== 12) {
            hours += 12;
        } else if (period === "AM" && hours === 12) {
            hours = 0;
        }

        // Pad hours with leading zero if necessary
        const formattedHours = hours.toString().padStart(2, '0');

        // Return the formatted time in "HH:mm" format
        return `${formattedHours}:${minutesStr}`;
    };

    const formattedTime = formatTimeToHHMM(user.employeeTiming);








    const [register, setRegister] = useState({
        name: user.name,
        email: user.email,
        phoneNumber: user.phoneNumber,
        type: user.type,

        imageUrl: user.imageUrl,

        address: user.address,
        qualification: user.qualification,
        department: user.department,
        position: user.position,
        salary: user.salary,
        registerId: user.registerId,
        accountTitle: user.accountTitle,
        accountNumber: user.accountNumber,
        cnic: user.cnic,

        cvUrl: user.cvUrl,

        cnicImage: user.cnicImage,
        offerLetter: user.offerLetter,
        bankName: user.bankName,
        employeeTiming: formattedTime,
        employeeShift: user.employeeShift


    });

    const handleTime = (e) => {
        setRegister({ ...register, employeeTiming: e.target.value })
    }

    const employeeTiming = new Date('1970-01-01T' + register.employeeTiming + 'Z')
        .toLocaleTimeString('en-US',
            { timeZone: 'UTC', hour12: true, hour: 'numeric', minute: 'numeric' }
        );


    const handleInput = (e) => {
        setRegister({ ...register, [e.target.name]: e.target.value })
    }

    function handleChange(e) {

        setRegister({ ...register, type: e })
    }

    function handleChangeDepartment(e) {

        setRegister({ ...register, department: e })
    }

    const handleChangePosition = (e) => {
        setRegister({ ...register, position: e })
    }

    const handleShift = (e) => {
        setRegister({ ...register, employeeShift: e })
    }

    console.log(register.employeeShift);




    const [previewImg, setPreviewImg] = useState(register.imageUrl);

    const handleFileChange = (event) => {
        const file = event.target.files[0];
        const reader = new FileReader();
        setRegister({ ...register, imageUrl: file })


        reader.onload = function (e) {
            setPreviewImg(e.target.result);
        };

        if (file) {
            reader.readAsDataURL(file);
        }
    };


    const [previewCv, setPreviewCv] = useState(register.cvUrl);

    const handleFileChangeCv = (event) => {
        const cvFile = event.target.files[0];
        const reader = new FileReader();
        setRegister({ ...register, cvUrl: cvFile })


        reader.onload = function (e) {
            setPreviewCv(e.target.result);
        };

        if (cvFile) {
            reader.readAsDataURL(cvFile);
        }
    };

    const [previewId, setPreviewId] = useState(register.cnicImage);

    const handleFileChangeCnic = (event) => {
        const cnicFile = event.target.files[0];
        const reader = new FileReader();
        setRegister({ ...register, cnicImage: cnicFile })


        reader.onload = function (e) {
            setPreviewId(e.target.result);
        };

        if (cnicFile) {
            reader.readAsDataURL(cnicFile);
        }
    };

    const [previewOfferlatter, setPreviewOfferlatter] = useState(register.offerLetter);

    const handleFileChangeOfferlatter = (event) => {
        const offerLatterfile = event.target.files[0];
        const reader = new FileReader();
        setRegister({ ...register, offerLetter: offerLatterfile })


        reader.onload = function (e) {
            setPreviewOfferlatter(e.target.result);
        };

        if (offerLatterfile) {
            reader.readAsDataURL(offerLatterfile);
        }
    };


  

    const [uploadImage, setImageUpload] = useState(false);

    useEffect(() => {

        if (!uploadImage) return;
        
        setDoc(doc(db, "users", user.id), register);
        setImageUpload(false);
        
    }, [uploadImage, register])


    const editData = async (e) => {
        e.preventDefault();

        try {
            let avatarUrl = register.imageUrl;
            let cvUrl = register.cvUrl;
            let cnicUrl = register.cnicImage;
            let offerUrl = register.offerLetter;

            // let avatarUrl, cvUrl, cnicUrl, offerUrl;

            if (avatarUrl instanceof File) {
                const avatarStorageRef = ref(storage, `${register.email}`);
                const avatarSnapshot = await uploadBytes(avatarStorageRef, avatarUrl)
                avatarUrl = await getDownloadURL(avatarSnapshot.ref)
            }


            if (cvUrl instanceof File) {
                const cvStorageRef = ref(storage, `/cv/${register.email}`);
                const cvSnapshot = await uploadBytes(cvStorageRef, cvUrl)
                cvUrl = await getDownloadURL(cvSnapshot.ref)
            }

            if (cnicUrl instanceof File) {
                const cnicStorageRef = ref(storage, `/cnic/${register.email}`);
                const cnicSnapshot = await uploadBytes(cnicStorageRef, cnicUrl)
                cnicUrl = await getDownloadURL(cnicSnapshot.ref)
            }


            if (offerUrl instanceof File) {
                const offerStorageRef = ref(storage, `/offer/${register.email}`);
                const offerSnapshot = await uploadBytes(offerStorageRef, offerUrl)
                offerUrl = await getDownloadURL(offerSnapshot.ref)
            }

            setRegister({ ...register, offerLetter: offerUrl, imageUrl: avatarUrl, cvUrl: cvUrl, cnicImage: cnicUrl, employeeTiming: employeeTiming })

            setImageUpload(true)

            let timerInterval;
            Swal.fire({
                title: "Edit Successfully!",
                html: "Edit in  <b></b> milliseconds.",
                timer: 3500,
                timerProgressBar: true,
                didOpen: () => {
                    Swal.showLoading();
                    const timer = Swal.getPopup().querySelector("b");
                    timerInterval = setInterval(() => {
                        timer.textContent = `${Swal.getTimerLeft()}`;
                    }, 200);
                },
                willClose: () => {
                    clearInterval(timerInterval);
                }
            }).then((result) => {
                if (result.dismiss === Swal.DismissReason.timer) {
                    return closeModal()
                }
            });

        } catch (error) {
            console.log(error);
        }

    }








    return (

        <>
            <div className='max-w-screen-xl mx-auto p-4'>
                <div className="  fixed inset-0 bg-gray-600 bg-opacity-50 overflow-y-auto z-50 h-full w-full" id="modal"
                    onClick={handleOutsideClick}
                >
                    <div className="relative top-5 mx-auto border w-[98%]  max-w-screen-lg shadow-lg rounded-md bg-gradient-to-bl from-teal-100 to-teal-200 ">

                        <div className="text-center mt-2">
                            <div className="mx-auto flex items-center justify-center h-12 w-12 rounded-full bg-purple-100">
                                <img src="https://w7.pngwing.com/pngs/1018/119/png-transparent-computer-icons-editing-pencil-miscellaneous-angle-pencil.png" className='h-6 w-6 text-teal-500' alt="" />
                            </div>

                            <h3 className="text-lg leading-6 font-medium text-gray-900">Edit Task</h3>
                            <div className="mt-2 px-7 py-3">
                                <p className="text-xl text-gray-500">Change Employee Details</p>

                                <section className="bg-blueGray-50">
                                    <div className="w-full lg:w-8/12 px-4 mx-auto mt-6">
                                        <div className="relative flex flex-col min-w-0 break-words w-full mb-6 shadow-lg rounded-lg bg-blueGray-100 border-0">
                                        </div>


                                        <form onSubmit={editData} id="edit-user" className='p-6  border border-teal-600 rounded-xl'>

                                            <div className="grid grid-cols-2 gap-6 max-sm:grid-cols-1">
                                                <div className="flex flex-col gap-2">
                                                    <label htmlFor="first_name" className="">
                                                        Name
                                                    </label>
                                                    <input value={register.name} type="text" name="name" id="first_name" className="rounded border border-gray-300 bg-gray-50" placeholder="John Doe" onChange={handleInput} />
                                                </div>

                                                <div className="flex flex-col gap-2">
                                                    <label htmlFor="email" className="">
                                                        Email
                                                    </label>

                                                    <input value={register.email} type="email" name="email" id="email" className="rounded border border-gray-300 bg-gray-50" placeholder="email@abc.com" onChange={handleInput} />
                                                </div>

                                                <div className="flex flex-col gap-2">
                                                    <label htmlFor="phone" className="">
                                                        Phone
                                                    </label>

                                                    <input value={register.phoneNumber} type="text" name="phoneNumber" id="phone" className="rounded border border-gray-300 bg-gray-50" placeholder="+920-000-000" onChange={handleInput} />
                                                </div>



                                                <div className="flex flex-col gap-2">
                                                    <label htmlFor="accountNumber" className="">
                                                        Account Number
                                                    </label>
                                                    <input value={register.accountNumber} type="text" name="accountNumber" id="accountNumber" className="rounded border border-gray-300 bg-gray-50" placeholder="Ac/Number" onChange={handleInput} />
                                                </div>

                                                <div className="flex flex-col gap-2">
                                                    <label htmlFor="bankName" className="">
                                                        Bank Name
                                                    </label>
                                                    <input type="text" value={register.bankName} name="bankName" id="bankName" className="rounded border border-gray-300 bg-gray-50" placeholder="Bank Name" onChange={handleInput} />
                                                </div>

                                                <div className="flex flex-col gap-2">
                                                    <label htmlFor="accountTile" className="">
                                                        Account Title
                                                    </label>
                                                    <input value={register.accountTitle} type="text" name="accountTitle" id="accountTile" className="rounded border border-gray-300 bg-gray-50" placeholder="Ac/Title" onChange={handleInput} />
                                                </div>







                                                <div className="flex flex-col gap-2">
                                                    <label htmlFor="cnic" className="">
                                                        Cnic
                                                    </label>

                                                    <input
                                                        value={register.cnic}
                                                        type="number"
                                                        name="cnic"
                                                        id="cnic"
                                                        className="[appearance:textfield] [&::-webkit-outer-spin-button]:appearance-none [&::-webkit-inner-spin-button]:appearance-none rounded border border-gray-300 bg-gray-50"
                                                        placeholder="42101-1587491-7"
                                                        maxLength={'13'}

                                                        onChange={handleInput}
                                                    />
                                                </div>



                                                <div>
                                                    <label htmlFor="type" className="block mb-2 text-sm font-medium text-gray-900 dark:text-white">
                                                        Select an option
                                                    </label>
                                                    <select
                                                        value={register.type}
                                                        onChange={(e) => handleChange(e.target.value)}
                                                        name="option"
                                                        id="type"
                                                        selected
                                                        className="bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 block w-full p-2.5 dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-blue-500 dark:focus:border-blue-500"
                                                    >
                                                        <option value="">Choose any one Type</option>
                                                        <option value="Admin">Admin</option>
                                                        <option value="Manager">Manager</option>
                                                        <option value="Employee">Employee</option>
                                                    </select>
                                                </div>

                                                <div className="flex items-center overflow-hidden">
                                                    <div className="shrink-0">
                                                        <img id='preview_img' className="size-14 border object-cover rounded-full" src={previewImg} alt="Current profile photo" />
                                                    </div>
                                                    <label htmlFor="fileInputProfile" className="cursor-pointer">
                                                        <span className="sr-only">Choose profile photo</span>
                                                        <input
                                                            filename={register.imageUrl}
                                                            id="fileInputProfile"
                                                            name='imageUrl'
                                                            type="file"
                                                            onChange={handleFileChange}
                                                            className="hidden"

                                                        />
                                                        <span className="file-upload-button w-52 bg-teal-500 text-white py-2 px-4 rounded-md hover:bg-teal-600">Change Profile Image</span>
                                                    </label>
                                                </div>



                                                <div className="flex items-center overflow-hidden">
                                                    <div className="shrink-0">
                                                        <img id='preview_img1' className="size-14 border object-cover rounded-full" src={previewCv} alt="Current profile photo" />
                                                    </div>
                                                    <label htmlFor="fileInputCv" className="cursor-pointer">
                                                        <span className="sr-only">Choose Cv</span>
                                                        <input
                                                            filename={register.cvUrl}
                                                            id="fileInputCv"
                                                            name='cvUrl'
                                                            type="file"
                                                            onChange={handleFileChangeCv}
                                                            className="hidden"

                                                        />
                                                        <span className="file-upload-button bg-teal-500 text-white py-2 px-4 rounded-md hover:bg-teal-600">Change Employee CV</span>
                                                    </label>
                                                </div>


                                                <div className="flex items-center overflow-hidden">
                                                    <div className="shrink-0">
                                                        <img id='preview_img2' className="size-14 border object-cover rounded-full" src={previewId} alt="Current profile photo" />
                                                    </div>
                                                    <label htmlFor="fileInput2" className="cursor-pointer">
                                                        <span className="sr-only">Upload Profile Image</span>
                                                        <input
                                                            filename={register.cnicImage}

                                                            id="fileInput2"
                                                            name='cnicImage'
                                                            type="file"
                                                            onChange={handleFileChangeCnic}
                                                            className="hidden"

                                                        />
                                                        <span className="file-upload-button bg-teal-500 text-white py-2 px-4 rounded-md hover:bg-teal-600">Change CNIC Front</span>
                                                    </label>
                                                </div>



                                                <div className="flex items-center overflow-hidden">
                                                    <div className="shrink-0">
                                                        <img id='preview_img3' className="size-14 border object-cover rounded-full" src={previewOfferlatter} alt="Current profile photo" />
                                                    </div>
                                                    <label htmlFor="fileInput3" className="cursor-pointer">
                                                        <span className="sr-only">Choose profile photo</span>
                                                        <input
                                                            filename={register.offerLetter}
                                                            id="fileInput3"
                                                            name='offerLetter'
                                                            type="file"
                                                            onChange={handleFileChangeOfferlatter}
                                                            className="hidden"

                                                        />
                                                        <span className="file-upload-button bg-teal-500 text-white py-2 px-4 rounded-md hover:bg-teal-600">Change Offer letter</span>
                                                    </label>
                                                </div>

                                                <div className="flex flex-col gap-2">
                                                    <label htmlFor="Address">
                                                        Address
                                                    </label>
                                                    <input value={register.address} name='address' type="text" id="Address" className="rounded border border-gray-300 bg-gray-50" placeholder="Address" onChange={handleInput} />
                                                </div>
                                                <div className="flex flex-col gap-2">
                                                    <label htmlFor="Qualification">
                                                        Qualification
                                                    </label>
                                                    <input value={register.qualification} name='qualification' type="text" id="Qualification" className="rounded border border-gray-300 bg-gray-50" placeholder="Qualification"
                                                        onChange={handleInput} />
                                                </div>

                                                <div>
                                                    <label htmlFor="Position" className="block mb-2 text-sm font-medium text-gray-900 dark:text-white">
                                                        Select  Department
                                                    </label>
                                                    <select
                                                        value={register.department}
                                                        onChange={(e) => handleChangeDepartment(e.target.value)}
                                                        name="department"
                                                        id="Position"
                                                        selected
                                                        className="bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 block w-full p-2.5 dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-blue-500 dark:focus:border-blue-500"
                                                    >
                                                        <option value="">Select department</option>
                                                        <option value="Development">Development</option>
                                                        <option value="Sales">Sales</option>
                                                        <option value="Graphics">Graphics</option>
                                                        <option value="Ui/Ux Designer">Ui/Ux Designer</option>
                                                    </select>
                                                </div>

                                                <div>
                                                    <label htmlFor="Position" className="block mb-2 text-sm font-medium text-gray-900 dark:text-white">
                                                        Select Position
                                                    </label>
                                                    <select
                                                        value={register.position}
                                                        onChange={(e) => handleChangePosition(e.target.value)}
                                                        name="position"
                                                        id="Position"
                                                        selected
                                                        className="bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 block w-full p-2.5 dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-blue-500 dark:focus:border-blue-500"
                                                    >
                                                        <option value="">Select department</option>
                                                        <option value="Senior">Senior</option>
                                                        <option value="Junior">Junior</option>
                                                        <option value="Internee">Internee</option>
                                                    </select>
                                                </div>

                                                <div className="grid grid-cols-1 sm:grid-cols-2 items-center gap-2">
                                                    <div className="flex flex-col gap-2 ">
                                                        <label htmlFor="Salary">
                                                            Salary
                                                        </label>
                                                        <input value={register.salary} name='salary' type="number" id="Salary" className="w-full rounded border border-gray-300 bg-gray-50" min={0} maxLength={10} placeholder="Salary" onChange={handleInput} />
                                                    </div>

                                                    <div className="flex flex-col gap-2 ">
                                                        <label htmlFor="Id">
                                                            ID
                                                        </label>
                                                        <input value={register.registerId} name='registerId' type="text" id="id" className="w-full rounded border border-gray-300 bg-gray-50" min={0} maxLength={10} placeholder="#id" onChange={handleInput} />
                                                    </div>
                                                </div>





                                                <div className="grid grid-cols-1 sm:grid-cols-2 items-center gap-2">
                                                    <div className="flex flex-col gap-2">
                                                        <label htmlFor="employeeTiming">
                                                            Employee Time
                                                        </label>
                                                        <input
                                                            type="time"
                                                            value={register.employeeTiming}
                                                            id="employeeTiming"
                                                            className="rounded border border-gray-300 bg-gray-50 relative"
                                                            placeholder="employeeTiming"
                                                            required
                                                            onChange={(e) => handleTime(e)}
                                                        />
                                                    </div>


                                                    <div className="flex flex-col gap-2 ">
                                                        <label htmlFor="Id">
                                                            Employee Shift
                                                        </label>

                                                        <select
                                                            onChange={(e) => handleShift(e.target.value)}
                                                            name="employeeShift"
                                                            id="employeeShift"
                                                            value={register.employeeShift}
                                                            selected
                                                            className="bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 block w-full p-2.5 dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-blue-500 dark:focus:border-blue-500"
                                                        >
                                                            <option selected={true} disabled >Choose any one Shift</option>
                                                            <option value="Morning">Morning</option>
                                                            <option value="Evening">Evening</option>
                                                        </select>

                                                    </div>
                                                </div>














                                            </div>
                                        </form >
                                    </div>
                                </section >
                            </div>
                            <div className=" flex  items-center justify-center gap-10 px-4 py-3">

                                <button form="edit-user" type='submit' id="ok-btn" className=" rounded-md bg-teal-700 text-white  py-2 px-4 font-semibold hover:bg-teal-800  transition-colors duration-150 ease-in-out">
                                    <RiCheckDoubleLine size={25} />
                                </button>

                                <button id="exit" className=" rounded-md bg-teal-700 text-white  py-2 px-4 font-semibold hover:bg-teal-800  transition-colors duration-150 ease-in-out" onClick={closeModal}>
                                    <RiCloseLargeFill />
                                </button>
                            </div>
                        </div>
                    </div>
                </div >

            </div >
        </>
    )
}

export default UserModal
