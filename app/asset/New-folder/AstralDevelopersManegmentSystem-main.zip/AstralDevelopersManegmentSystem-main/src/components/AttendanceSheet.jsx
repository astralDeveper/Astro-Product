import { addDoc, collection, getDocs, query, setDoc, where } from 'firebase/firestore';
import React, { useEffect, useState } from 'react';
import { useLocation, useNavigate } from 'react-router-dom';
import Swal from 'sweetalert2';
import { db } from '../config/firebase/firebaseConfig';
import { useAuth } from '../screens/AuthProvider';

const AttendanceSheet = () => {

    // get specific User
    // const location = useLocation();
    // console.log(location.state);
    // ent specific User

    const { user } = useAuth();



    // get Current Month start
    const currentDate = new Date();
    const months = ['January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December'];
    const currentMonthName = months[currentDate.getMonth()];
    // get Current Month end

    // get Current month Weeks name date and serial Number start
    const getCurrentMonthDataAndSno = listDaysAndDatesOfCurrentMonth()

    function listDaysAndDatesOfCurrentMonth() {
        const today = new Date();
        const currentMonth = today.getMonth();
        const currentYear = today.getFullYear();
        const daysInMonth = new Date(currentYear, currentMonth + 1, 0).getDate();

        const days = [];

        for (let i = 1; i <= daysInMonth; i++) {
            const date = new Date(currentYear, currentMonth, i);
            const dayOfWeek = date.toLocaleDateString('en-US', { weekday: 'long' });
            days.push({ attendanceWeeks: `${dayOfWeek}`, attendanceDate: `${date.toLocaleDateString()}`, sNo: i })
        }
        return days;
    }
    // console.log(getCurrentMonthDataAndSno);

    // get Current month Weeks name date and serial Number end

    // current Date Start
    const today = new Date();
    const currentDates = today.toLocaleDateString()
    // current Date End

    // check in start
    async function checkIn(e) {
        const currentTime = new Date();
        let hours = currentTime.getHours();
        const minutes = currentTime.getMinutes();
        const meridiem = hours >= 12 ? 'PM' : 'AM';
        hours = hours % 12 || 12;
        const timeString = `${hours}:${minutes < 10 ? '0' + minutes : minutes} ${meridiem}`
        let status = '';
        if (timeString <= location.state?.employeeTiming) {
            status = 'On Time';
        } else if ((timeString >= '8:20 PM' && timeString < '8:30 PM') || (timeString >= '9:20 PM' && timeString < '9:30 PM')) {
            status = 'Late';
        } else if ((timeString >= '9:00 PM' && timeString < '9:10 PM') || (timeString >= '10:00 AM' && timeString < '11:00 AM')) {
            status = 'HalfDay';
        }
        try {
            const docRef = await addDoc(collection(db, "attendance"), { ...e, checkInTime: timeString, userId: user?.id, attendanceMonth: currentMonthName, liveStatus: status });
            // setCheckInTime(true);
            Swal.fire({
                title: "Check In Marked",
                showClass: {
                    popup: `
                animate__animated
                animate__fadeInUp
                animate__faster
              `
                },
                hideClass: {
                    popup: `
                animate__animated
                animate__fadeOutDown
                animate__faster `
                }
            });
            // getAttendance();
            console.log("Document written with ID: ", docRef.id);
        } catch (error) {
            console.error("Error adding document: ", error);
        }
    }
    // check in end

    // check in start
    async function checkOut(e) {
        const currentTime = new Date();
        let hours = currentTime.getHours();
        const minutes = currentTime.getMinutes();
        const meridiem = hours >= 12 ? 'PM' : 'AM';
        hours = hours % 12 || 12;
        const timeString = `${hours}:${minutes < 10 ? '0' + minutes : minutes} ${meridiem}`;
        try {
            const querySnapshot = await getDocs(query(collection(db, "attendance"), where("userId", "==", user?.id)));
            if (!querySnapshot.empty) {
                const docRef = querySnapshot.docs[0].ref;
                await setDoc(docRef, { checkOutTime: timeString }, { merge: true });
                // setCheckOutTime(true)
                Swal.fire({
                    title: "Check Out Marked",
                    showClass: {
                        popup: `
                        animate__animated
                        animate__fadeInUp
                        animate__faster
                      `
                    },
                    hideClass: {
                        popup: `
                        animate__animated
                        animate__fadeOutDown
                        animate__faster`
                    }
                });
                // getAttendance()
            } else {
                console.log("No document found with the provided serial number.");
            }
        } catch (error) {
            console.error("Error adding document: ", error);
        }
    }

    // check in end

    // Confirm Attendance marked Start
    const [attendance, setAttendance] = useState([null])
    const selectAttendance = (e) => {
        setAttendance(e)
    }
    // console.log(attendance);
    // Confirm Attendance marked End

    // save Attendance Start 
    const navigate = useNavigate()
    const handleClick = async () => {
        try {
            const querySnapshot = await getDocs(query(collection(db, "attendance"), where("userId", "==", user?.id)));
            if (!querySnapshot.empty) {
                const docRef = querySnapshot.docs[0].ref;
                // console.log(docRef);
                await setDoc(docRef, { attendance: attendance.attendance }, { merge: true });
                Swal.fire({
                    title: "Attendance Marked",
                    showClass: {
                        popup: `
                          animate__animated
                          animate__fadeInUp
                          animate__faster`
                    },
                    hideClass: {
                        popup: `
                          animate__animated
                          animate__fadeOutDown
                          animate__faster`
                    }
                });

                user.type === 'Employee' ? navigate('/employee'):
                navigate('/manager')


                
            }
        } catch (error) {
            console.error("Error adding document: ", error);
        }
    };

    // save Attendance End 


    // Get Attendance Data form store start
    const [getAttendanceUser, setAttendanceUser] = useState(null);
    const [getAttendanceUsers, setAttendanceUsers] = useState([]);


    const getAttendance = async () => {
        try {
            const q = query(collection(db, "attendance"), where("userId", "==", user?.id));
            const querySnapshot = await getDocs(q);
            const allUsers = [];
            querySnapshot.forEach((doc) => {
                allUsers.push({ id: doc.id, ...doc.data() });
            });
            setAttendanceUser(...allUsers);
            setAttendanceUsers([...allUsers])
        } catch (error) {
            console.error("Error fetching employees:", error);
        }
    };

    useEffect(() => {
        getAttendance()
    }, [getAttendanceUser])



    // Get Attendance Data form store End


    const a = getAttendanceUsers.filter((x) => x.attendanceDate !== getCurrentMonthDataAndSno.filter((b) => b.attendanceDate));

    const b = a.map((item) => item.attendanceDate)


    return (
        <main className='max-w-screen-xl mx-auto p-4' >

            {/* Header Start */}
            <article className=' lg:grid lg:grid-cols-2 grid row-span-2 gap-4 justify-center ' >
                <div className=' lg:justify-self-end justify-center lg:hidden block '>
                    <img className='rounded-full w-52 h-52 shrink-0 ' src={user?.imageUrl} alt="image" />
                </div>
                <div className=' lg:justify-start justify-center '>
                    <div className='font-medium text-lg text-justify' >#ID  : {user?.registerId}</div>
                    <div className='font-medium text-lg text-justify' >Name : {user?.name}</div>
                    <div className='font-medium text-lg text-justify' >Shift : {user?.employeeShift}</div>
                    <div className='font-medium text-lg text-justify' >Department : {user?.department}</div>
                    <div className='font-medium text-lg text-justify' >Current Attendance Month : {currentMonthName}</div>
                </div>
                <div className=' lg:justify-self-end justify-center lg:block hidden '>
                    <img className='rounded-full w-52 h-52 shrink-0 ' src={user?.imageUrl} alt="image" />
                </div>
            </article>
            {/* Header End */}

            {/* Attendance Save Button start */}
            <div className="px-6 py-3  flex items-center justify-end">
                <button onClick={handleClick} className='border px-6 py-1 rounded-lg text-lg font-bold bg-teal-500 text-[#ffff] ' >Save</button>
            </div>
            {/* Attendance Save Button End */}

            {/* Table Section Start */}
            <table className="w-full text-sm text-left">
                {/* table header Start */}
                <thead className="text-xs text-gray-700 uppercase bg-gray-50">
                    <tr>
                        <th scope="col" className="px-6 py-3">
                            Sno
                        </th>
                        <th scope="col" className="px-6 py-3">
                            Day
                        </th>
                        <th scope="col" className="px-6 py-3">
                            Date
                        </th>
                        <th scope="col" className="px-6 py-3">
                            Attendance
                        </th>
                    </tr>
                </thead>
                {/* table header End */}

                {/* Start date weeks'Names and serialNo start */}

                <tbody>
                    {/* Start date weeks'Names and serialNo start */}
                    {getCurrentMonthDataAndSno.map((mTS, index) => {
                        return (
                            <tr key={index} className="odd:bg-white even:bg-gray-50 border-b">

                                <td className="px-6 py-4 font-medium text-gray-900 whitespace-nowrap">{mTS.sNo}</td>
                                <td className="px-6 py-4 font-medium text-gray-900 whitespace-nowrap">{mTS.attendanceWeeks}</td>
                                <td className="px-6 py-4 font-medium text-gray-900 whitespace-nowrap">{mTS.attendanceDate}</td>

                                {/* Attendance parked Section start */}
                                <td   className="px-6 py-4 font-medium text-gray-900 whitespace-nowrap">

                                    {mTS.attendanceDate === currentDates ?
                                        <div className='flex items-center justify-between'>

                                            <select
                                                onChange={(e) => selectAttendance({ date: mTS.attendanceDate, attendance: e.target.value })}
                                                className='border px-2 py-2 rounded-lg cursor-pointer font-medium' >
                                                <option value="">---</option>
                                                <option value="Absent" className='text-red-600'>Absent</option>
                                                <option value="Present" className='text-green-600'>Present</option>
                                            </select>

                                            <div className='flex items-center gap-4' >

                                                <button
                                                    onClick={() => checkIn(mTS)}
                                                    className={`px-4 py-2 bg-green-500 ${getAttendanceUser?.attendanceDate !== currentDates ? 'block' : 'hidden'} transition-all translate-x-2 text-white font-semibold text-[16px] rounded-md hover:bg-green-600`}
                                                >
                                                    Check In
                                                </button>

                                                <button
                                                    onClick={() => checkOut(mTS)}
                                                    className={`px-4 py-2 bg-red-500 ${!getAttendanceUser?.checkOutTime || getAttendanceUser?.attendanceDate !== currentDates ? 'block' : 'hidden'} transition-all translate-x-2 text-white font-semibold text-[16px] rounded-md hover:bg-red-600`} >
                                                    Check Out
                                                </button>

                                            </div>
                                        </div>
                                        :
                                        <></>
                                    }
                                    {a.map((item, indexes) =>
                                        b[indexes] === mTS.attendanceDate ?
                                            <td
                                                key={item.id}
                                                className={`px-6 shrink-0 flex lg:flex-row  flex-col justify-center gap-4 py-4 text-base font-medium ${item.attendance == 'Present' ? ' text-green-500' : 'text-red-500'}`}
                                            >
                                                <p className="shrink-0">{item.attendance}</p>
                                                <p className="shrink-0">
                                                    CheckInTime: {item.checkInTime}
                                                </p>
                                                <p className="shrink-0">
                                                    CheckOutTime: {item.checkOutTime}
                                                </p>
                                            </td>
                                            :
                                            <></>
                                    )}

                                </td>
                                {/* Attendance Marked Section end */}
                            </tr>
                        );
                    })}
                    {/* Start date weeks'Names and serialNo end */}
                </tbody>
                {/* Start date weeks'Names and serialNo end */}
            </table>
            {/* Table Section End */}
        </main >
    )
}

export default AttendanceSheet