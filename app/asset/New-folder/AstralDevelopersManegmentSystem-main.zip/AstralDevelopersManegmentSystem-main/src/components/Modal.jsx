import { RiAttachmentLine, RiCheckDoubleLine, RiCloseLargeFill, RiSendPlane2Fill } from '@remixicon/react';
import { collection, doc, getDocs, query, setDoc, where } from 'firebase/firestore';
import { useEffect, useState } from 'react';
import Swal from 'sweetalert2';
import { db, storage } from '../config/firebase/firebaseConfig';
import { getDownloadURL, ref, uploadBytesResumable } from 'firebase/storage';

const Modal = ({ closeModal, handleOutsideClick, task }) => {

    const selectStyles = {
        background: `url('data:image/svg+xml,%3csvg aria-hidden=\'true\' xmlns=\'http://www.w3.org/2000/svg\' fill=\'none\' viewBox=\'0 0 10 6\'%3e %3cpath stroke=\'%236B7280\' stroke-linecap=\'round\' stroke-linejoin=\'round\' stroke-width=\'2\' d=\'m1 1 4 4 4-4\'/%3e %3c/svg%3e') right 0.75rem center no-repeat`,
        backgroundSize: '0',
        paddingRight: '2.5rem',
        WebkitPrintColorAdjust: 'exact',
        printColorAdjust: 'exact',
        display: 'inlineBlock',
        verticalAlign: 'top',
        overflow: 'auto',
        border: 'solid grey 1px',
    };

    const [formData, setFormData] = useState({
        title: task.title,
        description: task.description,
        department: task.department,
        lastDate: task.lastDate,
        assignee: task.assignee.map((el) => el.id),
        status: "pending",
        managerId: task.managerId,
        managerName: task.managerName,
        startDate: task.startDate,
        taskFiles: task.taskFiles,
        type: task.type,
        managerImage: task.managerImage,
        taskHour: task?.taskHour,
        decline: ''
    });





    const [searchText, setSearchText] = useState('');

    const [allUsers, setAllUser] = useState([]);

    useEffect(() => {
        getData()
    }, [allUsers])

    const getData = async () => {
        try {

            if (task?.type == 'Admin') {
                const q = query(collection(db, "users"), where('type', 'in', ['Employee', 'Manager']));
                const querySnapshot = await getDocs(q);
                const allUser = []
                querySnapshot.forEach((doc) => {
                    allUser.push({ id: doc.id, ...(doc.data()) })
                    setAllUser(allUser)
                });
            }

            const q = query(collection(db, "users"), where("type", "==", "Employee"), where("department", "==", task.department));

            const querySnapshot = await getDocs(q);
            const allUser = []
            querySnapshot.forEach((doc) => {
                allUser.push({ id: doc.id, ...(doc.data()) })
                setAllUser(allUser)
            });



        } catch (error) {
            console.error('Error fetching data:', error);
        }

    }



    const [files, setFiles] = useState([]);

    const handleFileChange = (event) => {

        const file = event.target.files[0];
        setFiles([...files, file])
    };

    const [progress, setProgress] = useState(0);
    const [URLs, setURLs] = useState(formData.taskFiles);

    const [loader, setLoader] = useState(false)


    const uploadImages = () => {
        setLoader(true)
        const promises = [];
        files.map((file) => { // Using forEach instead of map for side effects
            const storageRef = ref(storage, `taskFile/${file.name}`);
            const uploadTask = uploadBytesResumable(storageRef, file);
            promises.push(uploadTask);
            uploadTask.on(
                "state_changed",
                (snapshot) => {
                    const progress = Math.round(
                        (snapshot.bytesTransferred / snapshot.totalBytes) * 100
                    );
                    setProgress(progress);
                },
                (error) => {
                    console.log(error);
                },
                async () => {
                    await getDownloadURL(uploadTask.snapshot.ref).then((downloadURL) => {
                        setURLs((prevURLs) => [...prevURLs, downloadURL]);

                    });
                }
            );

        });
        Promise.all(promises)
            .then(() => setLoader(false))

            .catch((err) => console.log(err));
    };

    // console.log(URLs);


    const uploadeImage = () => {
        uploadImages()
    }


    const editData = async (e) => {
        e.preventDefault();
        const data = await setDoc(doc(db, "tasks", task.id), { ...formData, taskFiles: URLs, decline: '' });

        let timerInterval;
        Swal.fire({
            title: "Edit Successfully!",
            html: "Edit in  <b></b> milliseconds.",
            timer: 2000,
            timerProgressBar: true,
            didOpen: () => {
                Swal.showLoading();
                const timer = Swal.getPopup().querySelector("b");
                timerInterval = setInterval(() => {
                    timer.textContent = `${Swal.getTimerLeft()}`;
                }, 100);
            },
            willClose: () => {
                clearInterval(timerInterval);
            }
        }).then((result) => {
            if (result.dismiss === Swal.DismissReason.timer) {
                return closeModal()
            }

        });
    }


    const [time, setTime] = useState(false)

    const TaskTime = (e) => {
        const selectedTime = e.target.value;
        setFormData({ ...formData, taskHour: selectedTime })
    }










    return (
        <>
            <div className='max-w-screen-xl mx-auto p-4'>
                <div className="fixed inset-0 bg-gray-600 bg-opacity-50 overflow-auto p-10  w-full" id="modal" onClick={handleOutsideClick}>

                    <div className="top-10 mx-auto p-5 border lg:w-[98%] w-full  max-w-screen-lg shadow-lg rounded-md bg-gradient-to-bl from-teal-100 to-teal-200 ">

                        <div className="mt-3 text-center">
                            <div className="mx-auto flex items-center justify-center h-12 w-12 rounded-full bg-purple-100">
                                <img src="https://w7.pngwing.com/pngs/1018/119/png-transparent-computer-icons-editing-pencil-miscellaneous-angle-pencil.png" className='h-6 w-6 text-teal-500' alt="" />
                            </div>

                            <h3 className="text-lg leading-6 font-medium text-gray-900">Edit Task</h3>
                            <div className="mt-2 px-7 py-3">

                                <p className="text-xl text-gray-500">Change Title or Task Description</p>

                                <section className="py-1 bg-blueGray-50">
                                    <div className="w-full lg:w-8/12 px-4 mx-auto mt-6">
                                        <div className="relative flex flex-col min-w-0 break-words w-full mb-6 shadow-lg rounded-lg bg-blueGray-100 border-0">
                                        </div>


                                        <form onSubmit={editData} id='editTask' className='flex flex-wrap' >
                                            <div className="w-full  lg:w-12/12 px-4">

                                                <div className="relative lg:w-full w-auto mb-3">
                                                    <label className="block uppercase text-blueGray-600 mb-2 text-[20px] font-medium" htmlFor="grid-password">
                                                        Edit Task Title
                                                    </label>
                                                    <input
                                                        value={formData.title}
                                                        onChange={(e) => setFormData({ ...formData, title: e.target.value })}
                                                        name='title'
                                                        className="border-0 text-lg   px-3 py-3 placeholder-blueGray-300 text-blueGray-600 bg-white rounded  shadow focus:outline-none focus:ring w-full  ease-linear transition-all duration-150"
                                                        rows="4"
                                                        placeholder='Edit Task Title'
                                                    />
                                                </div>
                                            </div>


                                            <div className="w-full lg:w-12/12 px-4">
                                                <div className="relative w-full mb-3">
                                                    <label className="block uppercase text-blueGray-600 mb-2 text-[20px] font-medium" htmlFor="grid-password">
                                                        Edit Task Details
                                                    </label>
                                                    <textarea
                                                        value={formData.description}
                                                        onChange={(e) => setFormData({ ...formData, description: e.target.value })}
                                                        name='description'
                                                        className="border-0  px-3 py-3 placeholder-blueGray-300 text-blueGray-600 bg-white rounded  shadow focus:outline-none focus:ring w-full ease-linear transition-all duration-150"
                                                        rows="4"
                                                        placeholder='Edit Task Details...'
                                                    />
                                                </div>
                                            </div>


                                            {progress > 0 && (
                                                <div className="text-center font-bold text-teal-700 ">{progress}%</div>
                                            )}

                                            <div className="flex gap-2 items-center overflow-hidden">

                                                <label htmlFor="fileInputProfile" className=" flex cursor-pointer">
                                                    <span className="sr-only">Choose profile photo</span>
                                                    <input
                                                        id="fileInputProfile"
                                                        name='taskFiles'
                                                        multiple
                                                        type="file"
                                                        onChange={handleFileChange}
                                                        className="hidden"
                                                    />
                                                    <span className="file-upload-button lg:flex hidden  items-center gap-2 bg-teal-500 text-white py-2 px-4 rounded-md hover:bg-teal-600"> Tasks File <span><RiAttachmentLine size={30} /></span>
                                                    </span>

                                                    <span className="file-upload-button lg:hidden  items-center gap-2 bg-teal-500 text-white py-2 px-4 rounded-md hover:bg-teal-600" ><RiAttachmentLine size={30} /></span>
                                                </label>

                                                {loader == false ?

                                                    <div className='flex'>
                                                        <button onClick={uploadeImage} className=' lg:flex hidden items-center gap-2 file-upload-button bg-teal-500 text-white py-2 px-4 rounded-md hover:bg-teal-600' >Uploade Files <span><RiSendPlane2Fill size={30} /></span> </button>
                                                        <span onClick={uploadeImage} className='file-upload-button lg:hidden  items-center gap-2 bg-teal-500 text-white py-2 px-4 rounded-md hover:bg-teal-600' ><RiSendPlane2Fill size={30} /></span>
                                                    </div>
                                                    : <button disabled type="button" className="text-white bg-teal-700 hover:bg-teal-800 focus:ring-4 focus:ring-teal-300 font-medium rounded-lg text-sm px-5 py-2.5 text-center me-2  inline-flex items-center">
                                                        <svg aria-hidden="true" role="status" className="inline w-4 h-4 me-3 text-white animate-spin" viewBox="0 0 100 101" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                            <path d="M100 50.5908C100 78.2051 77.6142 100.591 50 100.591C22.3858 100.591 0 78.2051 0 50.5908C0 22.9766 22.3858 0.59082 50 0.59082C77.6142 0.59082 100 22.9766 100 50.5908ZM9.08144 50.5908C9.08144 73.1895 27.4013 91.5094 50 91.5094C72.5987 91.5094 90.9186 73.1895 90.9186 50.5908C90.9186 27.9921 72.5987 9.67226 50 9.67226C27.4013 9.67226 9.08144 27.9921 9.08144 50.5908Z" fill="#E5E7EB" />
                                                            <path d="M93.9676 39.0409C96.393 38.4038 97.8624 35.9116 97.0079 33.5539C95.2932 28.8227 92.871 24.3692 89.8167 20.348C85.8452 15.1192 80.8826 10.7238 75.2124 7.41289C69.5422 4.10194 63.2754 1.94025 56.7698 1.05124C51.7666 0.367541 46.6976 0.446843 41.7345 1.27873C39.2613 1.69328 37.813 4.19778 38.4501 6.62326C39.0873 9.04874 41.5694 10.4717 44.0505 10.1071C47.8511 9.54855 51.7191 9.52689 55.5402 10.0491C60.8642 10.7766 65.9928 12.5457 70.6331 15.2552C75.2735 17.9648 79.3347 21.5619 82.5849 25.841C84.9175 28.9121 86.7997 32.2913 88.1811 35.8758C89.083 38.2158 91.5421 39.6781 93.9676 39.0409Z" fill="currentColor" />
                                                        </svg>
                                                        Loading...
                                                    </button>
                                                }

                                            </div>



                                            <div className='flex items-center justify-center w-full flex-col' >

                                                {task?.taskHour ?
                                                    <article className='w-full lg:w-12/12 px-4 mt-4' >
                                                        <label className="block uppercase text-blueGray-600 mb-2 text-[20px] font-medium" htmlFor="time">
                                                            Select Task Hourly
                                                        </label>
                                                        <input onChange={TaskTime} className='w-full' value={task?.taskHour} type="datetime-local" />
                                                    </article>

                                                    : <> <div className="flex flex-wrap w-full ">
                                                        <div className="w-full lg:w-12/12 px-4">
                                                            <div className="relative w-full mb-3">
                                                                <label className="block uppercase text-blueGray-600 mb-2 text-[20px] font-medium" htmlFor="grid-password">
                                                                    Start Date of Task
                                                                </label>
                                                                <input
                                                                    value={formData.startDate}
                                                                    onChange={(e) => setFormData({ ...formData, startDate: e.target.value })}
                                                                    name='date'
                                                                    type="Date"
                                                                    className="text-lg  border-0 px-3 py-3 placeholder-blueGray-300 text-blueGray-600 bg-white rounded  shadow focus:outline-none focus:ring w-full ease-linear transition-all duration-150"
                                                                    required
                                                                />
                                                            </div>
                                                        </div>
                                                    </div>
                                                        {/* section 2 */}

                                                        {/* section 3 */}

                                                        <div className="flex flex-wrap w-full ">
                                                            <div className="w-full lg:w-12/12 px-4">
                                                                <div className="relative w-full mb-3">
                                                                    <label className="block uppercase text-blueGray-600 
                                              mb-2 text-[20px] font-medium" htmlFor="grid-password">
                                                                        Last Date of Submit Task
                                                                    </label>
                                                                    <input
                                                                        value={formData.lastDate}
                                                                        onChange={(e) => setFormData({ ...formData, lastDate: e.target.value })}
                                                                        name='date'
                                                                        type="Date"
                                                                        className="text-lg  border-0 px-3 py-3 placeholder-blueGray-300 text-blueGray-600 bg-white rounded  shadow focus:outline-none focus:ring w-full ease-linear transition-all duration-150"
                                                                        required
                                                                    />
                                                                </div>
                                                            </div>
                                                        </div></>}
                                            </div>

















































                                            <div className="flex flex-wrap w-full ">
                                                <div className="w-full lg:w-12/12 px-4">
                                                    <div className="relative w-full mb-3">


                                                        <label htmlFor="underline_select" className="block uppercase text-blueGray-600 mb-2 text-[20px] font-medium">Select Employees</label>

                                                        <div className='bg-white rounded p-4' >

                                                            <input
                                                                onChange={(e) => { setSearchText(e.target.value) }}
                                                                className='w-full '
                                                                type="search"
                                                                placeholder="Search Employee..."
                                                            />

                                                            <select
                                                                style={selectStyles}
                                                                value={formData.assignee} required onChange={(e) => {
                                                                    let items = e.target.selectedOptions;
                                                                    let assigneeArr = [];
                                                                    for (let i = 0; i < items.length; i++) {
                                                                        // console.log(items[i].getAttribute('value'))
                                                                        assigneeArr.push(items[i].getAttribute('value'))
                                                                    }
                                                                    setFormData({
                                                                        ...formData, assignee: assigneeArr
                                                                    })
                                                                }} name='select' id="underline_select" className="text-lg border-0 px-3 py-3 placeholder-blueGray-300 text-blueGray-600  shadow  focus:outline-none w-full ease-linear transition-all duration-150    " multiple>

                                                                {searchText ?
                                                                    allUsers.filter((x) => (x.name.toLowerCase().includes(searchText))).map((user, index) =>
                                                                        <option className=' appearance-none' key={user.id} value={user.id} > {index + 1}) {user.name}</option>
                                                                    )
                                                                    :
                                                                    allUsers.map((user, index) =>
                                                                        <option className=' appearance-none' key={user.id} value={user.id} > {index + 1}) {user.name}</option>
                                                                    )
                                                                }
                                                            </select>

                                                        </div>



                                                    </div>
                                                </div>
                                            </div>








                                        </form>
                                    </div>
                                </section >


                            </div>
                            <div className=" flex  items-center justify-center gap-10 px-4 py-3">

                                <button type='submit' form='editTask' id="ok-btn" className=" rounded-md bg-teal-700 text-white  py-2 px-4 font-semibold hover:bg-teal-800  transition-colors duration-150 ease-in-out">
                                    <RiCheckDoubleLine size={25} />
                                </button>

                                <button id="exit" className=" rounded-md bg-teal-700 text-white  py-2 px-4 font-semibold hover:bg-teal-800  transition-colors duration-150 ease-in-out" onClick={closeModal}>
                                    <RiCloseLargeFill />
                                </button>
                            </div>
                        </div>
                    </div>
                </div>

            </div >
        </>
    )
}

export default Modal
