import { RiBarChartGroupedFill, RiCloseFill, RiFileList3Fill, RiProfileFill, RiUser2Fill, RiUserAddFill, RiUserStarFill } from '@remixicon/react'
import React from 'react'
import { NavLink } from 'react-router-dom'

const SideBar = ({ref , openSideBar , user}) => {

  

  return (
    <>
      <div ref={ref} className="  w-full text-white bg-gradient-to-b from-teal-800 to-teal-400 min-h-[calc(100vh_-_72px)] max-lg:fixed max-lg:top-0 max-lg:inset-0 max-lg:z-50 max-lg:w-9/12 max-lg:max-w-xs max-lg:h-full max-lg:-translate-x-full transition-transform relative max-lg:pt-8">
        <button className="text-teal-300 lg:hidden absolute  top-2 right-2" onClick={openSideBar}>
          <RiCloseFill size={30} />
        </button>

        <nav className="p-5 ">
          <div className='flex items-center gap-4 bg-gradient-to-b from-teal-200 to-teal-50 rounded-md p-2'>
            <div>
              <img src={user.imageUrl} alt="" className=" size-14 object-cover rounded-full overflow-hidden" />
            </div>
            <div className='flex items-center justify-center flex-col gap-[-2]' >
              <p className='text-lg font-bold text-teal-800'>{user.name} </p>
              <p className='text-slate-600'>{user.type}</p>
            </div>
          </div>

          <ul className="flex flex-col gap-4 mt-4">
            <NavLink end to="/dashboard" className="flex gap-4 items-center hover:text-teal-300 transition-colors">
              <span className='text-teal-300 '>
                <RiBarChartGroupedFill size={24} />
              </span>
              <span>Dashboard</span>
            </NavLink>
            <NavLink end to="/dashboard/register" className="flex gap-4 items-center hover:text-teal-300 transition-colors">
              <span className='text-teal-300' >
                <RiUserAddFill size={24} />
              </span>
              <span>Register</span>
            </NavLink>
            <NavLink end to="/dashboard/employee" className="flex gap-4 items-center hover:text-teal-300 transition-colors">
              <span className='text-teal-300'>
                <RiUser2Fill size={24} />
              </span>
              <span>Employee</span>
            </NavLink>
            <NavLink end to="/dashboard/managers" className="flex gap-4 items-center hover:text-teal-300 transition-colors">
              <span className='text-teal-300'>
                <RiUserStarFill size={24} />
              </span>
              <span>Manager</span>
            </NavLink>

            <NavLink end to="/dashboard/allEmployeesTask" className="flex gap-4 items-center hover:text-teal-300 transition-colors">
              <span className='text-teal-300'>
                <RiFileList3Fill size={24} />
              </span>
              <span>All Employees Tasks</span>
            </NavLink>

            <NavLink end to="/dashboard/profile" className="flex gap-4 items-center hover:text-teal-300 transition-colors">
              <span className='text-teal-300'>
                <RiProfileFill size={24} />
              </span>
              <span>Profile</span>
            </NavLink>
          </ul>
        </nav>
      </div>
    </>
  )
}

export default SideBar
