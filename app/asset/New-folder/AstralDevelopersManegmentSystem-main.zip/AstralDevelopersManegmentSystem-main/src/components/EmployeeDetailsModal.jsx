import React from 'react'

const EmployeeDetailsModal = ({ closeModalDetails, employeesDetail, handleModalDetailsOutside }) => {

    // console.log(employeesDetail);

    const offerLetter = employeesDetail.offerLetter;

    const combinedStyles = {
        color: 'green', // Default color for link
        backgroundColor: 'transparent',
        textDecoration: 'none',
        '&:visited': {
            color: '#FF0000',
        },
        '&:hover': {
            color: 'red',
            textDecoration: 'underline',
        },
        '&:active': {
            color: 'yellow',
            textDecoration: 'underline',
        },
    };


    const formatTimeToHHMM = (timeString) => {
        // Extract hours, minutes, and period (AM/PM) from the time string
        const [time, period] = timeString.split(' ');
        const [hoursStr, minutesStr] = time.split(':');
        let hours = parseInt(hoursStr, 10);
        const minutes = parseInt(minutesStr, 10);

        // Convert hours to 24-hour format if necessary
        if (period === "PM" && hours !== 12) {
            hours += 12;
        } else if (period === "AM" && hours === 12) {
            hours = 0;
        }

        // Pad hours with leading zero if necessary
        const formattedHours = hours.toString().padStart(2, '0');

        // Return the formatted time in "HH:mm" format
        return `${formattedHours}:${minutesStr}`;
    };

    const formattedTime = formatTimeToHHMM(employeesDetail.employeeTiming);


    // console.log(formattedTime);


    return (
        <div className="fixed top-0 left-0 grid justify-center z-50 items-center w-full h-screen bg-black bg-opacity-40 p-2 
        overflow-auto" id="modal1" onClick={handleModalDetailsOutside} >

            <div className="bg-white rounded-lg shadow-lg p-6 flex items-center justify-center     ">

                <button
                    type="button"
                    className="  absolute top-3 right-3 text-teal-500 bg-white hover:bg-gray-200 hover:text-gray-900 rounded-lg text-sm w-8 h-8 flex justify-center items-center"
                    onClick={closeModalDetails}>

                    <svg
                        className="w-5 h-5"
                        aria-hidden="true"
                        xmlns="http://www.w3.org/2000/svg"
                        fill="none"
                        viewBox="0 0 14 14">
                        <path
                            stroke="currentColor"
                            strokeLinecap="round"
                            strokeLinejoin="round"
                            strokeWidth="2"
                            d="m1 1 6 6m0 0 6 6M7 7l6-6M7 7l-6 6"
                        />
                    </svg>

                    <span className="sr-only">
                        Close modal
                    </span>

                </button>

                <main className="max-w-screen-xl mx-auto p-4 ">
                    <div className='text-2xl text-center mb-5 '>
                        Employee Profile
                    </div>
                    <form className='p-6  border border-teal-600 rounded-xl  '>

                        <div className="grid grid-cols-2 gap-6 max-sm:grid-cols-1">
                            <div className="flex flex-col gap-2">
                                <label htmlFor="first_name" className="">
                                    Name
                                </label>
                                <input disabled defaultValue={employeesDetail.name} type="text" name="name" id="first_name" className=" rounded border border-gray-300 bg-gray-50" />
                            </div>

                            <div className="flex flex-col gap-2">
                                <label htmlFor="email" className="">
                                    Email
                                </label>

                                <input disabled defaultValue={employeesDetail.email} type="email" name="email" id="email" className=" rounded border border-gray-300 bg-gray-50" />
                            </div>

                            <div className="flex flex-col gap-2">
                                <label htmlFor="phone" className="">
                                    Phone
                                </label>

                                <input disabled defaultValue={employeesDetail.phoneNumber} type="text" name="phoneNumber" id="phone" className=" rounded border border-gray-300 bg-gray-50" />
                            </div>

                            <div className="flex flex-col gap-2">
                                <label htmlFor="accountNumber" className="">
                                    Account Number
                                </label>
                                <input disabled defaultValue={employeesDetail.accountNumber} type="text" name="accountNumber" id="account Number" className="rounded border border-gray-300 bg-gray-50" placeholder="Ac/Number" />
                            </div>

                            <div className="flex flex-col gap-2">
                                <label htmlFor="accountTile" className="">
                                    Account Tilte
                                </label>
                                <input disabled defaultValue={employeesDetail.accountTitle} type="text" name="accountTitle" id="account Title" className="rounded border border-gray-300 bg-gray-50" placeholder="Ac/Title" />
                            </div>
                            <div className="flex flex-col gap-2">
                                <label htmlFor="accountTile" className="">
                                    Bank Name
                                </label>
                                <input disabled defaultValue={employeesDetail.bankName} type="text" name="accountTitle" id="account Title" className="rounded border border-gray-300 bg-gray-50" placeholder="Ac/Title" />
                            </div>



                            <div className="flex flex-col gap-2">
                                <label htmlFor="cnic" className="">
                                    Cnic
                                </label>
                                <input
                                    disable d defaultValue={employeesDetail.cnic}
                                    type="number"
                                    name="cnic"
                                    id="cnic"
                                    className="[appearance:textfield] [&::-webkit-outer-spin-button]:appearance-none [&::-webkit-inner-spin-button]:appearance-none rounded border border-gray-300 bg-gray-50"

                                />
                            </div>

                            <div>
                                <label htmlFor="type" className="block mb-2 text-sm font-medium text-gray-900 dark:text-white">
                                    Employee  Type
                                </label>
                                <input disabled defaultValue={employeesDetail.type} className="bg-gray-50 border border-gray-300 text-gray-9 00 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 block w-full p-2.5 dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-blue-500 dark:focus:border-blue-500" type="text" />
                            </div>

                            <div className="flex flex-col gap-2">
                                <label htmlFor="Address">
                                    Employee Address
                                </label>
                                <input disabled defaultValue={employeesDetail.address} name='address' type="text" id="Address" className=" rounded border border-gray-300 bg-gray-50 " placeholder="Address" />
                            </div>

                            <div className="flex flex-col gap-2">
                                <label htmlFor="Qualification">
                                    Qualification
                                </label>
                                <input disabled defaultValue={employeesDetail.qualification} name='qualification' type="text" id="Qualifi cation" className="rounded border border-gray-300 bg-gray-50" placeholder="Qualification"
                                />
                            </div>




                            <div>
                                <label htmlFor="Department" className="block mb-2 text-sm font-medium text-gray-900 dark:text-white">
                                    Employee Department
                                </label>
                                <input disabled defaultValue={employeesDetail.department} className="bg-gray-50 border border-gray -300 text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 block w-full p-2.5 dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-blue-500 dark:focus:border-blue-500" type="text" />
                            </div>

                            <div>
                                <label htmlFor="Position" className="block mb-2 text-sm font-medium text-gray-900 dark:text-white">
                                    Employee Position
                                </label>
                                <input disabled defaultValue={employeesDetail.position} className="bg-gray-50 border border-gray-300 text-gray-9 00 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 block w-full p-2.5 dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-blue-500 dark:focus:border-blue-500" type="text" />
                            </div>

                            <div className="flex flex-col gap-2">
                                <label htmlFor="Joining Date">
                                    Joining Date
                                </label>
                                <input disabled defaultValue={employeesDetail.joiningDate} name='joiningDate' type="date" id="Joining  Date" className="rounded border border-gray-300 bg-gray-50" placeholder="Joining Date" />
                            </div>



                            <div className="grid grid-cols-1 sm:grid-cols-2 items-center gap-2">

                                <div className="flex flex-col justify-center gap-2 ">
                                    <label htmlFor="Salary">
                                        Salary
                                    </label>
                                    <input disabled defaultValue={employeesDetail.salary} name='salary' type="number" id="Salary" className=" [appearance:textfield] [&::-webkit-outer-spin-button]:appearance-none [&::-webkit-inner-spin-button]:appearance-none w-full rounded border border-gray-300 bg-gray-50" min={0} maxLength={10} placeholder="Salary" />
                                </div>

                                <div className="flex flex-col gap-2 ">
                                    <label htmlFor="Id">
                                        ID
                                    </label>
                                    <input
                                        name='r egisterId'
                                        defaultValue={employeesDetail.registerId}
                                        type="text"
                                        id="id"
                                        className="w-full rounded border border-gray-300 bg-gray-50"
                                        readOnly
                                    />
                                </div>
                            </div>


                            <div className="flex flex-col gap-2">
                                <label htmlFor="employeeTiming">
                                    Employee Timing
                                </label>
                                <input disabled name='employeeTiming' value={formattedTime} type="time" id="employeeTiming"
                                    className="  rounded border border-gray-300 bg-gray-50 relative "
                                    placeholder="employeeTiming" />
                            </div>


                            <div className="flex flex-col gap-2 ">
                                    <label htmlFor="Id">
                                        Employee Shift
                                    </label>
                                    <input
                                        name='r egisterId'
                                        defaultValue={employeesDetail.employeeShift}
                                        type="text"
                                        id="id"
                                        className="w-full rounded border border-gray-300 bg-gray-50"
                                        readOnly
                                    />
                                </div>















                        </div>
                        <article className="flex items-center justify-center  lg:flex-row flex-col lg:gap-0 lg:mt-4 gap-2 flex-wrap mt-6 ">

                            <div className="lg:w-[50%] w-auto mb-4">
                                <img src={employeesDetail.imageUrl} alt="Ptofile Image" />
                            </div>

                            <div className="lg:w-[50%] w-auto mb-4">
                                <img src={employeesDetail.cvUrl} alt="Cv" />
                            </div>

                            <div className="lg:w-[50%] w-auto mb-4">
                                <img src={employeesDetail.cnicImage} alt="Cnic" />
                            </div>
                        </article>

                        <div className='flex items-center justify-center' >
                            <a style={combinedStyles} target="_blank" href={offerLetter} className=" border border-teal-700 px-2 rounded-md font-bold text-lg" >OfferLetter</a>
                        </div>
                    </form >
                </main >
            </div>
        </div>
    )
}

export default EmployeeDetailsModal
