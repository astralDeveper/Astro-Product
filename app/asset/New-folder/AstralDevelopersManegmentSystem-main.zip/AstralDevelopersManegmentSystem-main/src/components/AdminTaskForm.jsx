import { RiArrowLeftLine, RiAttachmentLine, RiSendPlane2Fill, RiUpload2Line } from '@remixicon/react';
import { addDoc, collection, getDocs, query, where } from 'firebase/firestore';
import React, { useEffect, useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import Swal from 'sweetalert2';
import { db, storage } from '../config/firebase/firebaseConfig';
import { useAuth } from '../screens/AuthProvider';
import { getDownloadURL, ref, uploadBytesResumable } from 'firebase/storage';

const AddTask = () => {


    const selectStyles = {
        background: `url('data:image/svg+xml,%3csvg aria-hidden=\'true\' xmlns=\'http://www.w3.org/2000/svg\' fill=\'none\' viewBox=\'0 0 10 6\'%3e %3cpath stroke=\'%236B7280\' stroke-linecap=\'round\' stroke-linejoin=\'round\' stroke-width=\'2\' d=\'m1 1 4 4 4-4\'/%3e %3c/svg%3e') right 0.75rem center no-repeat`,
        backgroundSize: '0',
        paddingRight: '2.5rem',
        WebkitPrintColorAdjust: 'exact',
        printColorAdjust: 'exact',
        display: 'inlineBlock',
        verticalAlign: 'top',
        overflow: 'auto',
        border: 'solid grey 1px',
    };



    const { user } = useAuth();


    const [searchText, setSearchText] = useState('');

    const [notLoading, SetNotLoading] = useState(true);

    const loadings = () => {
        if (notLoading === true) {
            SetNotLoading(false)
        } else {
            SetNotLoading(true)
        }
    }

    const [formData, setFormData] = useState({
        title: '',
        department: user.department,
        description: '',
        startDate: '',
        lastDate: '',
        assignee: [],
        status: 'pending',
        managerId: user.id,
        managerName: user.name,
        managerImage: user.imageUrl,
        taskFiles: '',
        type: user.type,
        taskHour: '',
        decline: ''
    });

    // console.log();

    const [allUsers, setAllUser] = useState([]);

    useEffect(() => {
        getData()
    }, [])

    const getData = async () => {
        try {
            const q = query(collection(db, "users"), where('type', 'in', ['Employee', 'Manager']));
            const querySnapshot = await getDocs(q);

            const allUser = []
            querySnapshot.forEach((doc) => {
                allUser.push({ id: doc.id, ...(doc.data()) })
                setAllUser(allUser)
            });



        } catch (error) {
            console.error('Error fetching data:', error);
        }

    }


    const navigate = useNavigate();



    const [files, setFiles] = useState([]);

    const handleFileChange = (event) => {

        const file = event.target.files[0];
        setFiles([...files, file])
    };

    const [progress, setProgress] = useState(0);
    const [URLs, setURLs] = useState([]);

    const [loader, setLoader] = useState(false)

    const uploadImages = () => {
        setLoader(true)
        const promises = [];
        files.map((file) => { // Using forEach instead of map for side effects
            const storageRef = ref(storage, `taskFile/${file.name}`);
            const uploadTask = uploadBytesResumable(storageRef, file);
            promises.push(uploadTask);
            uploadTask.on(
                "state_changed",
                (snapshot) => {
                    const progress = Math.round(
                        (snapshot.bytesTransferred / snapshot.totalBytes) * 100
                    );
                    setProgress(progress);
                },
                (error) => {
                    console.log(error);
                },
                async () => {
                    await getDownloadURL(uploadTask.snapshot.ref).then((downloadURL) => {
                        setURLs((prevURLs) => [...prevURLs, downloadURL]);

                    });
                }
            );
        });
        Promise.all(promises)
            .then(() => setLoader(false))

            .catch((err) => console.log(err));
    };

    // console.log(URLs);


    const uploadeImage = () => {
        uploadImages()
    }

    const handleSubmit = async () => {
        const docRef = await addDoc(collection(db, "tasks"), { ...formData, taskFiles: URLs });
        setFormData({
            title: '',
            description: '',
            startDate: '',
            lastDate: '',
            assignee: [],
            status: 'pending',
            managerId: user.id,
            managerName: user.name,
        })
        navigate('/dashboard/allEmployeesTask')
        Swal.fire({
            title: "Add task",
            text: "Task successfully assign",
            icon: "success"
        });
    }



    const radioStyle = {
        appearance: 'none',
        WebkitAppearance: 'none',
        MozAppearance: 'none',
        width: '16px',
        height: '16px',
        borderRadius: '50%',
        border: '2px solid #4CAF50',
        outline: 'none',
        cursor: 'pointer',
        marginRight: '5px',

    };

    const labelStyle = {
        cursor: 'pointer'
    };





    const [time, setTime] = useState(false)

    const TaskTime = (e) => {
        const selectedTime = e.target.value;
        setFormData({ ...formData, taskHour: selectedTime })
    }






    return (
        <main className='max-w-screen-xl mx-auto p-4'>
            <section className="py-1 bg-blueGray-50">
                <div className="w-full lg:w-8/12 px-4 mx-auto mt-6">
                    <div className="relative flex flex-col min-w-0 break-words w-full mb-6 bg-[#e8f9f9] shadow-lg rounded-lg bg-blueGray-100 border-0">

                        <div className="flex items-center justify-start p-4 "  >
                            <Link to={-1} className='rounded-full hover:text-[white] hover:bg-teal-800' >
                                <RiArrowLeftLine />
                            </Link>
                        </div>

                        <div className="rounded-t  mb-0 px-6 py-6">
                            <div className="text-center flex justify-between">
                                <h6 className="text-blueGray-700 text-xl font-bold">
                                    Add Tasks
                                </h6>
                            </div>

                        </div>
                        <div className="flex-auto px-4 lg:px-10 py-10 pt-0">



                            <h6 className="text-blueGray-400 text-lg mt-3 mb-6 font-bold uppercase">
                                Tasks Information
                            </h6>
                            <div className="flex flex-wrap">
                                <div className="w-full  px-4">
                                    <div className="relative w-full mb-3">
                                        <label className="block uppercase text-blueGray-600 
                                              mb-2 text-[20px] font-medium" htmlFor="grid-password">
                                            Task Title
                                        </label>
                                        <input value={formData.title} onChange={(e) => setFormData({ ...formData, title: e.target.value })} name='title' type="text" className="border-0 px-3 py-3 placeholder-blueGray-300 text-blueGray-600 bg-white rounded text-lg shadow focus:outline-none focus:ring w-full ease-linear transition-all duration-150   " placeholder='Task title' required />
                                    </div>
                                </div>

                                <div className="w-full lg:w-12/12 px-4">
                                    <div className="relative w-full mb-3">
                                        <label className="block uppercase text-blueGray-600 
                                              mb-2 text-[20px] font-medium" htmlFor="grid-password">
                                            Task Details
                                        </label>
                                        <textarea
                                            value={formData.description}
                                            onChange={(e) => setFormData({ ...formData, description: e.target.value })}
                                            name='description'
                                            className="border-0 text-lg  px-3 py-3 placeholder-blueGray-300 text-blueGray-600 bg-white rounded  shadow focus:outline-none focus:ring w-full ease-linear transition-all duration-150"
                                            rows="4"
                                            placeholder='Task Details...'
                                            required
                                        />
                                    </div>
                                </div>

                                {progress > 0 && (
                                    <div className="text-center font-bold text-teal-700 ">{progress}%</div>
                                )}

                                <div className="flex gap-2 items-center overflow-hidden">
                                    <label htmlFor="fileInputProfile" className=" flex cursor-pointer">
                                        <span className="sr-only">Choose profile photo</span>
                                        <input
                                            id="fileInputProfile"
                                            name='avatarUrl'
                                            multiple
                                            type="file"
                                            onChange={handleFileChange}
                                            className="hidden"
                                        />
                                        <span className="file-upload-button lg:flex hidden  items-center gap-2 bg-teal-500 text-white py-2 px-4 rounded-md hover:bg-teal-600"> Tasks File <span><RiAttachmentLine size={30} /></span>
                                        </span>

                                        <span className="file-upload-button lg:hidden  items-center gap-2 bg-teal-500 text-white py-2 px-4 rounded-md hover:bg-teal-600" ><RiAttachmentLine size={30} /></span>
                                    </label>

                                    {loader == false ?

                                        <div className='flex'>
                                            <button onClick={uploadeImage} className=' lg:flex hidden items-center gap-2 file-upload-button bg-teal-500 text-white py-2 px-4 rounded-md hover:bg-teal-600' >Uploade Files <span><RiSendPlane2Fill size={30} /></span> </button>
                                            <span onClick={uploadeImage} className='file-upload-button lg:hidden  items-center gap-2 bg-teal-500 text-white py-2 px-4 rounded-md hover:bg-teal-600' ><RiSendPlane2Fill size={30} /></span>
                                        </div>
                                        : <button disabled type="button" className="text-white bg-teal-700 hover:bg-teal-800 focus:ring-4 focus:ring-teal-300 font-medium rounded-lg text-sm px-5 py-2.5 text-center me-2  inline-flex items-center">
                                            <svg aria-hidden="true" role="status" className="inline w-4 h-4 me-3 text-white animate-spin" viewBox="0 0 100 101" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                <path d="M100 50.5908C100 78.2051 77.6142 100.591 50 100.591C22.3858 100.591 0 78.2051 0 50.5908C0 22.9766 22.3858 0.59082 50 0.59082C77.6142 0.59082 100 22.9766 100 50.5908ZM9.08144 50.5908C9.08144 73.1895 27.4013 91.5094 50 91.5094C72.5987 91.5094 90.9186 73.1895 90.9186 50.5908C90.9186 27.9921 72.5987 9.67226 50 9.67226C27.4013 9.67226 9.08144 27.9921 9.08144 50.5908Z" fill="#E5E7EB" />
                                                <path d="M93.9676 39.0409C96.393 38.4038 97.8624 35.9116 97.0079 33.5539C95.2932 28.8227 92.871 24.3692 89.8167 20.348C85.8452 15.1192 80.8826 10.7238 75.2124 7.41289C69.5422 4.10194 63.2754 1.94025 56.7698 1.05124C51.7666 0.367541 46.6976 0.446843 41.7345 1.27873C39.2613 1.69328 37.813 4.19778 38.4501 6.62326C39.0873 9.04874 41.5694 10.4717 44.0505 10.1071C47.8511 9.54855 51.7191 9.52689 55.5402 10.0491C60.8642 10.7766 65.9928 12.5457 70.6331 15.2552C75.2735 17.9648 79.3347 21.5619 82.5849 25.841C84.9175 28.9121 86.7997 32.2913 88.1811 35.8758C89.083 38.2158 91.5421 39.6781 93.9676 39.0409Z" fill="currentColor" />
                                            </svg>
                                            Loading...
                                        </button>
                                    }

                                </div>

                            </div>




                            {/* section 2 */}
                            <h6 className="text-blueGray-400 text-lg mt-3 mb-6 font-bold uppercase">
                                Task Alerts
                            </h6>


                            <article>
                                <div className='flex items-center gap-1'>
                                    <input onChange={() => { setTime(false) }} type="checkbox" id="hourly" style={radioStyle} name="drone" value="hourly" checked={time == "hourly" ? true : false} />
                                    <label htmlFor="hourly" style={labelStyle}>Hourly</label>
                                </div>

                                <div className='flex items-center gap-1'>
                                    <input onChange={() => { setTime(true) }} type="checkbox" id="days" style={radioStyle} name="drone" value="days"
                                        checked={time == "days" ? true : false} />
                                    <label htmlFor="days" style={labelStyle}>Days</label>
                                </div>
                            </article>


                            {time == false ?
                                <article className='w-full lg:w-12/12 px-4 mt-4' >
                                    <label className="block uppercase text-blueGray-600 mb-2 text-[20px] font-medium" htmlFor="time">
                                        Select Task Hourly
                                    </label>
                                    <input onChange={TaskTime} className='w-full' type="datetime-local" />
                                </article>

                                : <> <div className="flex flex-wrap">
                                    <div className="w-full lg:w-12/12 px-4">
                                        <div className="relative w-full mb-3">
                                            <label className="block uppercase text-blueGray-600 
                                              mb-2 text-[20px] font-medium" htmlFor="grid-password">
                                                Start Date of Task
                                            </label>
                                            <input
                                                value={formData.startDate}
                                                onChange={(e) => setFormData({ ...formData, startDate: e.target.value })}
                                                name='date'
                                                type="Date"
                                                className="text-lg  border-0 px-3 py-3 placeholder-blueGray-300 text-blueGray-600 bg-white rounded  shadow focus:outline-none focus:ring w-full ease-linear transition-all duration-150"
                                                required
                                            />
                                        </div>
                                    </div>
                                </div>
                                    {/* section 2 */}

                                    {/* section 3 */}

                                    <div className="flex flex-wrap">
                                        <div className="w-full lg:w-12/12 px-4">
                                            <div className="relative w-full mb-3">
                                                <label className="block uppercase text-blueGray-600 
                                              mb-2 text-[20px] font-medium" htmlFor="grid-password">
                                                    Last Date of Submit Task
                                                </label>
                                                <input
                                                    value={formData.lastDate}
                                                    onChange={(e) => setFormData({ ...formData, lastDate: e.target.value })}
                                                    name='date'
                                                    type="Date"
                                                    className="text-lg  border-0 px-3 py-3 placeholder-blueGray-300 text-blueGray-600 bg-white rounded  shadow focus:outline-none focus:ring w-full ease-linear transition-all duration-150"
                                                    required
                                                />
                                            </div>
                                        </div>
                                    </div></>}








                            {/* section 3 */}


                            {/* Add new Start */}




                            {/* Add new End */}



                            {/* section 4 */}


                            <h6 className="text-blueGray-400 text-lg mt-3 mb-6 font-bold uppercase">
                                Select Employee Assigned Task
                            </h6>

                            <div className="flex flex-wrap">
                                <div className="w-full lg:w-12/12 px-4">
                                    <div className="relative w-full mb-3">


                                        <label htmlFor="underline_select" className="block uppercase text-blueGray-600 mb-2 text-[20px] font-medium">Select Employees</label>

                                        <div className='bg-white rounded p-4' >

                                            <input
                                                onChange={(e) => { setSearchText(e.target.value) }}
                                                className='w-full '
                                                type="search"
                                                placeholder="Search Employee..."
                                            />

                                            <select
                                                style={selectStyles}
                                                value={formData.assignee} required onChange={(e) => {
                                                    let items = e.target.selectedOptions;
                                                    let assigneeArr = [];
                                                    for (let i = 0; i < items.length; i++) {
                                                        // console.log(items[i].getAttribute('value'))
                                                        assigneeArr.push(items[i].getAttribute('value'))
                                                    }
                                                    setFormData({ ...formData, assignee: assigneeArr })
                                                }} name='select' id="underline_select" className="text-lg border-0 px-3 py-3 placeholder-blueGray-300 text-blueGray-600  shadow  focus:outline-none w-full ease-linear transition-all duration-150    " multiple>

                                                {searchText ?
                                                    allUsers.filter((x) => (x.name.toLowerCase().includes(searchText))).map((user, index) =>
                                                        <option className=' appearance-none' key={user.id} value={user.id} > {index + 1}) {user.name}</option>
                                                    )
                                                    :
                                                    allUsers.map((user, index) =>
                                                        <option className=' appearance-none' key={user.id} value={user.id} > {index + 1}) {user.name}</option>
                                                    )
                                                }
                                            </select>

                                        </div>



                                    </div>
                                </div>
                            </div>

                            {/* section 4 */}


                            {notLoading === true ? (<div className='flex items-center justify-center'>
                                <button
                                    onClick={handleSubmit}
                                    type="submit"
                                    className="border-0 rounded-md w-full placeholder-blueGray-300 text-blueGray-60 bg-teal-700 text-white  py-2 px-4 font-semibold hover:bg-teal-800 "
                                >
                                    Assign Task
                                </button>
                            </div>
                            ) : (
                                <div className="flex items-center justify-center border-0 px-3 py-3 placeholder-blueGray-300 text-blueGray-600 bg-white rounded text-lg shadow focus:outline-none focus:ring w-full ease-linear transition-all duration-150 cursor-pointer ">
                                    <div className="  inline-block h-8 w-8 animate-spin rounded-full border-4 border-solid border-[blue] border-e-transparent align-[-0.125em] text-primary motion-reduce:animate-[spin_1.5s_linear_infinite]" role="status">
                                        <button className="!absolute !-m-px !h-px !w-px !overflow-hidden !whitespace-nowrap !border-0 !p-0 ![clip:rect(0,0,0,0)]">Loading...</button>
                                    </div>
                                </div>
                            )}

                        </div>
                    </div>

                </div >
            </section >
        </main>
    )
}

export default AddTask
