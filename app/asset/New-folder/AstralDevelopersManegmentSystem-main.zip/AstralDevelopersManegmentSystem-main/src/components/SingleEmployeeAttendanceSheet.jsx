import { query } from "firebase/database";
import { collection, getDocs, where } from "firebase/firestore";
import React, { useEffect, useState } from "react";
import { NavLink, useLocation } from "react-router-dom";
import { db } from "../config/firebase/firebaseConfig";
import { RiArrowGoBackFill } from "@remixicon/react";

const SingleEmployeeAttendanceSheet = () => {
    const currentDateWeek = listDaysAndDatesOfCurrentMonth();

    function listDaysAndDatesOfCurrentMonth() {
        const today = new Date();
        const currentMonth = today.getMonth();
        const currentYear = today.getFullYear();
        const daysInMonth = new Date(currentYear, currentMonth + 1, 0).getDate();

        const days = [];

        for (let i = 1; i <= daysInMonth; i++) {
            const date = new Date(currentYear, currentMonth, i);
            const dayOfWeek = date.toLocaleDateString("en-US", { weekday: "long" });
            days.push({
                attendanceWeeks: `${dayOfWeek}`,
                attendanceDate: `${date.toLocaleDateString()}`,
                sNo: i,
            });
        }
        return days;
    }

    const currentDate = new Date();
    const months = [
        "January",
        "February",
        "March",
        "April",
        "May",
        "June",
        "July",
        "August",
        "September",
        "October",
        "November",
        "December",
    ];
    const currentMonthName = months[currentDate.getMonth()];

    const location = useLocation();
    const singleEmployee = location.state;

    const [singleAttendant, setSingleAttendant] = useState([]);
    const [singleAttendants, setSingleAttendants] = useState();
    const [object, setObject] = useState()




    const getAttendantEmployee = async () => {

        const q = query(
            collection(db, "attendance"),
            where("userId", "==", singleEmployee.id),
        );
        const allUsers = [];
        const querySnapshot = await getDocs(q);
        querySnapshot.forEach((doc) => {
            allUsers.push({ id: doc.id, ...doc.data() });
        });
        let a = allUsers.filter((x) => x.attendanceMonth == currentMonthName);
        setSingleAttendant(a);
        setSingleAttendants(...a)

    };


    console.log();




    const todayDate = new Date();
    const dateString = todayDate.toLocaleDateString();


    let onTime;
    let halfDay;
    let Late;

    const filteredOnTime = singleAttendant.filter(item => item.liveStatus === 'On Time');
    const filteredHalfDay = singleAttendant.filter(item => item.liveStatus === 'HalfDay');
    const filteredLate = singleAttendant.filter(item => item.liveStatus === 'Late');


    onTime = filteredOnTime;
    halfDay = filteredHalfDay;
    Late = filteredLate;


    useEffect(() => {
        getAttendantEmployee();

    }, []);

    const a = singleAttendant.filter((x) => x.attendanceDate !== currentDateWeek.filter((b) => b.attendanceDate));

    const b = a.map((item) => item.attendanceDate)


    return (
        <main className="max-w-screen-xl mx-auto p-4">
            <NavLink 
                to={"/dashboard/allStudentsAttendanceList"} >

                <button className='bg-teal-400 px-8 rounded-lg w-fill py-2 ' >
                    <RiArrowGoBackFill size={24} color="#fff" />
                </button>
            </NavLink>

            <div className="relative overflow-x-auto shadow-lg sm:rounded-lg ">
                <article className=" lg:grid lg:grid-cols-2 grid row-span-2 gap-4 justify-center p-10 ">
                    <div className=" lg:justify-self-end justify-center lg:hidden block  ">
                        <img
                            className="rounded-full w-52 h-52 shrink-0 "
                            src={singleEmployee.imageUrl}
                            alt="image"
                        />
                    </div>

                    <div className=" lg:justify-start justify-center flex items-start mt-20 flex-col ">
                        <div className="font-medium text-lg text-justify">
                            #ID : {singleEmployee?.registerId}
                        </div>
                        <div className="font-medium text-lg text-justify">
                            Name : {singleEmployee?.name}
                        </div>
                        <div className="font-medium text-lg text-justify">
                            Shift : {singleEmployee?.employeeShift}
                        </div>
                        <div className="font-medium text-lg text-justify">
                            Department : {singleEmployee?.department}
                        </div>
                        <div className="font-medium text-lg text-justify">
                            Current Attendance Month : {currentMonthName}
                        </div>
                    </div>

                    <div className=" lg:justify-self-end justify-center lg:block hidden">
                        <img
                            className="rounded-full w-52 h-52 shrink-0 border-4 border-teal-600 object-cover "
                            src={singleEmployee.imageUrl}
                            alt="image"
                        />
                    </div>
                </article>

                <table className="w-full text-sm text-left rtl:text-right text-gray-500 dark:text-gray-400">
                    <thead className="text-xs text-gray-700 uppercase bg-gray-50">
                        <tr>
                            <th scope="col" className="px-6 py-3">
                                Sno
                            </th>
                            <th scope="col" className="px-6 py-3">
                                Day
                            </th>
                            <th scope="col" className="px-6 py-3">
                                Date
                            </th>
                            <th scope="col" className="px-6 py-3">
                                Attendance
                            </th>
                        </tr>
                    </thead>

                    <tbody>
                        {currentDateWeek.length > 0 ? (
                            currentDateWeek.map((date, indexs) => {
                                return (
                                    <tr
                                        key={indexs}
                                        className="odd:bg-white shrink-0 even:bg-gray-50 border-b  "
                                    >
                                        <td className="px-6 py-4 font-medium text-gray-900 whitespace-nowrap">
                                            {date.sNo}
                                        </td>
                                        <td className="px-6 py-4 text-gray-900">
                                            {date.attendanceWeeks}
                                        </td>
                                        <td className="px-6 py-4 text-gray-900">
                                            {date.attendanceDate}
                                        </td>
                                        {
                                            a.map((item, indexes) =>


                                                b[indexes] === date.attendanceDate ?
                                                    <td
                                                        key={item.id}
                                                        className={`px-6 shrink-0 flex lg:flex-row flex-col  justify-evenly py-4 text-base font-medium  ${item.attendance === 'Present' ? 'text-green-500' : 'text-red-500'} `}
                                                    >
                                                        <p className="shrink-0">{item.attendance}</p>
                                                        <p className="shrink-0">
                                                            CheckInTime: {item.checkInTime}
                                                        </p>
                                                        <p className="shrink-0">
                                                            CheckOutTime: {item.checkOutTime}
                                                        </p>
                                                    </td>
                                                    :
                                                    <></>
                                            )
                                        }
                                    </tr>
                                );
                            })
                        ) : (
                            <></>
                        )}
                    </tbody>
                </table>




            </div>
        </main >
    );
};

export default SingleEmployeeAttendanceSheet;
