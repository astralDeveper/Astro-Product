import { doc, setDoc } from 'firebase/firestore';
import React, { useEffect, useState } from 'react'
import { db } from '../config/firebase/firebaseConfig';

const TaskDetails = ({ closeDeleteModal, taskData, handleModalDetailsOutside }) => {


    const [declineTask, setDeclineTasks] = useState('')

    const assigneeIds = taskData.assignee.map((assignee) => assignee.id);

    // console.log(assigneeIds);



    const declinedTasks = () => {
        setDoc(doc(db, "tasks", taskData?.id), { ...taskData, decline: declineTask, assignee: assigneeIds });

    }

    const [declineDays, setDeclineDays] = useState(false)

    useEffect(() => {

        if (declineDays === false) return

        declinedTasks()

    }, [declineDays])







    const [remainingTime, setRemainingTime] = useState('');

    let [days, setDays] = useState();

    useEffect(() => {
        const endTime = new Date(taskData?.lastDate).getTime();

        const updateTimer = () => {
            setDeclineTasks('')
            const currentTime = new Date().getTime();
            const timeDifference = endTime - currentTime;

            if (timeDifference > 0) {
                const dayse = Math.floor(timeDifference / (1000 * 60 * 60 * 24))
                setDays(Math.floor(timeDifference / (1000 * 60 * 60 * 24)));
                const hours = Math.floor((timeDifference % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60));
                const minutes = Math.floor((timeDifference % (1000 * 60 * 60)) / (1000 * 60));
                const seconds = Math.floor((timeDifference % (1000 * 60)) / 1000);
                setRemainingTime(`${dayse}d ${hours}h ${minutes}m ${seconds}s`);

                setDeclineDays(false)
                setTimeout(updateTimer, 1000);
            } else {
                setRemainingTime('Deadline Expired!');
                setDeclineTasks('decline')
                setDeclineDays(true)
            }
        };

        updateTimer();

        return () => clearTimeout(updateTimer);
    }, [taskData?.lastDate]);




    const [remainingTimes, setRemainingTimes] = useState('Calculating...');

    useEffect(() => {
        const endTime = new Date(taskData?.taskHour).getTime();
        const updateTimer = () => {
            setDeclineTasks('')
            const currentTime = new Date().getTime();
            const timeDifference = endTime - currentTime;

            if (timeDifference > 0) {
                const hours = Math.floor((timeDifference % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60));
                const minutes = Math.floor((timeDifference % (1000 * 60 * 60)) / (1000 * 60));
                const seconds = Math.floor((timeDifference % (1000 * 60)) / 1000);
                setRemainingTimes(`${hours}h ${minutes}m ${seconds}s`);
                setTimeout(updateTimer, 1000);
                setDeclineDays(false)
                
            } else {
                setRemainingTimes('Deadline Expired!');
                setDeclineTasks('decline')
                setDeclineDays(true)

            }
        };

        updateTimer();

        return () => clearTimeout(updateTimer);
    }, [taskData?.lastDate]);




    return (




        <div onClick={handleModalDetailsOutside} id='modal1' className="fixed top-0 left-0 flex justify-center z-50  w-full h-full bg-black bg-opacity-40 p-2 overflow-auto">

            <div className="bg-white lg:w-[50%] w-full h-fit  rounded-lg shadow-lg p-6 m-auto ">
                <button
                    type="button"
                    className="absolute top-3 right-3 text-white  bg-teal-800 hover:bg-teal-300 hover:text-white rounded-lg text-sm w-8 h-8 flex justify-center items-center"
                    onClick={closeDeleteModal}
                >
                    <svg
                        className="w-4 h-4"
                        aria-hidden="true"
                        xmlns="http://www.w3.org/2000/svg"
                        fill="none"
                        viewBox="0 0 14 14"
                    >
                        <path
                            stroke="currentColor"
                            strokeLinecap="round"
                            strokeLinejoin="round"
                            strokeWidth="2"
                            d="m1 1 6 6m0 0 6 6M7 7l6-6M7 7l-6 6"
                        />
                    </svg>
                    <span className="sr-only">Close modal</span>
                </button>

                <div className="w-full ">


                    <article className=" cursor-pointer border p-6 rounded-md  shadow-md">
                        <div className='flex items-center justify-between' >
                            <div className="flex  justify-between items-center">
                                <h2 className="text-2xl font-bold text-neutral-800 [word-break:break-word]">
                                    {taskData?.title}
                                </h2>
                            </div>

                            {taskData?.taskHour ?
                                <p className='text-xl font-bold text-red-600 ' >{remainingTimes}</p>
                                // <></>
                                :
                                days <= 1 || remainingTime == 'Deadline Expired!' ?

                                    <div className="timer-container">
                                        <div style={{ color: 'red', fontSize: '20px', fontWeight: '900' }} >{remainingTime}</div>
                                    </div> : <div className="timer-container">
                                        <div style={{ color: 'green', fontSize: '20px', fontWeight: '900' }} >{remainingTime}</div>
                                    </div>
                            }







                        </div>


                        {taskData?.taskHour ?
                            <div>
                                <time>{taskData?.taskHour}</time>
                            </div>
                            :
                            <div className="text-sm flex lg:gap-6 gap-4  text-neutral-500 mt-2">
                                <time><div className="text-sm flex lg:gap-6 gap-4  text-neutral-500 mt-2">
                                    <time>{taskData?.startDate}</time>
                                    -
                                    <time>{taskData?.lastDate}</time>
                                </div></time>
                                -
                                <time>{taskData?.lastDate}</time>
                            </div>}



                        <p className="mt-6 text-[19px] font-medium break-words">
                            {taskData?.description}
                        </p>

                        <p className="mt-4 flex gap-4 items-center">
                            <img src={taskData?.managerImage} alt="" className="size-12 rounded-full overflow-hidden" />
                            <span>
                                <span>Assign by</span> :  {taskData?.managerName}
                            </span>
                        </p>

                        {
                            taskData?.assignee?.map((s) => (
                                <ul key={s.id} className="  text-lg font-medium flex flex-col gap-1 list-disc list-inside mt-4 [&_p]:inline">
                                    <div>
                                        <span className='text-lg underline font-bold ' >To :</span>
                                        <li>
                                            <p>{s?.name}</p>
                                        </li>
                                    </div>
                                </ul>
                            ))
                        }

                        <article>
                            <div className='text-lg underline font-bold' >
                                Task Files Download:
                            </div>
                            <div>
                                {taskData?.taskFiles?.map((item, index) => {
                                    return (
                                        <div key={index} className='text-lg font-medium '  >

                                            <a href={item} download target="_blank" >{index + 1}) Click her to Download File</a>


                                        </div>
                                    )
                                })}
                            </div>

                        </article>
                    </article>

                </div>
            </div>
        </div>
    )
}

export default TaskDetails