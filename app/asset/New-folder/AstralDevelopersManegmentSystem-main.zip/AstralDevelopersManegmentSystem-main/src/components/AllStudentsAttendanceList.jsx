import { RiArrowRightSFill } from "@remixicon/react";
import { query } from "firebase/database";
import { collection, getDocs, where } from "firebase/firestore";
import React, { useEffect, useState } from "react";
import { NavLink } from "react-router-dom";
import { db } from '../config/firebase/firebaseConfig';


const AllStudentsAttendanceList = () => {
    useEffect(() => {
        getAttendance();
    }, []);

    const [users, setUsers] = useState([]);

    const getAttendance = async () => {
        const q = query(
            collection(db, "users"),
            where("type", "in", ["Employee", "Manager"])
        );
        const allUsers = [];
        const querySnapshot = await getDocs(q);
        querySnapshot.forEach((doc) => {
            allUsers.push({ id: doc.id, ...doc.data() });
        });
        setUsers(allUsers);
    };

    const [filterData, setFilterdata] = useState([]);
    return (
        <main className="max-w-screen-2xl min-w-full ">
            <div className="">
                <div className="grid lg:grid-cols-3 grid-rows-1 items-center justify-center   border shadow-lg p-2 rounded-xl">
                    <div className=" lg:block flex items-center justify-center">
                        <img className="w-20 shrink-0 lg:block  " src="/logo.png" alt="" />
                    </div>

                    <div className="lg:text-[30px] text-base shrink-0 text-teal-900 font-bold">
                        All Employees  List
                    </div>

                    <input
                        type="search"
                        id="default-search"
                        className="shrink-0 block md:w-full  p-4 ps-10 text-sm text-gray-900 border border-gray-300 rounded-lg bg-gray-50 focus:ring-blue-500 focus:border-blue-500 "
                        placeholder="Search Employee Name or Id..."
                        required
                        onChange={(e) => {
                            let arr = users.filter((x) => {
                                if (
                                    x.name.toLowerCase().includes(e.target.value.toLowerCase())
                                ) {
                                    return x;
                                } else if (x.registerId.toLowerCase().includes(e.target.value.toLowerCase())) {
                                    return x;
                                }
                                return null;
                            });
                            setFilterdata([...arr]);
                        }}
                    />
                </div>
            </div>

            <article>
                {filterData.length > 0 ? (
                    filterData.map((filter) => {
                        return (
                            <ul className="flex items-center justify-center w-full lg:flex-row flex-col  gap-5 flex-wrap mt-6 ">
                                <li
                                    key={filter.id}
                                    className="col-span-1 lg:w-[50%] w-full divide-y divide-gray-200 rounded-lg bg-white shadow-2xl
                                     "
                                >
                                    <div className="flex w-full lg:flex-row flex-col items-center justify-between space-x-6 p-6">
                                        <div className="flex-1 truncate w-full ">
                                            <div className="flex items-center flex-col lg:flex-row space-x-3">
                                                <h3 className="truncate text-sm font-medium text-gray-900">
                                                    {filter.name}
                                                </h3>
                                                <span className="inline-flex  items-center rounded-full bg-green-50 px-1.5 py-0.5 text-xs font-medium text-blue-600 ring-1 ring-inset ring-green-600/20">
                                                    {filter.type}
                                                </span>
                                            </div>
                                            <p className="mt-1 truncate text-sm text-gray-500">
                                                {filter.registerId}
                                            </p>
                                        </div>
                                        <img
                                            className="h-10 w-10 rounded-full bg-gray-300"
                                            src={filter.imageUrl}
                                            alt=""
                                        />
                                    </div>
                                    <div>
                                        <div className="-mt-px flex divide-x w-full  divide-gray-200">
                                            <NavLink
                                                state={filter}
                                                to={"/singleStudentAttendance"}
                                                className="flex w-0 flex-1 lg:text-lg text-sm shrink-0 font-bold "
                                            >
                                                <RiArrowRightSFill color="#26847a" />

                                                <span className="text-teal-500  ">
                                                    See employee Attendance
                                                </span>
                                            </NavLink>
                                        </div>
                                    </div>
                                </li>
                            </ul>
                        );
                    })
                ) : users.length > 0 ? (
                    <ul className="flex items-center justify-center w-full lg:flex-row flex-col  gap-5 flex-wrap mt-6">
                        {users.map((item, index) => (
                            <li
                                key={index}
                                className="col-span-1 lg:w-[50%] w-[80%] divide-y divide-gray-200 rounded-lg bg-white shadow-2xl "
                            >
                                <div className="flex w-full  lg:flex-row flex-col items-center justify-between space-x-6 p-6">
                                    <div className="flex-1 truncate ">
                                        <div className="flex items-center flex-col lg:flex-row space-x-3">
                                            <h3 className="truncate  text-sm font-medium text-gray-900">
                                                {item.name}
                                            </h3>
                                            <span className="inline-flex  items-center rounded-full bg-green-50 px-1.5 py-0.5 text-xs font-medium text-blue-600 ring-1 ring-inset ring-green-600/20">
                                                {item.type}
                                            </span>
                                        </div>
                                        <p className="mt-1 truncate text-sm text-gray-500">
                                            {item.registerId}
                                        </p>
                                    </div>
                                    <img
                                        className="h-20 w-20 flex-shrink-0 object-cover rounded-full bg-gray-300"
                                        src={item.imageUrl}
                                        alt=""
                                    />
                                </div>
                                <div>
                                    <div className="-mt-px flex divide-x divide-gray-200">
                                        <NavLink
                                            state={item}
                                            to={"/dashboard/singleEmployeeAttendanceSheet"}
                                            className="flex w-0 flex-1  lg:text-lg text-sm font-bold "
                                        >
                                            <RiArrowRightSFill color="#26847a" />

                                            <span className="text-teal-500  ">
                                                See employee Attendance
                                            </span>
                                        </NavLink>
                                    </div>
                                </div>
                            </li>
                        ))}
                    </ul>
                ) : (
                    <p className="flex items-center justify-center h-screen text-2xl font-extrabold ">
                        Not Employee Found!
                    </p>
                )}
            </article>
        </main>
    );
}

export default AllStudentsAttendanceList