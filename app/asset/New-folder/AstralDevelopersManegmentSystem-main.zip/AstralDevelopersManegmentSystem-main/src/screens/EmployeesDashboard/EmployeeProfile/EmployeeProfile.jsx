import React from 'react'
import ProfileComponent from '../../../components/Profile'

const EmployeeProfile = () => {
    return (
        <>
            <ProfileComponent />
        </>
    )
}

export default EmployeeProfile
