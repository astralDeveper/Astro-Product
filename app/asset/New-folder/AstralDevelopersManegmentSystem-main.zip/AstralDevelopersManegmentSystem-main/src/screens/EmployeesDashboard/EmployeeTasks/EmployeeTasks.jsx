import { RiAttachmentLine, RiCheckDoubleFill, RiDeleteBin2Line, RiLoader2Line, RiSendPlane2Fill } from '@remixicon/react';
import { collection, doc, getDocs, query, setDoc, updateDoc, where } from 'firebase/firestore';
import { deleteObject, getDownloadURL, ref, uploadBytesResumable } from 'firebase/storage';
import React, { useEffect, useState } from 'react';
import Swal from 'sweetalert2';
import TaskConfirmModal from '../../../components/TaskConfirmModal';
import TaskDetails from '../../../components/TaskDetails';
import { db, storage } from '../../../config/firebase/firebaseConfig';
import { useAuth } from '../../AuthProvider';

const EmployeeTasks = () => {
    const { user } = useAuth()

    const [isModalOpenTasks, setIsModalOpenTasks] = useState(false);

    const [selectedTasks, setSelectedTasks] = useState()


    const openTaskDetails = (item, e) => {
        e.stopPropagation();
        setSelectedTasks(item)
        setIsModalOpenTasks(true);
    }



    const closeDeleteModals = async () => {
        setIsModalOpenTasks(false);
    };

    const handleModalDetailsOutside = (event) => {
        if (event.target.id === 'modal1') {
            setIsModalOpenTasks(false);
        }
    };


    const [allUser, setAllUser] = useState([])


    const getData = async () => {
        try {
            const q = query(collection(db, "tasks"), where("assignee", "array-contains", user?.id));

            const querySnapshot = await getDocs(q);

            const allTask = []

            querySnapshot.forEach(async (doc) => {
                const taskData = doc.data()

                const users = query(collection(db, "users"));

                const userSnapshot = await getDocs(users);
                const taskUser = []
                userSnapshot.forEach((users) => {
                    const userData = users.data();
                    if (taskData.assignee.includes(users.id)) {
                        taskUser.push({ id: users.id, ...userData });
                    }
                });
                allTask.push({ ...taskData, id: doc.id, assignee: taskUser })
                setAllUser(allTask);
            });


        } catch (error) {
            console.error('Error fetching data:', error);
        }
    }

    useEffect(() => {
        getData()

    }, [allUser])



    const [statusTask, setStatusTask] = useState(null)

    const [isModalOpen, setIsModalOpen] = useState(false);


    const openTaskConfirmModals = (item, e) => {
        e.stopPropagation();
        setIsModalOpen(true);
        setStatusTask(item)
    };

    const handleModalTaskConfirmOutside = (event) => {
        if (event.target.id === 'modal1') {
            setIsModalOpen(false);

        }
    };
    const closeTaskConfirmModals = () => {
        setIsModalOpen(false);
    };





    const [files, setFiles] = useState([]);


    const handleFileChange = (event) => {
        const file = event.target.files[0];
        setFiles([...files, file]);
    };






    const [progress, setProgress] = useState(0);

    const [URLs, setURLs] = useState([]);

    const [loader, setLoader] = useState(false)

    const uploadImages = () => {

        setLoader(true)
        const promises = [];
        files.map((file) => {
            // console.log(file.name);
            const storageRef = ref(storage, `taskFile/${file.name}`);
            const uploadTask = uploadBytesResumable(storageRef, file);
            promises.push(uploadTask);
            uploadTask.on(
                "state_changed",
                (snapshot) => {
                    const progress = Math.round(
                        (snapshot.bytesTransferred / snapshot.totalBytes) * 100
                    );
                    setProgress(progress);
                },
                (error) => {
                    console.log(error);
                },
                async () => {
                    await getDownloadURL(uploadTask.snapshot.ref).then((downloadURL) => {
                        setURLs((prevURLs) => [...prevURLs, downloadURL]);
                        setImageUpload(true)
                    });
                }
            );
        });
        Promise.all(promises)
            .then(() => {
                setLoader(false)
            })
            .catch((err) => console.log(err));
    };










    const [uploadImage, setImageUpload] = useState(false);




    const status = async () => {

        const washingtonRef = doc(db, "tasks", statusTask?.id);
        let status;
        if (statusTask?.status === 'pending') {
            status = 'In Progress'
        } else if (status = 'In Progress') {
            status = 'Completed'
        } else {
            status = 'Completed'
        }

        // Set the "capital" field of the city 'DC'
        await updateDoc(washingtonRef, {
            status: status,
            taskSubmitFiles: URLs

        });
        // console.log('status change successfully');
        getData()
        let timerInterval;
        Swal.fire({
            title: "Generate Progress",
            html: "I will close in <b></b> milliseconds.",
            timer: 2000,
            timerProgressBar: true,
            didOpen: () => {
                Swal.showLoading();
                const timer = Swal.getPopup().querySelector("b");
                timerInterval = setInterval(() => {
                    timer.textContent = `${Swal.getTimerLeft()}`;
                }, 100);
            },
            willClose: () => {
                clearInterval(timerInterval);
            }
        }).then((result) => {
            /* Read more about handling dismissals below */
            if (result.dismiss === Swal.DismissReason.timer) {
                // console.log("I was closed by the timer");
                setIsModalOpen(false);
            }
        });
    }


    const uploadeImage = (e, item) => {
        e.stopPropagation()
        setStatusTask(item)
        uploadImages()

    }




    const deletedTask = async (e, item) => {
        e.stopPropagation()


        const tasksCollection = collection(db, 'tasks');
        const q = query(tasksCollection);

        try {
            const querySnapshot = await getDocs(q);
            querySnapshot.forEach(async (documentSnapshot) => {
                const docRef = doc(db, 'tasks', documentSnapshot.id);
                await updateDoc(docRef, { taskSubmitFiles: null });
            });
        } catch (error) {
            console.error('Error deleting taskSubmitFiles: ', error);
        }







        const desertRef = ref(storage, item.taskSubmitFiles);
        deleteObject(desertRef).then(() => {

            const Toast = Swal.mixin({
                toast: true,
                position: "top-end",
                showConfirmButton: false,
                timer: 2000,
                timerProgressBar: true,
                didOpen: (toast) => {
                    toast.onmouseenter = Swal.stopTimer;
                    toast.onmouseleave = Swal.resumeTimer;
                }
            });
            Toast.fire({
                icon: "success",
                title: "File Link Deleted successfully"
            });

        }).catch((error) => {
            console.log(error);
        });

        getData()
    }


    useEffect(() => {

        if (!uploadImage) return;

        status()

        getData()

        setImageUpload(false)

    }, [uploadImage, URLs, deletedTask])




    let obj;

    allUser.map((item) => {
        obj = item;
    })

    const inCompleteTask = (e, item) => {
        e.stopPropagation()
        let assignee = [''];
        item.assignee.map((id) => {
            assignee = [id.id]
        });

        setDoc(doc(db, "tasks", item?.id), { ...item, status: 'In Complete', assignee: assignee });



    }



















    return (
        <main className="max-w-screen-xl mx-auto p-4">

            {isModalOpen && <TaskConfirmModal closeTaskConfirmModals={closeTaskConfirmModals} handleModalTaskConfirmOutside={handleModalTaskConfirmOutside} status={status} />}

            {isModalOpenTasks && <TaskDetails closeDeleteModal={closeDeleteModals} taskData={selectedTasks} handleModalDetailsOutside={handleModalDetailsOutside} />}

            <div className="mt-10 max-w-screen-md mx-auto">
                <ul className="flex flex-col gap-5">
                    {allUser.length > 0 ? allUser.map((item) => {
                        return (
                            <li onClick={(e) => openTaskDetails(item, e)} key={item.id} >
                                <article className="border p-6 rounded-md shadow-md cursor-pointer">
                                    <div className="flex justify-between items-center  ">
                                        <h2 className="text-2xl font-bold text-neutral-800 [word-break:break-word] ">
                                            {item.title}
                                        </h2>
                                        {item.status === 'pending' ? (
                                            <p key={item.id} className="px-2 py-1 rounded-full bg-yellow-200 text-yellow-800 text-xs font-medium">
                                                {item.status}
                                            </p>
                                        ) : item.status === 'In Progress' ? (
                                            <p key={item.id} className="px-2 py-1 rounded-full bg-orange-200 text-orange-800 text-xs font-medium">
                                                {item.status}
                                            </p>
                                        ) : item.status === 'Completed' ? (
                                            <p key={item.id} className="px-2 py-1 rounded-full bg-green-200 text-green-800 text-xs font-medium">
                                                {item.status}
                                            </p>
                                        )
                                            : (
                                                <p className="px-2 py-1 rounded-full bg-red-200 text-red-800 text-xs font-medium">
                                                    {item.status}
                                                </p>
                                            )
                                        }
                                    </div>

                                    <div className='flex items-center flex-row-reverse justify-between mt-6' >


                                        <div className='flex items-center flex-col gap-2 justify-end  mb-4 '>
                                            <div>
                                                <button disabled={item.status === 'In Complete'} className={item.status === 'In Complete' || item.status === 'Completed' ? 'hidden' : `lg:flex hidden lg:text-lg text-base items-center gap-2  bg-red-500 text-white py-2 px-4 rounded-md hover:bg-red-600`} onClick={(e) => inCompleteTask(e, item)} >In Complete Task</button>
                                            </div>
                                            {
                                                item.status === 'pending' ? (
                                                    <div>
                                                        <button disabled={item.decline === 'decline'} onClick={(e) => openTaskConfirmModals(item, e)} className={item.decline === 'decline' ? 'lg:flex hidden lg:text-lg text-base items-center gap-2  bg-teal-200 text-white py-2 px-4 rounded-md hover:bg-teal-200' : 'lg:flex hidden lg:text-lg text-base items-center gap-2  bg-teal-500 text-white py-2 px-4 rounded-md hover:bg-teal-600'}>
                                                            In Progress
                                                        </button>
                                                        <button disabled={item.decline === 'decline'} onClick={(e) => openTaskConfirmModals(item, e)} className={item.decline === 'decline' ? 'lg:hidden flex lg:text-lg text-base items-center gap-2  bg-teal-200 text-white py-2 px-4 rounded-md hover:bg-teal-200' : 'lg:hidden flex lg:text-lg text-base items-center gap-2  bg-teal-500 text-white py-2 px-4 rounded-md hover:bg-teal-600'} title={'Progress'} >
                                                            <RiLoader2Line size={23} />
                                                        </button>
                                                    </div>
                                                ) : item.status === 'In Progress' ? (
                                                    <div>
                                                        <button disabled={item.decline === 'decline'} onClick={(e) => openTaskConfirmModals(item, e)} className={item.decline === 'decline' ? 'lg:flex hidden lg:text-lg text-base items-center gap-2  bg-teal-200 text-white py-2 px-4 rounded-md hover:bg-teal-200' : 'lg:flex hidden lg:text-lg text-base items-center gap-2  bg-teal-500 text-white py-2 px-4 rounded-md hover:bg-teal-600'}>
                                                            Completed
                                                        </button>
                                                        <button disabled={item.decline === 'decline'} onClick={(e) => openTaskConfirmModals(item, e)} className={item.decline === 'decline' ? 'lg:hidden flex lg:text-lg text-base items-center gap-2  bg-teal-500 text-white py-2 px-4 rounded-md hover:bg-teal-600' : 'lg:hidden flex lg:text-lg text-base items-center gap-2  bg-teal-500 text-white py-2 px-4 rounded-md hover:bg-teal-600'} title={'Progress'} >
                                                            <RiCheckDoubleFill size={23} />
                                                        </button>
                                                    </div>
                                                ) :
                                                    <></>

                                            }
                                        </div>

                                        <div className='break-words'  >
                                            <p className='lg:text-lg text-sm font-medium lg:font-bold underline mb-2' >Attached Your Completed Tasks</p>
                                            {item.status == 'Completed' ?
                                                <div className='flex items-center gap-4' >
                                                    <div>
                                                        {item?.taskSubmitFiles ?
                                                            <article>
                                                                <p className='' >Task File Link</p>
                                                                <div className='flex items-center gap-6' >
                                                                    <a onClick={(e) => { e.stopPropagation() }} target="_blank" href={item.taskSubmitFiles} className='text-lg font-medium p-2' >Click <span className='text-purple-700 underline text-lg font-medium' >her..</span></a>

                                                                    <button onClick={(e) => deletedTask(e, item)} >
                                                                        <RiDeleteBin2Line size={30} />
                                                                    </button>
                                                                </div>

                                                            </article>
                                                            :
                                                            <></>}


                                                    </div>

                                                    <label onClick={(e) => { e.stopPropagation() }} htmlFor="fileInputProfile" className=" lg:block flex cursor-pointer ">
                                                        <span className="sr-only">Choose profile photo</span>
                                                        <input
                                                            id="fileInputProfile"
                                                            name='avatarUrl'
                                                            multiple
                                                            type="file"
                                                            onChange={handleFileChange}

                                                            className="hidden"
                                                        />
                                                        <span className="file-upload-button lg:flex hidden w-fit  items-center gap-2 bg-teal-500 text-white py-2 px-4 rounded-md hover:bg-teal-600">Completed Tasks File <span><RiAttachmentLine size={30} /></span>
                                                        </span>

                                                        <span className="file-upload-button lg:hidden  items-center gap-2 bg-teal-500 text-white py-2 px-4 rounded-md hover:bg-teal-600" ><RiAttachmentLine size={30} /></span>


                                                    </label>

                                                    {loader == false ?

                                                        <div className='flex items-center' >
                                                            <button onClick={(e) => uploadeImage(e, item)} className='lg:flex hidden items-center gap-2 file-upload-button bg-teal-500 text-white text-sm p-1 rounded-md hover:bg-teal-600' > <span><RiSendPlane2Fill
                                                                size={23} /></span> </button>

                                                            <span onClick={(e) => uploadeImage(e, item)} className='file-upload-button lg:hidden  items-center gap-2 bg-teal-500 text-white py-2 px-4 rounded-md hover:bg-teal-600' ><RiSendPlane2Fill size={24} /></span>
                                                        </div>
                                                        : <div className='flex items-center gap-4' >
                                                            <button disabled type="button" className="text-white bg-teal-700 hover:bg-teal-800 focus:ring-4 focus:ring-teal-300 font-medium rounded-lg text-sm px-5 py-2.5 text-center me-2  inline-flex items-center">
                                                                <svg aria-hidden="true" role="status" className="inline w-4 h-4 me-3 text-white animate-spin" viewBox="0 0 100 101" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                                    <path d="M100 50.5908C100 78.2051 77.6142 100.591 50 100.591C22.3858 100.591 0 78.2051 0 50.5908C0 22.9766 22.3858 0.59082 50 0.59082C77.6142 0.59082 100 22.9766 100 50.5908ZM9.08144 50.5908C9.08144 73.1895 27.4013 91.5094 50 91.5094C72.5987 91.5094 90.9186 73.1895 90.9186 50.5908C90.9186 27.9921 72.5987 9.67226 50 9.67226C27.4013 9.67226 9.08144 27.9921 9.08144 50.5908Z" fill="#E5E7EB" />
                                                                    <path d="M93.9676 39.0409C96.393 38.4038 97.8624 35.9116 97.0079 33.5539C95.2932 28.8227 92.871 24.3692 89.8167 20.348C85.8452 15.1192 80.8826 10.7238 75.2124 7.41289C69.5422 4.10194 63.2754 1.94025 56.7698 1.05124C51.7666 0.367541 46.6976 0.446843 41.7345 1.27873C39.2613 1.69328 37.813 4.19778 38.4501 6.62326C39.0873 9.04874 41.5694 10.4717 44.0505 10.1071C47.8511 9.54855 51.7191 9.52689 55.5402 10.0491C60.8642 10.7766 65.9928 12.5457 70.6331 15.2552C75.2735 17.9648 79.3347 21.5619 82.5849 25.841C84.9175 28.9121 86.7997 32.2913 88.1811 35.8758C89.083 38.2158 91.5421 39.6781 93.9676 39.0409Z" fill="currentColor" />
                                                                </svg>
                                                                Loading...
                                                            </button>

                                                            {progress > 0 && (
                                                                <div className="text-center font-bold text-teal-700 ">{progress}%</div>
                                                            )}
                                                        </div>
                                                    }










                                                </div>
                                                : <></>
                                            }
                                        </div>

                                    </div>



                                </article>
                            </li>
                        )
                    }) : <div className='flex items-center justify-center h-[50vh] font-bold text-3xl flex-col gap-2 text-teal-700'>
                        <p>No Tasks Found!</p>

                    </div>}
                </ul>
            </div>



        </main>
    )
}

export default EmployeeTasks
