import { RiBarChartGroupedFill, RiCloseFill, RiLogoutCircleRLine, RiMenuFill, RiProfileFill, RiTaskFill, RiUser2Fill, RiUserAddFill, RiUserStarFill } from "@remixicon/react";
import { signOut } from "firebase/auth";
import { useEffect, useRef } from "react";
import { Link, NavLink, Outlet, useLocation, useNavigate } from "react-router-dom";
import { auth } from "../../config/firebase/firebaseConfig";
import { useAuth } from "../AuthProvider";


export default function EmployeeDashboard() {
  const ref = useRef();


  const navigate = useNavigate();
  let pathname = useLocation().pathname;

  const { user, setUser } = useAuth();

  const logOut = () => {
    signOut(auth).then(() => {
      setUser(null)
      navigate('/')

    }).catch((error) => {
      console.log('user signOut Faild');
    });
  }

  const openSideBar = () => {
    ref.current.classList.toggle('max-lg:-translate-x-full');
  }

  useEffect(() => {
    if (pathname) {
      ref.current.classList.toggle('max-lg:-translate-x-full');
    }
  }, [pathname])

  return (
    <>
      <div className="grid grid-cols-[18%_auto] max-lg:grid-cols-1 h-[100vh] overflow-hidden   ">
        <div ref={ref} className=" w-fit text-white bg-gradient-to-b from-teal-800 to-teal-400 min-h-[calc(100vh_-_72px)] max-lg:fixed max-lg:top-0 max-lg:inset-0 max-lg:z-50 max-lg:w-9/12 max-lg:max-w-xs max-lg:h-full max-lg:-translate-x-full transition-transform relative max-lg:pt-8">

          <p className="font-bold lg:text-3xl bg-gradient-to-b from-teal-50 to-teal-200 [-webkit-background-clip:text] [-webkit-text-fill-color:transparent] max-lg:hidden uppercase [text-shadow:theme(textColor.teal.100)_2px_2px_2px;] py-5 px-3">
            Astral Developers
          </p>

          <button className="text-teal-300 lg:hidden absolute  top-2 right-2" onClick={openSideBar}>
            <RiCloseFill size={30} />
          </button>

          <nav className="p-5 ">
            <div className='flex items-center gap-4 bg-gradient-to-b from-teal-200 to-teal-50 rounded-md p-2'>
              <div className="shrink-0" >
                <img src={user.imageUrl} alt="" className=" shrink-0 size-14 object-cover rounded-full overflow-hidden" />
              </div>
              <div className='flex items-center justify-center flex-col gap-[-2] shrink-0 ' >
                <p className='text-lg font-bold text-teal-800'>{user.name} </p>
                <p className='text-slate-600'>{user.position}</p>
              </div>
            </div>

            <ul className="flex flex-col gap-4 mt-4">

              <NavLink end to="/employee" className="flex gap-4 items-center hover:text-teal-300 transition-colors">
                <span className='text-teal-300 '>
                  <RiTaskFill size={24} />
                </span>
                <span>All Task</span>
              </NavLink>

              <NavLink end to="/employee/employeeAttendance" className="flex gap-4 items-center hover:text-teal-300 transition-colors">
                <span className='text-teal-300 '>
                  <RiTaskFill size={24} />
                </span>
                <span>Attendance</span>
              </NavLink>

              <NavLink end to="/employee/employeeProfile" className="flex gap-4 items-center hover:text-teal-300 transition-colors">
                <span className='text-teal-300'>
                  <RiProfileFill size={24} />
                </span>
                <span>Profile</span>
              </NavLink>




            </ul>
          </nav>
        </div>

        <div className="bg-gradient-to-b from-teal-800 to-teal-400    lg:ml-[-14px]  ">
          <div className="w-full flex gap-2 justify-between lg:justify-end items-center p-4  bg-teal-800">

            <button className="text-teal-300 lg:hidden" onClick={openSideBar}>
              <RiMenuFill size={30} />
            </button>

            <p className="font-bold text-xl lg:text-3xl bg-gradient-to-b from-teal-50 to-teal-200 [-webkit-background-clip:text] [-webkit-text-fill-color:transparent] lg:hidden uppercase [text-shadow:theme(textColor.teal.100)_2px_2px_2px;] py-5 px-3">
              Astral Developers
            </p>

            <button onClick={logOut} className="px-4 lg:block hidden py-2 bg-sky-400 hover:bg-sky-500 transition-colors text-white rounded-md font-semibold">
              Logout
            </button>

            <button onClick={logOut} className="px-4 lg:hidden py-2 bg-sky-400 hover:bg-sky-500 transition-colors text-white rounded-md font-semibold">
              <RiLogoutCircleRLine size={24} />
            </button>
          </div>
          <div className="rounded-tl-2xl max-lg:rounded-tr-2xl shadow-md bg-gradient-to-b from-teal-50 to-teal-100 h-[100vh] overflow-auto pb-20">
            <Outlet />
          </div>
        </div>
      </div>
    </>
  )
}




