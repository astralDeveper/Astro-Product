import React from 'react'
import AttendanceSheet from '../../../components/AttendanceSheet'

const Attendance = () => {
    return (

        <>
            <AttendanceSheet />
        </>
    )
}

export default Attendance