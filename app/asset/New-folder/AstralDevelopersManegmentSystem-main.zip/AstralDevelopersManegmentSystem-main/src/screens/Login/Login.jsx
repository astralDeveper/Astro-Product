import React, { useState } from 'react';
import { Link, Navigate, useNavigate } from 'react-router-dom';
import { onAuthStateChanged, signInWithEmailAndPassword } from "firebase/auth";
import { auth } from '../../config/firebase/firebaseConfig';
import { useAuth } from '../AuthProvider';
import Swal from 'sweetalert2';
import showPwdImg from '/show.png';
import hidePwdImg from '/hide.png';


const Login = () => {
  const [loginData, setLoginData] = useState({
    email: '',
    password: ''
  })


  const navigate = useNavigate();

  const { user } = useAuth();

  const loginUser = async (e) => {
    e.preventDefault();
    try {
      const userCredential = await signInWithEmailAndPassword(auth, loginData.email, loginData.password);
      const user = userCredential.user;

      switch (user.type) {
        case 'Admin':
          navigate("/dashboard");
          break;
        case 'Manager':
          navigate("/manager");
          break;
        case 'Employee':
          navigate("/employee");
          break;
      }
    } catch (error) {
      const errorMessage = error.message;
      console.log(errorMessage);

      if (error.message.includes('Firebase: Error (auth/invalid-credential)')) {
        Swal.fire({
          position: "center",
          icon: "warning",
          title: 'Email or password is incorrect. Please Fill Out The Correct Input.',
          showConfirmButton: false,
          timerProgressBar: true,
          timer: 35000
        });
      }


      if (error.message.includes('Firebase: Access to this account has been temporarily disabled due to many failed login attempts. You can immediately restore it by resetting your password or you can try again later. (auth/too-many-requests).')) {
        Swal.fire({
          position: "center",
          icon: "warning",
          title: 'Access to this account has been temporarily disabled due to many failed login attempts. You can immediately restore it by resetting your password or you can try again later',
          showConfirmButton: false,
          timerProgressBar: true,
          timer: 35000
        });
      }



    }
  }

  if (user) {
    switch (user.type) {
      case 'Admin':
        return <Navigate to="/dashboard" />
      case 'Manager':
        return <Navigate to="/manager" />
      case 'Employee':
        return <Navigate to="/employee" />
    }
  }


  const [pwd, setPwd] = useState('');
  const [isRevealPwd, setIsRevealPwd] = useState(false);

  { loginData.password = pwd }





  return (
    <>
      <div className="flex items-center justify-center h-screen px-6 py-12 lg:px-8 bg-gradient-to-b from-teal-800 to-teal-400 ">
        <div className="flex flex-col items-center justify-center  border border-[#40ffff]   rounded-e-3xl rounded-s-3xl shadow-2xl p-8 w-full sm:max-w-md ">
          <img
            className="h-[140px] w-auto mb-5"
            src="/logo.png"
            alt="Your Company"
          />
          <h2 className="text-2xl font-bold leading-9 tracking-tight text-black mb-5">
            Sign In
          </h2>
          <form onSubmit={(e) => loginUser(e)} className="w-full" action="#" method="POST">
            <div className="mb-4">
              <label htmlFor="email" className="block text-sm font-medium leading-6 text-black">
                Email address
              </label>
              <input
                id="email"
                name="email"
                type="email"
                autoComplete="email"
                placeholder='email@gmail.com'
                required
                className="block w-full rounded-md   shadow-sm py-2 px-3 placeholder-gray-400 focus:outline-none focus:ring-teal-500 focus:border-teal-500 focus:shadow-outline-indigo transition duration-150 ease-in-out sm:text-sm sm:leading-5"
                onChange={(e) => setLoginData({ ...loginData, email: e.target.value })}
              />
            </div>
            <div className="mb-4">
              <div className="flex justify-between">
                <label htmlFor="password" className="block text-sm font-medium leading-6 text-black">
                  Password
                </label>
              </div>
              <input
                id="password"
                type={isRevealPwd ? "text" : "password"} value={pwd} name="pwd"
                autoComplete="current-password"
                placeholder='*********'
                required
                className=" overflow-auto relative block w-full rounded-md border-gray-300 shadow-sm py-2 px-3 placeholder-gray-400 focus:outline-none focus:ring-teal-500 focus:border-teal-500 focus:shadow-outline-indigo transition duration-150 ease-in-out sm:text-sm sm:leading-5"
                onChange={e => setPwd(e.target.value)}
              />
              <img
                className='w-8 cursor-pointer absolute mt-[-35px]
                lg:left-[58%] left-[65%] sm:left-[68%] 
                lg:ml-0  md:ml-[-14px] md:left-auto   shrink-0 '
                title={isRevealPwd ? "Hide password" : "Show password"}
                src={isRevealPwd ? showPwdImg : hidePwdImg}
                onClick={() => setIsRevealPwd(prevState => !prevState)}
              />
              <Link to={'/password-reset'} className="text-sm mt-2 block font-semibold ">
                Forgot password?
              </Link>
            </div>
            <div>
              <button
                type="submit"
                className="w-full rounded-md bg-teal-700 text-white  py-2 px-4 font-semibold hover:bg-teal-800  transition-colors duration-150 ease-in-out"
              >
                Sign in
              </button>
            </div>
          </form>
        </div>
      </div>
    </>
  )
}

export default Login


