import React from 'react'
import AttendanceSheet from '../../../components/AttendanceSheet'

const ManagerAttendance = () => {
    return (
        <>
            <AttendanceSheet />
        </>

    )
}

export default ManagerAttendance