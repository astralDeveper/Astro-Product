import React from 'react'
import ProfileComponent from '../../../components/Profile'

const ManagerProfile = () => {
    return (
        <>
            <ProfileComponent />
        </>
    )
}

export default ManagerProfile
