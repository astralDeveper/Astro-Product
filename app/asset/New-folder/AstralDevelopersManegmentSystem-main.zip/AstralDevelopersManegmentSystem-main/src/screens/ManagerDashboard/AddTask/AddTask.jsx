import React from 'react'
import AddTasks from '../../../components/AddTask'

const AddTask = () => {
  return (
    <>
      <AddTasks />
    </>



  )
}

export default AddTask
