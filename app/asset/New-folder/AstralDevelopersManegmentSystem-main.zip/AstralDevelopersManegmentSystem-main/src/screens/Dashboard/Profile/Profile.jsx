import React from 'react'
import ProfileComponent from '../../../components/Profile'
import { useAuth } from '../../AuthProvider'

const Profile = () => {


// const user =  useAuth();
// console.log(user);







  return (
    <>
      <ProfileComponent />
    </>
  )
}

export default Profile
