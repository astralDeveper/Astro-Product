import { RiAdminFill, RiBarChartFill, RiCheckboxFill, RiLoopRightLine, RiMailFill, RiTaskFill, RiTeamFill, RiTimeFill } from "@remixicon/react";
import { query } from "firebase/database";
import { collection, getDocs, where } from "firebase/firestore";
import { useEffect, useState } from "react";
import { db } from "../../../config/firebase/firebaseConfig";


export default function AdminGraph() {


  useEffect(() => {

    getEmployee()

  }, [])

  const [Admin, setAdmin] = useState([]);
  const [employee, setEmployee] = useState([]);
  const [manager, setManager] = useState([]);
  const [pendingTasks, setPendingTasks] = useState([]);
  const [completedTasks, setCompletedTasks] = useState([]);
  const [progressTasks, setProgressTasks] = useState([]);


  const getEmployee = async () => {
    try {
      const q = query(collection(db, "users"), where("type", "==", "Admin"));
      const querySnapshot = await getDocs(q);
      const allAdmin = []
      querySnapshot.forEach((doc) => {
        allAdmin.push({ id: doc.id, ...(doc.data()) })
        setAdmin([...allAdmin])
      });

      const qe = query(collection(db, "users"), where("type", "==", "Employee"));
      const querySnapshote = await getDocs(qe);
      const allEmployee = []
      querySnapshote.forEach((doc) => {
        allEmployee.push({ id: doc.id, ...(doc.data()) })
        setEmployee([...allEmployee])
      });

      const qm = query(collection(db, "users"), where("type", "==", "Manager"));
      const querySnapshotM = await getDocs(qm);
      const allManager = []
      querySnapshotM.forEach((doc) => {
        allManager.push({ id: doc.id, ...(doc.data()) })
        setManager([...allManager])
      });

      const qpt = query(collection(db, "tasks"), where("status", "==", "pending"));
      const querySnapshotPT = await getDocs(qpt);
      const pendingTasks = []
      querySnapshotPT.forEach((doc) => {
        pendingTasks.push({ id: doc.id, ...(doc.data()) })
        setPendingTasks(pendingTasks)
      });

      const qc = query(collection(db, "tasks"), where("status", "==", "Completed"));
      const querySnapshotCT = await getDocs(qc);
      const completedTasks = []
      querySnapshotCT.forEach((doc) => {
        completedTasks.push({ id: doc.id, ...(doc.data()) })
        setCompletedTasks(completedTasks)
      });

      const qP = query(collection(db, "tasks"), where("status", "==", "In Progress"));
      const querySnapshotTP = await getDocs(qP);
      const progressTasks = []
      querySnapshotTP.forEach((doc) => {
        progressTasks.push({ id: doc.id, ...(doc.data()) })
        setProgressTasks(progressTasks)
      });




    } catch (error) {
      console.error('Error fetching data:', error);
    }

  }

  // console.log(progressTasks);


  return (
    <>
      {/* <DashboardCards /> */}
      <main className="max-w-screen-xl mx-auto grid grid-cols-3 gap-4 p-4 max-sm:grid-cols-1 max-sm:justify-items-center">

        <article className="w-full grid grid-cols-[1fr_1.5fr] items-center bg-gradient-to-br from-teal-100 to-teal-50 border rounded-md p-6 max-w-xs shadow-md">
          <RiAdminFill
            size={36} className="text-teal-400" />
          <div>
            <h2 className="text-lg text-neutral-500 font-medium">Admin</h2>
            <p className="text-3xl text-neutral-700 font-bold">{Admin.length}</p>
          </div>
        </article>


        <article className="w-full grid grid-cols-[1fr_1.5fr] items-center bg-gradient-to-br from-teal-100 to-teal-50 border rounded-md p-6 max-w-xs shadow-md">
          <RiTeamFill size={36} className="text-teal-400" />
          <div>
            <h2 className="text-lg text-neutral-500 font-medium">Employees</h2>
            <p className="text-3xl text-neutral-700 font-bold">{employee.length}</p>
          </div>
        </article>




        <article className="w-full grid grid-cols-[1fr_1.5fr] items-center bg-gradient-to-br from-teal-100 to-teal-50 border rounded-md p-6 max-w-xs shadow-md">
          <RiTeamFill size={36} className="text-teal-400" />

          <div>
            <h2 className="text-lg text-neutral-500 font-medium">Manager</h2>
            <p className="text-3xl text-neutral-700 font-bold">{manager.length}</p>
          </div>
        </article>

        <article className="w-full grid grid-cols-[1fr_1.5fr] items-center bg-gradient-to-br from-teal-100 to-teal-50 border rounded-md p-6 max-w-xs shadow-md">
          <RiTimeFill size={36} className="text-teal-400" />
          <div>
            <h2 className="text-lg text-neutral-500 font-medium">Pending Tasks</h2>
            <p className="text-3xl text-neutral-700 font-bold">{pendingTasks.length}</p>
          </div>
        </article>

        <article className="w-full grid grid-cols-[1fr_1.5fr] items-center bg-gradient-to-br from-teal-100 to-teal-50 border rounded-md p-6 max-w-xs shadow-md">
          <RiLoopRightLine
            size={36} className="text-teal-400" />
          <div>
            <h2 className="text-lg text-neutral-500 font-medium">In Progress Tasks</h2>
            <p className="text-3xl text-neutral-700 font-bold">{progressTasks.length}</p>
          </div>
        </article>

        <article className="w-full grid grid-cols-[1fr_1.5fr] items-center bg-gradient-to-br from-teal-100 to-teal-50 border rounded-md p-6 max-w-xs shadow-md">
          <RiCheckboxFill size={36} className="text-teal-400" />
          <div>
            <h2 className="text-lg text-neutral-500 font-medium">Completed Tasks</h2>
            <p className="text-3xl text-neutral-700 font-bold">{completedTasks.length}</p>
          </div>
        </article>

      </main>
    </>
  )
}


