import React from 'react'
import AllStudentsAttendanceList from '../../../components/AllStudentsAttendanceList'

const AllAttendance = () => {
    return (
        <>
            <AllStudentsAttendanceList />
        </>
    )
}

export default AllAttendance